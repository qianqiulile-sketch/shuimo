package com.dia.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.LinkedHashMap
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

class DiaAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        private var instance: DiaAccessibilityService? = null

        fun getInstance(): DiaAccessibilityService? = instance

        fun isRunning(): Boolean = instance != null
    }

    private val nodeCache = LinkedHashMap<String, AccessibilityNodeInfo>()
    private var nodeCounter = 0

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.d("DiaAccessibility", "Service Connected")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Here Dia will listen to screen changes to act as a system-wide agent.
        event?.let {
            if (it.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
                Log.d("DiaAccessibility", "Window changed: ${it.packageName}")
                try { com.dia.app.guide.GuideEngine.onScreenChanged() } catch (_: Exception) {}
            } else if (it.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED) {
                // User tapped something — this is the real signal for Guide to advance.
                try { com.dia.app.guide.GuideEngine.onUserClicked() } catch (_: Exception) {}
            }
        }
    }

    override fun onInterrupt() {
        Log.d("DiaAccessibility", "Service Interrupted")
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        clearNodeCache()
    }

    fun getScreenTree(): String? {
        return try {
            val root = rootInActiveWindow ?: return "Screen unavailable (no window)"
            clearNodeCache()
            nodeCounter = 0
            val sb = StringBuilder()
            // Header: which app is foreground, so the agent knows the context.
            val pkg = root.packageName?.toString().orEmpty()
            if (pkg.isNotEmpty()) sb.append("APP: ").append(pkg).append('\n')
            buildTreeCompact(root, sb)
            val result = sb.toString().trim()
            if (result.isEmpty()) "No interactive nodes found" else result
        } catch (e: Exception) {
            Log.e("DiaAccessibility", "getScreenTree crash", e)
            "Error building screen tree: ${e.message}"
        }
    }

    /**
     * Get ALL visible text on the current screen — for translation purposes.
     * Includes non-interactive text nodes that the compact tree skips.
     * Returns a plain text dump of everything readable on screen.
     */
    fun getAllScreenText(): String? {
        return try {
            val root = rootInActiveWindow ?: return null
            val sb = StringBuilder()
            collectAllText(root, sb)
            val result = sb.toString().trim()
            if (result.isEmpty()) null else result
        } catch (e: Exception) {
            Log.e("DiaAccessibility", "getAllScreenText crash", e)
            null
        }
    }

    private fun collectAllText(node: AccessibilityNodeInfo, sb: StringBuilder) {
        try {
            val text = node.text?.toString()?.trim().orEmpty()
            val desc = node.contentDescription?.toString()?.trim().orEmpty()
            val hint = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                node.hintText?.toString()?.trim().orEmpty()
            } else ""

            // Add any non-empty text we find.
            if (text.isNotEmpty() && text.length > 1) sb.append(text).append('\n')
            else if (desc.isNotEmpty() && desc.length > 1) sb.append(desc).append('\n')
            else if (hint.isNotEmpty() && hint.length > 1) sb.append(hint).append('\n')

            for (i in 0 until node.childCount) {
                val child = node.getChild(i) ?: continue
                collectAllText(child, sb)
            }
        } catch (_: Exception) {}
    }

    fun getNodeCoordinates(nodeId: String): IntArray? {
        val node = nodeCache[nodeId] ?: return null
        val bounds = Rect()
        node.getBoundsInScreen(bounds)
        return intArrayOf(bounds.centerX(), bounds.centerY())
    }

    fun getNodeById(nodeId: String): AccessibilityNodeInfo? {
        return nodeCache[nodeId]
    }

    fun findNodesByText(query: String): List<AccessibilityNodeInfo> {
        val root = rootInActiveWindow ?: return emptyList()
        val matches = ArrayList<AccessibilityNodeInfo>()
        val needle = query.trim().lowercase(Locale.US)
        if (needle.isEmpty()) return matches
        collectMatches(root, needle, matches)
        return matches
    }

    fun recycleNodes(nodes: List<AccessibilityNodeInfo>) {
        nodes.forEach {
            try {
                it.recycle()
            } catch (_: Exception) {
            }
        }
    }

    fun performTap(x: Int, y: Int, durationMs: Long = 80): Boolean {
        return try {
            val service = getInstance()
            if (service == null) {
                Log.e("DiaAccessibility", "Service null in performTap")
                return false
            }
            val path = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
            val stroke = GestureDescription.StrokeDescription(path, 0, durationMs)
            val gesture = GestureDescription.Builder().addStroke(stroke).build()
            dispatchGestureSync(gesture)
        } catch (e: Exception) {
            Log.e("DiaAccessibility", "performTap crash", e)
            false
        }
    }

    fun performLongPress(x: Int, y: Int, durationMs: Long = 600): Boolean {
        return performTap(x, y, durationMs)
    }

    fun performSwipe(startX: Int, startY: Int, endX: Int, endY: Int, durationMs: Long = 450): Boolean {
        return try {
            val service = getInstance()
            if (service == null) {
                Log.e("DiaAccessibility", "Service null in performSwipe")
                return false
            }
            val path = Path().apply {
                moveTo(startX.toFloat(), startY.toFloat())
                lineTo(endX.toFloat(), endY.toFloat())
            }
            val stroke = GestureDescription.StrokeDescription(path, 0, durationMs)
            val gesture = GestureDescription.Builder().addStroke(stroke).build()
            dispatchGestureSync(gesture)
        } catch (e: Exception) {
            Log.e("DiaAccessibility", "performSwipe crash", e)
            false
        }
    }

    /**
     * Take a screenshot from within the accessibility service context.
     * Only works on Android 11+ (API 30). The callback receives a software
     * Bitmap or null on failure.
     */
    fun captureScreenshot(callback: (android.graphics.Bitmap?) -> Unit) {
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.R) {
            callback(null)
            return
        }
        try {
            takeScreenshot(
                android.view.Display.DEFAULT_DISPLAY,
                mainExecutor,
                object : TakeScreenshotCallback {
                    override fun onSuccess(result: ScreenshotResult) {
                        try {
                            val hwBitmap = android.graphics.Bitmap.wrapHardwareBuffer(
                                result.hardwareBuffer, result.colorSpace
                            )
                            val softBitmap = hwBitmap?.copy(android.graphics.Bitmap.Config.ARGB_8888, false)
                            result.hardwareBuffer.close()
                            callback(softBitmap)
                        } catch (e: Exception) {
                            Log.e("DiaAccessibility", "screenshot decode failed", e)
                            callback(null)
                        }
                    }

                    override fun onFailure(errorCode: Int) {
                        Log.e("DiaAccessibility", "takeScreenshot failed: $errorCode")
                        callback(null)
                    }
                }
            )
        } catch (e: Exception) {
            Log.e("DiaAccessibility", "captureScreenshot error", e)
            callback(null)
        }
    }

    /**
     * Submit the currently focused input field.
     *
     * Tries in order:
     *  1. AccessibilityNodeInfo.ACTION_IME_ENTER (Android R+, invokes the IME's
     *     done/search action — works inside almost every real app).
     *  2. Dispatching KEYCODE_ENTER via Runtime.exec — works only with adb shell
     *     (safe no-op otherwise, included as a last resort).
     *
     * Returns true if any strategy reported success.
     */
    fun performImeEnter(): Boolean {
        val root = rootInActiveWindow ?: return false
        val focused = try { root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) } catch (_: Exception) { null }
            ?: try { root.findFocus(AccessibilityNodeInfo.FOCUS_ACCESSIBILITY) } catch (_: Exception) { null }

        if (focused != null) {
            // Strategy 1 (R+): IME's bound action — Search / Done / Next /
            // whatever the EditText has imeOptions set to. This is what
            // tapping the keyboard's blue "search" button actually does.
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                try {
                    val ok = focused.performAction(
                        AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id
                    )
                    if (ok) return true
                } catch (_: Exception) {}
            }

            // Strategy 2: append a literal "\n" to the field text. Most
            // text-based search bars treat a newline as submit.
            try {
                val current = focused.text?.toString().orEmpty()
                val args = android.os.Bundle().apply {
                    putCharSequence(
                        AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                        current + "\n",
                    )
                }
                val ok = focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
                if (ok) {
                    // Move caret to end so the newline registers as input.
                    val end = (current.length + 1)
                    val sel = android.os.Bundle().apply {
                        putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, end)
                        putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, end)
                    }
                    try { focused.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, sel) } catch (_: Exception) {}
                    return true
                }
            } catch (_: Exception) {}

            // Strategy 3: click the focused field — some custom search bars
            // submit on click after the IME has accepted the text.
            try { focused.performAction(AccessibilityNodeInfo.ACTION_CLICK) } catch (_: Exception) {}
        }

        // Strategy 4: try the rooted/adb fallback. Harmless if it fails.
        return try {
            Runtime.getRuntime().exec(arrayOf("input", "keyevent", "66")).waitFor()
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun dispatchGestureSync(gesture: GestureDescription): Boolean {
        return try {
            val latch = CountDownLatch(1)
            val result = BooleanArray(1)
            result[0] = false
            
            dispatchGesture(gesture, object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription) {
                    result[0] = true
                    latch.countDown()
                }

                override fun onCancelled(gestureDescription: GestureDescription) {
                    result[0] = false
                    latch.countDown()
                }
            }, null)
            
            // Wait up to 2 seconds for gesture to complete
            val completed = latch.await(2, TimeUnit.SECONDS)
            if (!completed) {
                Log.w("DiaAccessibility", "Gesture timeout")
                false
            } else {
                result[0]
            }
        } catch (e: Exception) {
            Log.e("DiaAccessibility", "dispatchGestureSync error", e)
            false
        }
    }

    private fun buildTree(node: AccessibilityNodeInfo, sb: StringBuilder, depth: Int) {
        val id = "n${++nodeCounter}"
        nodeCache[id] = node

        val bounds = Rect().apply { node.getBoundsInScreen(this) }
        val text = node.text?.toString()?.trim().orEmpty()
        val desc = node.contentDescription?.toString()?.trim().orEmpty()
        val className = node.className?.toString().orEmpty()

        sb.append("[").append(id).append("] ")
        if (text.isNotEmpty()) sb.append("text=\"").append(text).append("\" ")
        if (desc.isNotEmpty()) sb.append("desc=\"").append(desc).append("\" ")
        sb.append("class=").append(className).append(" ")
        sb.append("bounds=")
            .append("[")
            .append(bounds.left).append(",")
            .append(bounds.top).append(",")
            .append(bounds.right).append(",")
            .append(bounds.bottom).append("] ")
        sb.append("clickable=").append(node.isClickable)
        sb.append(" enabled=").append(node.isEnabled)
        sb.append(" focusable=").append(node.isFocusable)
        sb.append("\n")

        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            buildTree(child, sb, depth + 1)
        }
    }

    private fun buildTreeCompact(node: AccessibilityNodeInfo, sb: StringBuilder) {
        try {
            val text = node.text?.toString()?.trim().orEmpty()
            val desc = node.contentDescription?.toString()?.trim().orEmpty()
            val hint = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                node.hintText?.toString()?.trim().orEmpty()
            } else ""
            val clickable = node.isClickable
            val focusable = node.isFocusable
            val editable = node.isEditable
            val checkable = node.isCheckable
            val longClickable = node.isLongClickable
            val className = node.className?.toString().orEmpty()
            val looksEditable = editable ||
                className.contains("EditText", ignoreCase = true) ||
                className.contains("AutoComplete", ignoreCase = true) ||
                className.contains("SearchView", ignoreCase = true) ||
                className.contains("SearchBar", ignoreCase = true) ||
                className.contains("TextField", ignoreCase = true) ||
                className.contains("TextInput", ignoreCase = true)

            val bounds = Rect().apply { node.getBoundsInScreen(this) }
            val visible = bounds.width() > 0 && bounds.height() > 0

            val hasContent = text.isNotEmpty() || desc.isNotEmpty() || hint.isNotEmpty()
            val isInteractive = clickable || focusable || editable || longClickable || looksEditable

            // Emit only nodes the agent can actually reason about. Raise the
            // cap well above the count any normal screen has so the real
            // EditText is never truncated away.
            if (visible && (hasContent || isInteractive) && nodeCounter < 250) {
                val id = "n${++nodeCounter}"
                nodeCache[id] = node

                sb.append('[').append(id).append("] ")

                // Label: prefer visible text, then content description, then
                // hint text (important for empty search fields).
                when {
                    text.isNotEmpty() -> sb.append('"').append(text.take(48)).append("\" ")
                    desc.isNotEmpty() -> sb.append('(').append(desc.take(48)).append(") ")
                    hint.isNotEmpty() -> sb.append("hint=\"").append(hint.take(48)).append("\" ")
                }

                // Explicit markers — the agent picks the right tool from these.
                if (looksEditable) sb.append("EDIT ")
                if (clickable) sb.append("TAP ")
                if (longClickable) sb.append("LONG ")
                if (checkable) sb.append(if (node.isChecked) "ON " else "OFF ")

                // Disambiguation markers — small models otherwise confuse a
                // mic icon labeled "Voice search" with the actual search bar.
                // We append explicit hint tokens so the model can route around.
                val labelLower = (text + " " + desc + " " + hint).lowercase()
                when {
                    listOf("voice search", "voice", "microphone", "mic ", " mic", "speak").any { labelLower.contains(it) } ->
                        sb.append("MIC ")
                    listOf("camera", "lens icon", "scan", "barcode", "qr code", "image search").any { labelLower.contains(it) } ->
                        sb.append("CAM ")
                }

                sb.append('@')
                    .append(bounds.centerX()).append(',').append(bounds.centerY())
                    .append('\n')
            }

            for (i in 0 until node.childCount) {
                try {
                    val child = node.getChild(i) ?: continue
                    buildTreeCompact(child, sb)
                } catch (e: Exception) {
                    Log.w("DiaAccessibility", "Error processing child $i", e)
                }
            }
        } catch (e: Exception) {
            Log.w("DiaAccessibility", "buildTreeCompact node error", e)
        }
    }

    private fun collectMatches(
        node: AccessibilityNodeInfo,
        needle: String,
        out: MutableList<AccessibilityNodeInfo>,
    ) {
        val text = node.text?.toString()?.lowercase(Locale.US).orEmpty()
        val desc = node.contentDescription?.toString()?.lowercase(Locale.US).orEmpty()
        if (text.contains(needle) || desc.contains(needle)) {
            out.add(node)
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            collectMatches(child, needle, out)
        }
    }

    private fun clearNodeCache() {
        nodeCache.values.forEach {
            try {
                it.recycle()
            } catch (_: Exception) {
            }
        }
        nodeCache.clear()
    }
}
