package com.dia.app.agent

import kotlin.math.PI
import kotlin.math.E
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.roundToLong
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

/**
 * 精确计算器（纯 Kotlin，可单元测试）。小模型心算容易出错，算数一律交给它。
 * 支持 + - * / ^ % 括号、×÷、中文括号，函数 sqrt sin cos tan ln log abs round floor，常量 pi e。
 */
object Calc {

    fun eval(expr: String): Double {
        val s = expr.replace('×', '*').replace('÷', '/').replace('（', '(').replace('）', ')')
            .replace("，", "").replace(",", "").replace("　", "").replace(" ", "").replace("**", "^")
            .replace("π", "pi")
        val p = Parser(s)
        val v = p.expr()
        if (p.pos < s.length) throw IllegalArgumentException("无法解析：${s.substring(p.pos)}")
        return v
    }

    fun format(v: Double): String = when {
        v.isNaN() -> "无效结果"
        v.isInfinite() -> "无穷大"
        abs(v - v.roundToLong()) < 1e-9 && abs(v) < 1e15 -> v.roundToLong().toString()
        else -> "%.10f".format(v).trimEnd('0').trimEnd('.')
    }

    private class Parser(val s: String) {
        var pos = 0

        fun peek(): Char = if (pos < s.length) s[pos] else '\u0000'

        fun expr(): Double {
            var v = term()
            while (true) {
                when (peek()) {
                    '+' -> { pos++; v += term() }
                    '-' -> { pos++; v -= term() }
                    else -> return v
                }
            }
        }

        fun term(): Double {
            var v = power()
            while (true) {
                when (peek()) {
                    '*' -> { pos++; v *= power() }
                    '/' -> { pos++; val d = power(); if (d == 0.0) throw ArithmeticException("除数不能为 0"); v /= d }
                    '%' -> {
                        // 后面跟数字 / 括号视为取余，否则视为百分号
                        val next = if (pos + 1 < s.length) s[pos + 1] else '\u0000'
                        if (next.isDigit() || next == '(') { pos++; v %= power() } else { pos++; v /= 100.0 }
                    }
                    else -> return v
                }
            }
        }

        /** 一元正负号比乘方优先级低：-2^2 = -4 */
        fun power(): Double = when (peek()) {
            '-' -> { pos++; -power() }
            '+' -> { pos++; power() }
            else -> {
                val base = atom()
                if (peek() == '^') {
                    pos++
                    base.pow(power())
                } else base
            }
        }

        fun atom(): Double {
            val c = peek()
            if (c == '(') {
                pos++
                val v = expr()
                if (peek() == ')') pos++ else throw IllegalArgumentException("缺少右括号")
                return v
            }
            if (c.isDigit() || c == '.') {
                val start = pos
                while (pos < s.length && (s[pos].isDigit() || s[pos] == '.')) pos++
                if (pos < s.length && (s[pos] == 'e' || s[pos] == 'E') && pos + 1 < s.length && (s[pos + 1].isDigit() || s[pos + 1] == '-')) {
                    pos += 2
                    while (pos < s.length && s[pos].isDigit()) pos++
                }
                return s.substring(start, pos).toDouble()
            }
            if (c.isLetter()) {
                val start = pos
                while (pos < s.length && s[pos].isLetter()) pos++
                val name = s.substring(start, pos).lowercase()
                when (name) {
                    "pi" -> return PI
                    "e" -> return E
                }
                val arg = atom()
                return when (name) {
                    "sqrt" -> sqrt(arg)
                    "sin" -> sin(arg)
                    "cos" -> cos(arg)
                    "tan" -> tan(arg)
                    "ln" -> ln(arg)
                    "log" -> log10(arg)
                    "abs" -> abs(arg)
                    "round" -> arg.roundToLong().toDouble()
                    "floor" -> floor(arg)
                    else -> throw IllegalArgumentException("不认识的函数：$name")
                }
            }
            throw IllegalArgumentException("表达式有误（位置 ${pos + 1}）")
        }
    }
}
