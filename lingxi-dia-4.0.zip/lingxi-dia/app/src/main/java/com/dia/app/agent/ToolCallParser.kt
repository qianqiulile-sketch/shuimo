package com.dia.app.agent

/**
 * 从模型输出里找工具调用（纯 Kotlin，可单元测试）。
 *
 * 首选格式：`<tool>{"name":"web_search","args":{"query":"…"}}</tool>`
 * 也兼容小模型常见的变体：```json {…}```、`<tool_call>…</tool_call>`、
 * 开头直接是 `{"name":…}` / `{"tool":…,"params":…}`。
 */
object ToolCallParser {

    data class Raw(val json: String, val before: String)

    private val tagRe = Regex("<(tool|tool_call|function_call)>\\s*([\\s\\S]*?)\\s*</\\1>", RegexOption.IGNORE_CASE)
    private val fenceRe = Regex("```(?:json|tool)?\\s*(\\{[\\s\\S]*?\\})\\s*```", RegexOption.IGNORE_CASE)

    /** 找到第一段工具调用 JSON。 */
    fun findRaw(text: String): Raw? {
        tagRe.find(text)?.let { m ->
            val obj = firstJsonObject(m.groupValues[2]) ?: return@let
            return Raw(obj, text.substring(0, m.range.first).trim())
        }
        // 只写了开标签没写闭标签
        val open = Regex("<(tool|tool_call)>", RegexOption.IGNORE_CASE).find(text)
        if (open != null) {
            val obj = firstJsonObject(text.substring(open.range.last + 1))
            if (obj != null) return Raw(obj, text.substring(0, open.range.first).trim())
        }
        fenceRe.find(text)?.let { m ->
            val obj = m.groupValues[1]
            if (looksLikeCall(obj)) return Raw(firstJsonObject(obj) ?: obj, text.substring(0, m.range.first).trim())
        }
        val trimmed = text.trimStart()
        if (trimmed.startsWith("{")) {
            val obj = firstJsonObject(trimmed)
            if (obj != null && looksLikeCall(obj)) return Raw(obj, "")
        }
        return null
    }

    /**
     * 找出一段输出里的全部工具调用（模型可以一次给出多个互不依赖的调用）。
     * 没有标签时退回 [findRaw] 的单个结果。
     */
    fun findAll(text: String): List<Raw> {
        val out = ArrayList<Raw>()
        for (m in tagRe.findAll(text)) {
            val inner = m.groupValues[2]
            // 一个标签里也可能塞了 JSON 数组：[{...},{...}]
            val trimmed = inner.trim()
            if (trimmed.startsWith("[")) {
                var rest = trimmed
                while (true) {
                    val obj = firstJsonObject(rest) ?: break
                    if (looksLikeCall(obj)) out.add(Raw(obj, ""))
                    val idx = rest.indexOf(obj)
                    if (idx < 0) break
                    rest = rest.substring(idx + obj.length)
                }
            } else {
                firstJsonObject(inner)?.let { out.add(Raw(it, "")) }
            }
        }
        if (out.isNotEmpty()) {
            // 末尾还有一个只写了开标签的调用
            val lastClose = text.lastIndexOf("</")
            val tailOpen = Regex("<(tool|tool_call)>", RegexOption.IGNORE_CASE).findAll(text).lastOrNull()
            if (tailOpen != null && tailOpen.range.first > lastClose) {
                firstJsonObject(text.substring(tailOpen.range.last + 1))?.let { out.add(Raw(it, "")) }
            }
            return out
        }
        // 多个 ```json 代码块
        val fences = fenceRe.findAll(text).map { it.groupValues[1] }.filter { looksLikeCall(it) }.toList()
        if (fences.size > 1) return fences.mapNotNull { f -> firstJsonObject(f)?.let { Raw(it, "") } }
        return listOfNotNull(findRaw(text))
    }

    private fun looksLikeCall(json: String): Boolean =
        Regex("\"(name|tool|function)\"\\s*:\\s*\"[a-zA-Z_]+\"").containsMatchIn(json)

    /** 取出第一个括号配平的 JSON 对象（会跳过字符串里的括号）。 */
    fun firstJsonObject(s: String): String? {
        val start = s.indexOf('{')
        if (start < 0) return null
        var depth = 0
        var inStr = false
        var esc = false
        for (i in start until s.length) {
            val c = s[i]
            if (inStr) {
                if (esc) esc = false
                else if (c == '\\') esc = true
                else if (c == '"') inStr = false
                continue
            }
            when (c) {
                '"' -> inStr = true
                '{' -> depth++
                '}' -> {
                    depth--
                    if (depth == 0) return s.substring(start, i + 1)
                }
            }
        }
        // 没配平：尝试补齐右括号
        if (depth in 1..3) return s.substring(start) + "}".repeat(depth)
        return null
    }

    /**
     * 流式输出时用来隐藏工具调用标记：去掉完整的 `<tool>…</tool>`，
     * 以及末尾还没写完的 `<tool…` / `<to`。
     */
    fun visibleText(streaming: String): String {
        var t = tagRe.replace(streaming, "")
        val idx = Regex("<(tool|tool_call|function_call)>", RegexOption.IGNORE_CASE).find(t)?.range?.first
        if (idx != null) t = t.substring(0, idx)
        // 末尾不完整的标签前缀
        val lt = t.lastIndexOf('<')
        if (lt >= 0 && lt >= t.length - 14) {
            val tail = t.substring(lt).lowercase()
            if ("<tool_call>".startsWith(tail) || "<tool>".startsWith(tail) || "<function_call>".startsWith(tail)) {
                t = t.substring(0, lt)
            }
        }
        return t
    }

    /** 输出看起来像是要调用工具（流式时先不显示）。 */
    fun mightBeCall(streaming: String): Boolean {
        val t = streaming.trimStart()
        if (t.isEmpty()) return true
        if (t.startsWith("{") || t.startsWith("```json") || t.startsWith("```tool")) return true
        if (t.startsWith("<")) {
            val head = t.take(15).lowercase()
            return head.startsWith("<tool") || head.startsWith("<function") || "<tool".startsWith(head)
        }
        return false
    }
}
