package com.dia.app.deep

import android.content.Context
import android.util.Log
import com.dia.app.agent.AgentListener
import com.dia.app.agent.AgentRequest
import com.dia.app.agent.AgentTools
import com.dia.app.agent.DiaAgent
import com.dia.app.agent.ToolOutcome
import com.dia.app.files.AiFolder
import com.dia.app.llm.LlmGateway
import com.dia.app.prefs.DiaSettings
import com.dia.app.ui.chat.ChatController
import com.dia.app.web.WebSearch
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/** 等用户批准的一个操作（长思关闭了「自动批准」时）。 */
data class DeepConfirm(val sessionId: String, val title: String, val detail: String)

/**
 * 自主长思引擎 —— 让灵犀成为「活的、自循环、自动的」AI。
 *
 * 给一个主题，它会：
 *  1. 拆解：先（可选联网）了解主题，制定一份分层的计划（用户可随时增删改、细化、调整顺序）
 *  2. 循环：每一轮读取「已经做了什么 / 还要做什么 / 用户新消息」，挑下一个步骤，
 *     调用一切工具（联网、文件、计算、生图、操控手机……）完成它；需要时自己改计划、给自己下新命令
 *  3. 记录：每一步的产出写进「灵犀AI/长思/<主题>/」（计划.md、日志.md、总结.md、步骤/…），并做简短总结
 *  4. 复盘：计划做完后自己复盘、提出新的深挖方向，**一直运行直到用户暂停**
 *
 * 用户随时可以插话（下一轮优先处理；勾「立即」会打断当前步骤）。在后台由 [DeepThinkService] 保活。
 */
object DeepEngine {

    private const val TAG = "DeepEngine"
    private const val MAX_EVENTS = 400

    private lateinit var appCtx: Context
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private val _sessions = MutableStateFlow<List<DeepSession>>(emptyList())
    val sessions: StateFlow<List<DeepSession>> = _sessions.asStateFlow()

    private val eventFlows = ConcurrentHashMap<String, MutableStateFlow<List<DeepEvent>>>()
    private val loops = ConcurrentHashMap<String, Job>()
    private val stepJobs = ConcurrentHashMap<String, Job>()
    private val confirmWaits = ConcurrentHashMap<String, CompletableDeferred<Boolean>>()

    private val _confirm = MutableStateFlow<DeepConfirm?>(null)
    /** 当前等用户批准的操作（界面顶部显示「准 / 驳」）。 */
    val confirm: StateFlow<DeepConfirm?> = _confirm.asStateFlow()

    private val timeFmt = SimpleDateFormat("M月d日 HH:mm", Locale.CHINA)

    val isReady: Boolean get() = ::appCtx.isInitialized

    fun init(context: Context) {
        if (::appCtx.isInitialized) return
        appCtx = context.applicationContext
        scope.launch(Dispatchers.IO) { loadAll() }
    }

    // ───────── 读写 ─────────

    private fun root(): File = AiFolder.dir("长思")

    private fun loadAll() {
        val list = ArrayList<DeepSession>()
        try {
            for (d in root().listFiles().orEmpty()) {
                val f = File(d, "state.json")
                if (!f.isFile) continue
                try {
                    val s = DeepJson.session(JSONObject(f.readText())).let { it.copy(folder = d.absolutePath) }
                    list.add(s)
                    val ev = File(d, "events.json")
                    val events = if (ev.isFile) DeepJson.events(JSONArray(ev.readText())) else emptyList()
                    eventFlows.getOrPut(s.id) { MutableStateFlow(emptyList()) }.value = events
                } catch (e: Exception) {
                    Log.w(TAG, "skip ${d.name}: ${e.message}")
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "loadAll: ${e.message}")
        }
        _sessions.value = list.sortedByDescending { it.updatedAt }
    }

    fun get(id: String): DeepSession? = _sessions.value.firstOrNull { it.id == id }

    fun events(id: String): StateFlow<List<DeepEvent>> = eventFlows.getOrPut(id) { MutableStateFlow(emptyList()) }.asStateFlow()

    fun folderOf(id: String): File? = get(id)?.folder?.takeIf { it.isNotBlank() }?.let { File(it) }

    fun isRunning(id: String): Boolean = loops[id]?.isActive == true

    fun runningCount(): Int = loops.values.count { it.isActive }

    private fun mutate(id: String, persist: Boolean = true, f: (DeepSession) -> DeepSession): DeepSession? {
        var out: DeepSession? = null
        _sessions.update { list ->
            list.map { s -> if (s.id == id) f(s).copy(updatedAt = System.currentTimeMillis()).also { out = it } else s }
        }
        if (persist) out?.let { save(it) }
        return out
    }

    private fun save(s: DeepSession) {
        val dir = File(s.folder)
        scope.launch(Dispatchers.IO) {
            try {
                dir.mkdirs()
                File(dir, "state.json").writeText(DeepJson.session(s).toString(1))
                File(dir, "计划.md").writeText(PlanOps.markdown(s.topic, s.plan))
                AiFolder.touch()
            } catch (e: Exception) {
                Log.w(TAG, "save: ${e.message}")
            }
        }
    }

    private fun saveEvents(id: String) {
        val s = get(id) ?: return
        val list = eventFlows[id]?.value ?: return
        scope.launch(Dispatchers.IO) {
            try { File(s.folder, "events.json").writeText(DeepJson.events(list.takeLast(MAX_EVENTS)).toString()) } catch (_: Exception) { }
        }
    }

    private fun event(id: String, kind: String, title: String, detail: String = "", status: String = "", note: String = "", toolName: String? = null): String {
        val e = DeepEvent(UUID.randomUUID().toString(), System.currentTimeMillis(), kind, title, detail, status, note, toolName)
        eventFlows.getOrPut(id) { MutableStateFlow(emptyList()) }.update { (it + e).takeLast(MAX_EVENTS) }
        return e.id
    }

    private fun updateEvent(id: String, eventId: String, f: (DeepEvent) -> DeepEvent) {
        eventFlows[id]?.update { list -> list.map { if (it.id == eventId) f(it) else it } }
    }

    private fun appendFile(s: DeepSession, name: String, text: String) {
        try {
            val f = File(s.folder, name)
            f.parentFile?.mkdirs()
            f.appendText(text)
        } catch (e: Exception) {
            Log.w(TAG, "append $name: ${e.message}")
        }
    }

    private fun activity(id: String, text: String) {
        mutate(id, persist = false) { it.copy(activity = text) }
        DeepThinkService.refresh(appCtx)
    }

    // ───────── 对外：新建 / 运行 / 暂停 / 删除 ─────────

    /** 新建一个长思，默认立即开始。返回编号。 */
    fun create(
        context: Context,
        topic: String,
        web: String = DiaSettings.deepWeb.value,
        autoApprove: Boolean = DiaSettings.deepAutoApprove.value,
        maxCycles: Int = 0,
        reviewFirst: Boolean = false,
        start: Boolean = true,
    ): String {
        init(context)
        val now = System.currentTimeMillis()
        val id = "d" + java.lang.Long.toString(now, 36)
        val safe = topic.trim().take(18).replace(Regex("[\\\\/:*?\"<>|\\s]+"), "_").trim('_').ifBlank { "长思" }
        val folder = File(root(), SimpleDateFormat("yyyyMMdd-HHmm", Locale.CHINA).format(Date(now)) + "_" + safe)
        folder.mkdirs()
        File(folder, "步骤").mkdirs()
        val s = DeepSession(
            id = id, topic = topic.trim(), createdAt = now, status = "idle", web = web, autoApprove = autoApprove,
            maxCycles = maxCycles, reviewFirst = reviewFirst, folder = folder.absolutePath,
        )
        _sessions.update { listOf(s) + it }
        save(s)
        try {
            File(folder, "日志.md").writeText("# 长思日志：${s.topic}\n\n开始于 ${timeFmt.format(Date(now))}\n\n")
        } catch (_: Exception) { }
        event(id, "system", "长思已创建：${s.topic}", "目录：灵犀AI/${AiFolder.rel(folder)}")
        if (start) start(id)
        return id
    }

    /** 开始 / 继续运行。 */
    fun start(id: String) {
        if (!isReady) return
        if (loops[id]?.isActive == true) return
        val s = get(id) ?: return
        if (s.status == "done") mutate(id) { it.copy(status = "paused", emptyReflections = 0) }
        val job = scope.launch { loop(id) }
        loops[id] = job
        DeepThinkService.refresh(appCtx)
    }

    /** 暂停（当前步骤会中断，下次继续时从这一步重新开始）。 */
    fun pause(id: String) {
        loops.remove(id)?.cancel()
        stepJobs.remove(id)?.cancel()
        confirmWaits.remove(id)?.complete(false)
        if (_confirm.value?.sessionId == id) _confirm.value = null
        mutate(id) { s ->
            s.copy(
                status = if (s.status == "done") "done" else "paused",
                plan = PlanOps.resetDoing(s.plan),
                currentStepId = null,
                activity = "已暂停",
            )
        }
        event(id, "system", "⏸ 已暂停")
        saveEvents(id)
        if (!ChatController.isGenerating.value) LlmGateway.cancelCurrent()
        DeepThinkService.refresh(appCtx)
    }

    /** 打断当前正在执行的步骤（它会回到待办，下一轮重新安排）。 */
    private fun interruptStep(id: String) {
        stepJobs[id]?.cancel()
        if (!ChatController.isGenerating.value) LlmGateway.cancelCurrent()
    }

    fun pauseAll() {
        for (id in loops.keys.toList()) pause(id)
    }

    fun delete(id: String, deleteFiles: Boolean) {
        pause(id)
        val s = get(id)
        _sessions.update { list -> list.filter { it.id != id } }
        eventFlows.remove(id)
        if (s != null) {
            scope.launch(Dispatchers.IO) {
                val dir = File(s.folder)
                if (deleteFiles) dir.deleteRecursively() else File(dir, "state.json").delete()
                AiFolder.touch()
            }
        }
    }

    /** 打开灵犀时继续上次没暂停的长思。 */
    fun resumeAll(context: Context) {
        init(context)
        if (!DiaSettings.deepResumeOnStart.value) return
        scope.launch {
            // 等列表从磁盘读出来
            var tries = 0
            while (_sessions.value.isEmpty() && tries++ < 20) delay(150)
            for (s in _sessions.value) {
                if ((s.status == "running" || s.status == "planning") && loops[s.id]?.isActive != true) {
                    event(s.id, "system", "▶ 灵犀重新打开，自动继续长思")
                    start(s.id)
                }
            }
        }
    }

    // ───────── 用户随时插话 / 改计划 ─────────

    fun addNote(id: String, text: String, urgent: Boolean = false) {
        val t = text.trim()
        if (t.isEmpty()) return
        val n = DeepNote(UUID.randomUUID().toString().take(8), t, System.currentTimeMillis(), urgent = urgent)
        val s = mutate(id) { it.copy(notes = it.notes + n) } ?: return
        event(id, "user", t, note = if (urgent) "立即处理" else "下一轮处理")
        appendFile(s, "日志.md", "\n> 【用户 ${timeFmt.format(Date())}】$t\n")
        if (urgent && isRunning(id)) {
            interruptStep(id)
            event(id, "system", "已打断当前步骤，先处理你的新指令")
        } else if (!isRunning(id) && s.status != "done") {
            // 暂停中收到消息：不自动开始，等用户点继续
            event(id, "system", "长思已暂停，点「继续」后会先处理这条消息")
        }
    }

    fun addStep(id: String, title: String, parentId: String? = null, afterId: String? = null, detail: String = "") {
        if (title.isBlank()) return
        mutate(id) { s ->
            val step = DeepStep("s${s.nextId}", title.trim(), detail.trim(), by = "user")
            s.copy(plan = PlanOps.insert(s.plan, step, parentId, afterId), nextId = s.nextId + 1,
                status = if (s.status == "done") "paused" else s.status)
        }
        event(id, "plan", "你新增了步骤：$title")
    }

    fun editStep(id: String, stepId: String, title: String, detail: String) {
        mutate(id) { s -> s.copy(plan = PlanOps.update(s.plan, stepId) { it.copy(title = title.trim().ifBlank { it.title }, detail = detail.trim()) }) }
        event(id, "plan", "你修改了步骤：$title")
    }

    fun setStepStatus(id: String, stepId: String, status: String) {
        val st = PlanOps.normalizeStatus(status)
        mutate(id) { s -> s.copy(plan = PlanOps.update(s.plan, stepId) { it.copy(status = st) }) }
        if (st == DeepStep.SKIP && get(id)?.currentStepId == stepId) interruptStep(id)
    }

    fun removeStep(id: String, stepId: String) {
        val title = get(id)?.plan?.let { PlanOps.find(it, stepId)?.title }.orEmpty()
        if (get(id)?.currentStepId == stepId) interruptStep(id)
        mutate(id) { s -> s.copy(plan = PlanOps.remove(s.plan, stepId)) }
        event(id, "plan", "你删除了步骤：$title")
    }

    fun moveStep(id: String, stepId: String, up: Boolean) {
        mutate(id) { s -> s.copy(plan = PlanOps.move(s.plan, stepId, up)) }
    }

    /** 修改长思的运行选项（联网方式 / 自动批准 / 轮数上限），下一轮生效。 */
    fun setOptions(id: String, web: String? = null, autoApprove: Boolean? = null, maxCycles: Int? = null) {
        mutate(id) { s ->
            s.copy(
                web = web ?: s.web,
                autoApprove = autoApprove ?: s.autoApprove,
                maxCycles = maxCycles ?: s.maxCycles,
            )
        }
        web?.let { event(id, "system", "联网方式改为：" + mapOf("auto" to "自行决定", "on" to "允许联网", "off" to "不联网")[it]) }
    }

    /** 改主题描述（下一轮生效）。 */
    fun setTopic(id: String, topic: String) {
        if (topic.isBlank()) return
        mutate(id) { it.copy(topic = topic.trim()) }
        event(id, "system", "主题改为：$topic")
    }

    /** 确认计划（「生成计划后先等我确认」时）。 */
    fun approvePlan(id: String) {
        mutate(id) { it.copy(status = "running") }
        event(id, "plan", "你确认了计划，开始执行")
        start(id)
    }

    /** 让 AI 把某一步细化成若干子步骤。 */
    fun refineStep(id: String, stepId: String) {
        scope.launch {
            val s = get(id) ?: return@launch
            val step = PlanOps.find(s.plan, stepId) ?: return@launch
            event(id, "plan", "AI 正在细化：${step.title}")
            val out = try {
                LlmGateway.complete(
                    system = "你是严谨的项目规划师。只输出编号列表。",
                    prompt = "【长思主题】${s.topic}\n【整体计划】\n${PlanOps.render(s.plan, stepId, 0)}\n\n" +
                        "请把步骤「${step.title}」${if (step.detail.isNotBlank()) "（${step.detail}）" else ""}细化成 2~5 个更具体、可直接执行的子步骤。" +
                        "每行「1. 标题：做什么、产出什么」。只输出列表。",
                    temperature = 0.3,
                    timeoutMs = 120_000,
                )
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                event(id, "error", "细化失败：${e.message}")
                return@launch
            }
            val items = PlanOps.parseOutline(out).map { Triple(0, it.second, it.third) }
            if (items.isEmpty()) { event(id, "error", "AI 没给出可用的子步骤"); return@launch }
            mutate(id) { cur ->
                val (kids, next) = PlanOps.build(items, cur.nextId)
                cur.copy(plan = PlanOps.update(cur.plan, stepId) { it.copy(children = it.children + kids, status = DeepStep.TODO) }, nextId = next)
            }
            event(id, "plan", "已把「${step.title}」细化为 ${items.size} 个子步骤")
        }
    }

    fun resolveConfirm(approved: Boolean) {
        val c = _confirm.value ?: return
        _confirm.value = null
        confirmWaits.remove(c.sessionId)?.complete(approved)
        event(c.sessionId, "confirm", if (approved) "✓ 你批准了：${c.title}" else "✗ 你驳回了：${c.title}")
    }

    // ───────── 给 AI 的工具 ─────────

    fun planTool(sessionId: String?, args: JSONObject): ToolOutcome {
        if (sessionId == null || get(sessionId) == null) {
            return ToolOutcome("plan 工具只能在自主长思里使用。要开启长思请用 deep_think。", ok = false)
        }
        val id: String = sessionId
        val action = args.optString("action").trim().lowercase().ifBlank { "view" }
        val s0 = get(id) ?: return ToolOutcome("长思不存在", ok = false)
        fun key(k: String): String? = args.optString(k).takeIf { it.isNotBlank() }?.let { PlanOps.resolveId(s0.plan, it) }
        fun stepList(): List<Triple<Int, String, String>> {
            val arr = args.optJSONArray("steps")
            if (arr != null) {
                return (0 until arr.length()).mapNotNull { i ->
                    val o = arr.optJSONObject(i)
                    if (o != null) {
                        val t = o.optString("title").ifBlank { o.optString("q") }.trim()
                        if (t.isBlank()) null else Triple(0, t, o.optString("detail").ifBlank { o.optString("note") })
                    } else arr.optString(i).trim().takeIf { it.isNotBlank() }?.let { Triple(0, it, "") }
                }
            }
            val text = args.optString("steps").ifBlank { args.optString("title") }
            if (text.contains('\n')) return PlanOps.parseOutline(text).map { Triple(0, it.second, it.third) }
            return if (text.isNotBlank()) listOf(Triple(0, text.trim(), args.optString("detail").ifBlank { args.optString("note") })) else emptyList()
        }
        return when (action) {
            "view", "show", "list" -> ToolOutcome(PlanOps.render(s0.plan, s0.currentStepId, 120))
            "add", "insert", "append" -> {
                val items = stepList()
                if (items.isEmpty()) return ToolOutcome("缺少要新增的步骤 title / steps", ok = false)
                val parent = key("parent")
                val after = key("after")
                mutate(id) { cur ->
                    var plan = cur.plan
                    var next = cur.nextId
                    var anchor = after
                    for ((_, t, d) in items) {
                        val st = DeepStep("s${next++}", t, d, by = "ai")
                        plan = PlanOps.insert(plan, st, parent, anchor)
                        anchor = st.id
                    }
                    cur.copy(plan = plan, nextId = next)
                }
                event(id, "plan", "AI 给自己新增了 ${items.size} 个步骤", items.joinToString("\n") { "· " + it.second })
                ToolOutcome("已新增 ${items.size} 个步骤。当前计划：\n" + PlanOps.render(get(id)!!.plan, get(id)!!.currentStepId, 0))
            }
            "split", "refine", "expand" -> {
                val target = key("id") ?: s0.currentStepId ?: return ToolOutcome("缺少要细化的步骤 id", ok = false)
                val items = stepList()
                if (items.isEmpty()) return ToolOutcome("缺少子步骤 steps", ok = false)
                mutate(id) { cur ->
                    val (kids, next) = PlanOps.build(items, cur.nextId)
                    cur.copy(plan = PlanOps.update(cur.plan, target) { it.copy(children = it.children + kids) }, nextId = next)
                }
                event(id, "plan", "AI 把步骤细化为 ${items.size} 个子步骤", items.joinToString("\n") { "· " + it.second })
                ToolOutcome("已细化。当前计划：\n" + PlanOps.render(get(id)!!.plan, get(id)!!.currentStepId, 0))
            }
            "update", "edit", "set", "mark" -> {
                val target = key("id") ?: return ToolOutcome("缺少步骤 id（如 s3 或 1.2）", ok = false)
                val title = args.optString("title").trim()
                val status = args.optString("status").trim()
                val note = args.optString("note").ifBlank { args.optString("detail") }.trim()
                mutate(id) { cur ->
                    cur.copy(plan = PlanOps.update(cur.plan, target) { st ->
                        st.copy(
                            title = title.ifBlank { st.title },
                            status = if (status.isNotBlank()) PlanOps.normalizeStatus(status) else st.status,
                            detail = if (note.isNotBlank()) note else st.detail,
                        )
                    })
                }
                event(id, "plan", "AI 更新了步骤 ${PlanOps.labelOf(get(id)!!.plan, target) ?: target}", listOf(title, status, note).filter { it.isNotBlank() }.joinToString(" · "))
                ToolOutcome("已更新。当前计划：\n" + PlanOps.render(get(id)!!.plan, get(id)!!.currentStepId, 0))
            }
            "remove", "delete" -> {
                val target = key("id") ?: return ToolOutcome("缺少步骤 id", ok = false)
                val t = PlanOps.find(s0.plan, target)?.title.orEmpty()
                mutate(id) { cur -> cur.copy(plan = PlanOps.remove(cur.plan, target)) }
                event(id, "plan", "AI 删除了步骤：$t")
                ToolOutcome("已删除「$t」。")
            }
            "move" -> {
                val target = key("id") ?: return ToolOutcome("缺少步骤 id", ok = false)
                val up = args.optString("note").ifBlank { args.optString("direction") }.lowercase().let { it == "up" || it.contains("上") }
                mutate(id) { cur -> cur.copy(plan = PlanOps.move(cur.plan, target, up)) }
                ToolOutcome("已${if (up) "上移" else "下移"}。")
            }
            else -> ToolOutcome("不支持的操作「$action」：可用 view / add / split / update / remove / move", ok = false)
        }
    }

    fun askUser(sessionId: String?, question: String): ToolOutcome {
        if (sessionId == null || get(sessionId) == null) return ToolOutcome("ask_user 只能在自主长思里使用；对话里直接问用户即可。", ok = false)
        if (question.isBlank()) return ToolOutcome("缺少问题 question", ok = false)
        event(sessionId, "question", question)
        get(sessionId)?.let { appendFile(it, "日志.md", "\n> 【AI 请示】$question\n") }
        DeepThinkService.notifyQuestion(appCtx, get(sessionId)?.topic.orEmpty(), question)
        return ToolOutcome("已把问题发给用户（不阻塞）。请先按最合理的假设继续推进，并在结论里写明你的假设；用户回复后会出现在【用户新消息】里。")
    }

    // ───────── 主循环 ─────────

    private suspend fun loop(id: String) {
        var errors = 0
        try {
            mutate(id) { if (it.status != "review") it.copy(status = "running") else it }
            event(id, "system", "▶ 长思开始运行")
            while (currentCoroutineContext().isActive) {
                val s = get(id) ?: break
                if (s.status == "paused" || s.status == "done") break
                if (s.status == "review") { activity(id, "等你确认计划…"); delay(1500); continue }
                if (!LlmGateway.isAvailable()) { activity(id, "等待模型加载（请在对话页选择模型）…"); delay(15_000); continue }
                // 礼让：本机模型同一时间只能跑一个推理，用户在对话时先让用户
                if (!LlmGateway.canParallel() && ChatController.isGenerating.value) { activity(id, "你正在对话，稍候继续…"); delay(1500); continue }
                if (s.maxCycles > 0 && s.cycles >= s.maxCycles) {
                    finish(id, "已达到设定的 ${s.maxCycles} 轮")
                    break
                }
                try {
                    if (s.plan.isEmpty()) {
                        makePlan(id)
                        continue
                    }
                    val step = PlanOps.nextTodo(s.plan)
                    if (step == null) {
                        val added = reflect(id)
                        if (added == 0) {
                            val cur = get(id) ?: break
                            if (!DiaSettings.deepEndless.value || cur.emptyReflections >= 3) {
                                finish(id, "计划已全部完成")
                                break
                            }
                        }
                        continue
                    }
                    coroutineScope {
                        val j = launch { runCycle(id, step) }
                        stepJobs[id] = j
                        j.join()
                        stepJobs.remove(id)
                        if (j.isCancelled && currentCoroutineContext().isActive) {
                            // 被用户「立即处理」或删除 / 跳过打断：这一步回到待办
                            mutate(id) { cur -> cur.copy(plan = PlanOps.resetDoing(cur.plan), currentStepId = null) }
                        }
                    }
                    errors = 0
                } catch (e: kotlinx.coroutines.CancellationException) {
                    throw e
                } catch (e: Exception) {
                    errors++
                    Log.w(TAG, "cycle error", e)
                    event(id, "error", "出错了：${e.message ?: e.javaClass.simpleName}", note = "第 $errors 次")
                    mutate(id) { cur -> cur.copy(plan = PlanOps.resetDoing(cur.plan), currentStepId = null) }
                    if (errors >= 6) {
                        mutate(id) { it.copy(status = "error", activity = "连续出错，已暂停：${e.message}") }
                        break
                    }
                    activity(id, "出错了，${10 * errors} 秒后重试…")
                    delay(10_000L * errors)
                }
                delay(DiaSettings.deepCycleDelay.value.coerceIn(0, 120) * 1000L)
            }
        } finally {
            // 只移除自己（暂停后马上继续时，新的循环已经登记了）
            currentCoroutineContext()[Job]?.let { me -> loops.remove(id, me) }
            saveEvents(id)
            DeepThinkService.refresh(appCtx)
        }
    }

    private fun finish(id: String, reason: String) {
        val s = mutate(id) { it.copy(status = "done", currentStepId = null, activity = reason) } ?: return
        event(id, "system", "✅ $reason", "总结与全部产出都在：灵犀AI/${AiFolder.rel(File(s.folder))}")
        scope.launch {
            try { writeReport(id) } catch (e: Exception) { Log.w(TAG, "report: ${e.message}") }
        }
    }

    private fun webLabel(web: String): String = when (web) {
        "off" -> "本次长思不联网，只用已有知识、文件和计算"
        "on" -> "可以随时联网（web_search / read_webpage / download）"
        else -> "需要最新信息或资料时自行联网（web_search / read_webpage），不需要时不必联网"
    }

    private fun mission(s: DeepSession): String = """
【自主长思模式】
你正在后台独立完成一个长期主题，身边没有人实时对话。系统每一轮交给你计划里的一个步骤，你要像一个能干的研究员 / 执行者一样把它真正做完：
- 怎么做由你决定：一切工具都已授权，可以连续、组合、多次调用。联网：${webLabel(s.web)}。
- 有价值的产出（资料摘录、数据、草稿、表格、代码、报告）写进你的工作目录：ai_files write/append，相对路径就是本长思目录（例如 资料/xxx.md、草稿/报告.md）；需要 Word/PPT/Excel/PDF 就写对应扩展名，或用 create_file。
- 计划不合适就直接改：plan add（加步骤）/ split（细化）/ update（改标题、标记完成或跳过）/ remove。你可以给自己下新命令，之后自己执行。
- 只有用户本人才能回答的问题用 ask_user 提出，然后按最合理的假设继续，不要停下来等。
- 【用户新消息】优先级最高：先落实用户的要求（需要就调整计划），再做本步。
- 不要重复已经完成的工作；读已有文件可以接上之前的进度。
- 本步结束时最后输出：
【本步结论】2~6 行要点（得到了什么、写了哪些文件）
【状态】完成  或  未完成：原因
""".trim()

    private fun cyclePrompt(s: DeepSession, step: DeepStep, notes: List<DeepNote>): String {
        val (done, total) = PlanOps.counts(s.plan)
        val label = PlanOps.labelOf(s.plan, step.id) ?: step.id
        val folder = File(s.folder)
        val files = try { AiFolder.list(folder, depth = 2, limit = 40) } catch (_: Exception) { "" }
        val recent = PlanOps.flatten(s.plan).filter { it.step.status == DeepStep.DONE && it.step.result.isNotBlank() }.takeLast(4)
        val attempt = s.attempts[step.id] ?: 0
        return buildString {
            append("【长思主题】").append(s.topic).append('\n')
            append("【进度】第 ").append(s.cycles).append(" 轮 · 已完成 ").append(done).append('/').append(total).append(" 步\n\n")
            append("【计划】（✓完成 ▶当前 ○待办 ⊘跳过 ✗失败）\n").append(PlanOps.render(s.plan, step.id, 60)).append("\n\n")
            append("【阶段总结】\n").append(s.summary.ifBlank { "（暂无，这是开头几步）" }).append("\n\n")
            if (recent.isNotEmpty()) {
                append("【最近完成的步骤】\n")
                for (r in recent) append("- ").append(r.label).append(' ').append(r.step.title).append("：").append(r.step.result.take(300)).append('\n')
                append('\n')
            }
            if (files.isNotBlank()) append("【工作目录（相对路径直接用）】\n").append(files).append("\n\n")
            if (notes.isNotEmpty()) {
                append("【用户新消息】（优先处理！）\n")
                for (n in notes) append("- ").append(timeFmt.format(Date(n.time))).append("：").append(n.text).append('\n')
                append('\n')
            }
            append("【本轮任务】[").append(step.id).append("] ").append(label).append(' ').append(step.title)
            if (step.detail.isNotBlank()) append(" —— ").append(step.detail)
            if (attempt > 0) append("\n（这一步之前没做完 ").append(attempt).append(" 次，换个方法，或把它拆小、或标记跳过并说明原因）")
            append("\n\n现在开始执行本轮任务。")
        }
    }

    private suspend fun runCycle(id: String, step: DeepStep) {
        val before = mutate(id) { s ->
            s.copy(
                plan = PlanOps.update(s.plan, step.id) { it.copy(status = DeepStep.DOING) },
                currentStepId = step.id,
                cycles = s.cycles + 1,
                activity = "执行 ${PlanOps.labelOf(s.plan, step.id) ?: ""} ${step.title}",
            )
        } ?: return
        val label = PlanOps.labelOf(before.plan, step.id) ?: step.id
        val notes = before.notes.filter { !it.handled }
        event(id, "cycle", "第 ${before.cycles} 轮 · $label ${step.title}", step.detail, note = if (notes.isNotEmpty()) "带上 ${notes.size} 条你的新消息" else "")
        DeepThinkService.refresh(appCtx)

        val listener = DeepListener(id)
        val started = System.currentTimeMillis()
        val text = DiaAgent.run(
            AgentRequest(
                history = emptyList(),
                userText = cyclePrompt(before, step, notes),
                extraSystem = mission(before),
                toolsOverride = AgentTools.deepNames(before.web),
                maxStepsOverride = DiaSettings.deepToolsPerStep.value,
                deep = true,
            ),
            listener,
        )
        // 这一轮正常结束才把带上的用户消息标记为已处理（被打断时下一轮还会带上）
        if (notes.isNotEmpty()) {
            val ids = notes.map { it.id }.toSet()
            mutate(id) { s -> s.copy(notes = s.notes.map { if (it.id in ids) it.copy(handled = true) else it }) }
        }
        val (conclusion, finished, reason) = parseOutcome(text)
        val cur = get(id) ?: return
        val nowStep = PlanOps.find(cur.plan, step.id)
        val attempts = (cur.attempts[step.id] ?: 0) + if (finished) 0 else 1
        val newStatus = when {
            nowStep == null -> null // 被删了
            nowStep.status == DeepStep.SKIP || nowStep.status == DeepStep.DONE -> nowStep.status // AI / 用户已经标记
            !nowStep.isLeaf -> DeepStep.TODO // 本轮被细化成子步骤：交给子步骤
            finished -> DeepStep.DONE
            attempts >= 3 -> DeepStep.FAILED
            else -> DeepStep.TODO
        }
        val updated = mutate(id) { s ->
            s.copy(
                plan = if (newStatus == null) s.plan else PlanOps.update(s.plan, step.id) {
                    it.copy(status = newStatus, result = conclusion.take(400).ifBlank { it.result })
                },
                currentStepId = null,
                attempts = s.attempts + (step.id to attempts),
                activity = if (finished) "完成 $label ${step.title}" else "未完成：${reason.take(40)}",
            )
        } ?: return
        event(id, "result", "${if (finished) "✓" else "…"} $label ${step.title}", conclusion.ifBlank { text.take(1500) },
            status = if (finished) "done" else "error", note = if (!finished) reason else "用时 ${(System.currentTimeMillis() - started) / 1000} 秒")

        // 写文件：本步全文 + 日志
        withContext(Dispatchers.IO) {
            try {
                val safe = step.title.take(24).replace(Regex("[\\\\/:*?\"<>|\\s]+"), "_")
                val f = File(File(updated.folder, "步骤"), "${label}_$safe.md")
                f.parentFile?.mkdirs()
                f.writeText(
                    "# $label ${step.title}\n\n第 ${before.cycles} 轮 · ${timeFmt.format(Date())} · ${if (finished) "完成" else "未完成：$reason"}\n\n" +
                        (if (step.detail.isNotBlank()) "> ${step.detail}\n\n" else "") + text.trim() + "\n\n## 工具记录\n\n" + listener.toolLog(),
                )
                appendFile(
                    updated, "日志.md",
                    "\n## 第 ${before.cycles} 轮 · ${timeFmt.format(Date())} · $label ${step.title}\n" +
                        (if (notes.isNotEmpty()) "- 处理了用户消息：${notes.joinToString("；") { it.text.take(60) }}\n" else "") +
                        (if (listener.toolNames().isNotEmpty()) "- 用了工具：${listener.toolNames().joinToString("、")}\n" else "") +
                        "- ${if (finished) "结论" else "未完成（$reason）"}：${conclusion.replace('\n', ' ').take(600)}\n",
                )
                AiFolder.touch()
            } catch (e: Exception) {
                Log.w(TAG, "write step: ${e.message}")
            }
        }
        saveEvents(id)
        // 每 3 轮（或计划刚做完）更新一次阶段总结
        val (d, t) = PlanOps.counts(updated.plan)
        if (updated.cycles % 3 == 0 || d == t) {
            try { updateSummary(id) } catch (e: kotlinx.coroutines.CancellationException) { throw e } catch (e: Exception) { Log.w(TAG, "summary: ${e.message}") }
        }
    }

    /** 从本步输出里取「本步结论」和「状态」。 */
    fun parseOutcome(text: String): Triple<String, Boolean, String> {
        val t = text.trim()
        val stateLine = Regex("【状态】\\s*(.+)").findAll(t).lastOrNull()?.groupValues?.get(1)?.trim()
            ?: Regex("状态[：:]\\s*(.+)").findAll(t).lastOrNull()?.groupValues?.get(1)?.trim()
        val unfinished = stateLine != null && (stateLine.startsWith("未完成") || stateLine.startsWith("失败"))
        val reason = if (unfinished) stateLine!!.removePrefix("未完成").removePrefix("失败").trimStart('：', ':', ' ').ifBlank { "没有说明原因" } else ""
        val concl = Regex("【本步结论】([\\s\\S]*?)(?=【状态】|$)").find(t)?.groupValues?.get(1)?.trim()
            ?: t.replace(Regex("【状态】.*"), "").trim().takeLast(600)
        return Triple(concl, !unfinished && t.isNotBlank(), reason)
    }

    // ───────── 规划 / 复盘 / 总结 ─────────

    private suspend fun makePlan(id: String) {
        val s = mutate(id) { it.copy(status = "planning", activity = "正在拆解主题、制定计划…") } ?: return
        event(id, "plan", "正在拆解主题、制定计划…")
        DeepThinkService.refresh(appCtx)
        var bg = ""
        if (s.web != "off" && DiaSettings.stepPreSearch.value) {
            activity(id, "先联网了解一下这个主题…")
            bg = withContext(Dispatchers.IO) {
                try {
                    val r = WebSearch.search(s.topic, 5)
                    r.hits.mapIndexed { i, h -> "[${i + 1}] ${h.title}：${h.snippet.take(200)}" }.joinToString("\n")
                } catch (_: Exception) { "" }
            }
        }
        val notes = s.notes.filter { !it.handled }.joinToString("\n") { "- " + it.text }
        val out = LlmGateway.complete(
            system = "你是顶尖的研究与项目规划师，擅长把一个大主题拆成清晰、可执行、循序渐进的步骤。只输出计划大纲。",
            prompt = buildString {
                append("【主题】").append(s.topic).append('\n')
                if (notes.isNotBlank()) append("【用户补充】\n").append(notes).append('\n')
                if (bg.isNotBlank()) append("【预检索资料】\n").append(bg).append('\n')
                append("\n请为这个主题制定一份由 AI 自己逐步执行的计划：\n")
                append("- 4~8 个一级步骤，复杂的步骤下面列 2~4 个子步骤（用 1. / 1.1 这样的编号，子步骤缩进两个空格）\n")
                append("- 每步一行：「编号 标题：做什么、产出什么（例如写进哪个文件）」\n")
                append("- 步骤要具体、可直接动手（查资料、整理、计算、写作、验证……），按先后顺序排列\n")
                append("- 最后一步一般是汇总成果，写成一份完整的报告 / 文件\n")
                append("只输出计划。")
            },
            temperature = 0.35,
            timeoutMs = 180_000,
        )
        var items = PlanOps.parseOutline(out)
        if (items.isEmpty()) {
            items = listOf(
                Triple(0, "弄清主题与目标", "界定范围、关键问题、成功标准"),
                Triple(0, "收集资料与事实", "检索、阅读、摘录要点到 资料/"),
                Triple(0, "分析与思考", "比较、推理、得出结论"),
                Triple(0, "产出成果", "写成完整的报告文件"),
            )
        }
        val cur = get(id) ?: return
        val (plan, next) = PlanOps.build(items, cur.nextId)
        val review = cur.reviewFirst
        mutate(id) { it.copy(plan = plan, nextId = next, status = if (review) "review" else "running", activity = if (review) "计划已生成，等你确认" else "计划已生成") }
        event(id, "plan", "计划已生成：${plan.size} 个一级步骤，共 ${PlanOps.counts(plan).second} 个具体步骤", PlanOps.render(plan, null, 0))
        if (review) DeepThinkService.notifyQuestion(appCtx, cur.topic, "计划已生成，请确认或修改后点「开始执行」")
    }

    /** 计划做完了：复盘并提出新步骤。返回新增的步骤数。 */
    private suspend fun reflect(id: String): Int {
        val s = mutate(id) { it.copy(activity = "计划已做完，正在复盘、寻找新的方向…") } ?: return 0
        event(id, "plan", "计划已做完，正在复盘、寻找值得继续深挖的方向…")
        val doneList = PlanOps.flatten(s.plan).filter { it.step.isLeaf }.joinToString("\n") { "- ${it.label} ${it.step.title}：${it.step.result.take(160)}" }
        val notes = s.notes.filter { !it.handled }.joinToString("\n") { "- " + it.text }
        val strong = s.emptyReflections > 0 || DiaSettings.deepEndless.value
        val out = LlmGateway.complete(
            system = "你是一个永不满足的研究者，善于复盘、发现漏洞、提出更有价值的下一步。只输出编号列表或「无」。",
            prompt = buildString {
                append("【长思主题】").append(s.topic).append('\n')
                append("【阶段总结】\n").append(s.summary.ifBlank { "（无）" }).append('\n')
                append("【已完成的步骤】\n").append(doneList.take(5000)).append('\n')
                if (notes.isNotBlank()) append("【用户新消息】\n").append(notes).append('\n')
                append("\n计划里的步骤都做完了。请复盘：哪些结论还不够扎实、哪里有遗漏、有什么更深一层或相关的问题值得研究、成果还能怎样做得更好（更完整的报告、表格、对比、可执行的清单、跟进最新变化…）。\n")
                append("提出接下来最有价值的 2~5 个新步骤（「1. 标题：做什么、产出什么」），不要重复已完成的。")
                if (strong) append("用户希望你持续思考、不要停止，请务必提出新的方向。") else append("如果主题确实已经穷尽，只输出「无」。")
            },
            temperature = 0.6,
            timeoutMs = 180_000,
        )
        val items = if (out.trim().startsWith("无") && out.trim().length < 6) emptyList() else PlanOps.parseOutline(out).map { Triple(0, it.second, it.third) }
        if (items.isEmpty()) {
            mutate(id) { it.copy(emptyReflections = it.emptyReflections + 1) }
            event(id, "plan", "复盘：暂时没有新的方向")
            return 0
        }
        val round = (PlanOps.flatten(s.plan).count { it.depth == 0 && it.step.title.startsWith("深挖") } + 1)
        mutate(id) { cur ->
            val (kids, next) = PlanOps.build(items, cur.nextId + 1)
            val parent = DeepStep("s${cur.nextId}", "深挖 · 第 $round 轮", "复盘后自己提出的新方向", children = kids)
            cur.copy(plan = cur.plan + parent, nextId = next, emptyReflections = 0)
        }
        event(id, "plan", "复盘后给自己新增了 ${items.size} 个步骤", items.joinToString("\n") { "· " + it.second })
        return items.size
    }

    private suspend fun updateSummary(id: String) {
        val s = get(id) ?: return
        val done = PlanOps.flatten(s.plan).filter { it.step.status == DeepStep.DONE && it.step.result.isNotBlank() }
        if (done.isEmpty()) return
        activity(id, "更新阶段总结…")
        val out = LlmGateway.complete(
            system = "你善于提炼要点，写简洁准确的阶段总结。",
            prompt = "【长思主题】${s.topic}\n【之前的阶段总结】\n${s.summary.ifBlank { "（无）" }}\n\n【各步骤结论】\n" +
                done.joinToString("\n") { "- ${it.label} ${it.step.title}：${it.step.result.take(300)}" }.take(7000) +
                "\n\n请更新阶段总结（不超过 500 字，要点式）：已经弄清了什么、产出了哪些文件、还缺什么 / 下一步重点。",
            temperature = 0.3,
            timeoutMs = 120_000,
        ).trim()
        if (out.isBlank()) return
        val u = mutate(id) { it.copy(summary = out) } ?: return
        withContext(Dispatchers.IO) {
            try {
                File(u.folder, "总结.md").writeText("# 阶段总结：${u.topic}\n\n更新于 ${timeFmt.format(Date())}（第 ${u.cycles} 轮）\n\n$out\n")
                AiFolder.touch()
            } catch (_: Exception) { }
        }
        event(id, "system", "📝 阶段总结已更新", out)
    }

    /** 结束时写一份完整的总结报告。 */
    private suspend fun writeReport(id: String) {
        val s = get(id) ?: return
        if (!LlmGateway.isAvailable()) return
        val done = PlanOps.flatten(s.plan).filter { it.step.result.isNotBlank() }
        val report = LlmGateway.complete(
            system = "你是资深的报告撰写人，把研究过程的结论整理成结构清晰、有理有据的 Markdown 报告。",
            prompt = "【主题】${s.topic}\n【阶段总结】\n${s.summary}\n\n【各步骤结论】\n" +
                done.joinToString("\n") { "- ${it.label} ${it.step.title}：${it.step.result.take(500)}" }.take(12000) +
                "\n\n请写一份完整的总结报告（Markdown：标题、摘要、主要发现、结论与建议、仍待研究的问题）。",
            temperature = 0.4,
            timeoutMs = 240_000,
        ).trim()
        if (report.isBlank()) return
        withContext(Dispatchers.IO) {
            File(s.folder, "总结报告.md").writeText(report + "\n")
            AiFolder.touch()
        }
        event(id, "result", "📄 已写好《总结报告.md》", report.take(3000), status = "done")
        saveEvents(id)
    }

    // ───────── 长思里的工具执行宿主 ─────────

    private class DeepListener(private val sid: String) : AgentListener {
        override val context: Context get() = appCtx
        override val wuji: Boolean get() = true
        override val deepSessionId: String get() = sid

        private val starts = ConcurrentHashMap<String, Long>()
        private val log = StringBuilder()
        private val names = LinkedHashSet<String>()
        @Volatile private var current: String? = null

        fun toolLog(): String = synchronized(log) { log.toString().ifBlank { "（本步没有调用工具）" } }
        fun toolNames(): List<String> = synchronized(names) { names.toList() }

        override fun onText(text: String) {}
        override fun onThought(delta: String) {}

        override fun onToolStart(name: String, title: String): String =
            onToolCall(name, title, JSONObject(), "", 0, false)

        override fun onToolCall(name: String, title: String, args: JSONObject, reason: String, stepNo: Int, byUser: Boolean): String {
            val eid = event(sid, "tool", (if (stepNo > 0) "步骤 $stepNo · " else "") + title, args.toString(2).take(3000), "running", reason, name)
            starts[eid] = System.currentTimeMillis()
            current = eid
            synchronized(names) { names.add(AgentTools.spec(name)?.title ?: name) }
            activity(sid, (if (reason.isNotBlank()) "$reason → " else "") + title)
            return eid
        }

        override fun onToolEnd(cardId: String, outcome: ToolOutcome) {
            val ms = System.currentTimeMillis() - (starts.remove(cardId) ?: System.currentTimeMillis())
            updateEvent(sid, cardId) {
                it.copy(status = if (outcome.ok) "done" else "error", detail = (it.detail + "\n\n── 结果 ──\n" + outcome.display).take(6000), durationMs = ms)
            }
            val title = eventFlows[sid]?.value?.firstOrNull { it.id == cardId }?.title.orEmpty()
            synchronized(log) {
                log.append("- ").append(if (outcome.ok) "✓ " else "✗ ").append(title).append("（").append(ms / 1000.0).append("s）：")
                    .append(outcome.forModel.replace('\n', ' ').take(240)).append('\n')
            }
            if (current == cardId) current = null
        }

        override fun progress(text: String) {
            val c = current ?: return
            updateEvent(sid, c) { it.copy(note = text) }
        }

        override suspend fun confirm(title: String, detail: String): Boolean {
            val s = get(sid)
            if (s == null || s.autoApprove) {
                event(sid, "confirm", "⚡ 已自动批准：$title", detail, "approved")
                return true
            }
            val d = CompletableDeferred<Boolean>()
            confirmWaits[sid] = d
            _confirm.value = DeepConfirm(sid, title, detail)
            event(sid, "confirm", "等待你批准：$title", detail, "pending")
            activity(sid, "等待你批准：$title")
            DeepThinkService.notifyQuestion(appCtx, s.topic, "需要你批准：$title")
            return try {
                d.await()
            } finally {
                confirmWaits.remove(sid)
                if (_confirm.value?.sessionId == sid) _confirm.value = null
            }
        }

        override fun moveAppToBack() {
            ChatController.emitEvent("move_to_back")
        }
    }
}
