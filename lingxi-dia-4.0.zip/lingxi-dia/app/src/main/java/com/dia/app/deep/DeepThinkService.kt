package com.dia.app.deep

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.dia.app.MainActivity
import com.dia.app.R

/**
 * 自主长思的前台服务：只要还有长思在运行，就保持灵犀在后台活着（常驻通知 + 部分唤醒锁），
 * 通知上显示「主题 · 第几轮 · 正在做什么」，可以一键暂停全部。没有长思在跑时自动停止。
 */
class DeepThinkService : Service() {

    companion object {
        private const val TAG = "DeepThinkService"
        private const val CHANNEL_ID = "dia_deep_channel"
        private const val CHANNEL_ASK = "dia_deep_ask"
        private const val NOTIFICATION_ID = 4812
        private const val ASK_ID = 4813
        const val ACTION_PAUSE_ALL = "com.dia.app.deep.PAUSE_ALL"
        const val EXTRA_OPEN_DEEP = "open_deep"
        private const val WAKELOCK_TAG = "Dia::DeepThink"

        @Volatile private var running = false
        @Volatile private var lastUpdate = 0L
        @Volatile private var lastRenew = 0L

        /** 根据当前是否有长思在运行，启动 / 更新 / 停止服务。可以频繁调用（内部节流）。 */
        fun refresh(context: Context) {
            val ctx = context.applicationContext
            val n = DeepEngine.runningCount()
            if (n == 0) {
                if (running) {
                    try { ctx.stopService(Intent(ctx, DeepThinkService::class.java)) } catch (_: Exception) { }
                }
                return
            }
            if (!running) {
                try {
                    val i = Intent(ctx, DeepThinkService::class.java)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) ctx.startForegroundService(i) else ctx.startService(i)
                } catch (e: Exception) {
                    Log.w(TAG, "start blocked: ${e.message}")
                }
                return
            }
            val now = System.currentTimeMillis()
            if (now - lastRenew > 10 * 60_000L) {
                // 定期续唤醒锁（onStartCommand 里重新 acquire）
                lastRenew = now
                try { ctx.startService(Intent(ctx, DeepThinkService::class.java)) } catch (_: Exception) { }
            }
            if (now - lastUpdate < 1500) return
            lastUpdate = now
            try {
                val mgr = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                mgr.notify(NOTIFICATION_ID, build(ctx))
            } catch (_: Exception) { }
        }

        private fun openIntent(ctx: Context): PendingIntent {
            val open = Intent(ctx, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                putExtra(EXTRA_OPEN_DEEP, true)
            }
            return PendingIntent.getActivity(ctx, 21, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        }

        private fun ensureChannels(ctx: Context) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
            val mgr = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (mgr.getNotificationChannel(CHANNEL_ID) == null) {
                mgr.createNotificationChannel(NotificationChannel(CHANNEL_ID, "灵犀 · 自主长思", NotificationManager.IMPORTANCE_LOW).apply {
                    description = "自主长思在后台运行时显示"
                    setShowBadge(false)
                })
            }
            if (mgr.getNotificationChannel(CHANNEL_ASK) == null) {
                mgr.createNotificationChannel(NotificationChannel(CHANNEL_ASK, "灵犀 · 长思请示", NotificationManager.IMPORTANCE_DEFAULT).apply {
                    description = "长思需要你回答问题或批准操作时提醒"
                })
            }
        }

        private fun build(ctx: Context): Notification {
            ensureChannels(ctx)
            val active = DeepEngine.sessions.value.filter { DeepEngine.isRunning(it.id) }
            val first = active.firstOrNull()
            val title = if (active.size > 1) "灵犀 · ${active.size} 个长思运行中" else "灵犀 · 自主长思中"
            val text = first?.let { s ->
                val (d, t) = PlanOps.counts(s.plan)
                "${s.topic.take(20)} · 第 ${s.cycles} 轮 · $d/$t · ${s.activity.take(40)}"
            } ?: "运行中…"
            val pause = Intent(ctx, DeepThinkService::class.java).setAction(ACTION_PAUSE_ALL)
            val pausePi = PendingIntent.getService(ctx, 22, pause, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            return NotificationCompat.Builder(ctx, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_dia_logo)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(NotificationCompat.BigTextStyle().bigText(text))
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(openIntent(ctx))
                .addAction(0, "全部暂停", pausePi)
                .build()
        }

        /** 长思需要用户回答 / 批准时，弹一条普通通知。 */
        fun notifyQuestion(context: Context, topic: String, question: String) {
            val ctx = context.applicationContext
            if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) return
            try {
                ensureChannels(ctx)
                val n = NotificationCompat.Builder(ctx, CHANNEL_ASK)
                    .setSmallIcon(R.drawable.ic_dia_logo)
                    .setContentTitle("长思「${topic.take(16)}」请示")
                    .setContentText(question)
                    .setStyle(NotificationCompat.BigTextStyle().bigText(question))
                    .setAutoCancel(true)
                    .setContentIntent(openIntent(ctx))
                    .build()
                val mgr = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                mgr.notify(ASK_ID, n)
            } catch (_: Exception) { }
        }
    }

    private var wakeLock: PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        val n = build(this)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(NOTIFICATION_ID, n)
            }
        } catch (e: Exception) {
            Log.w(TAG, "startForeground failed: ${e.message}")
        }
        acquireWakeLock()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_PAUSE_ALL) {
            DeepEngine.pauseAll()
            stopSelf()
            return START_NOT_STICKY
        }
        if (DeepEngine.runningCount() == 0) {
            stopSelf()
            return START_NOT_STICKY
        }
        acquireWakeLock()
        try {
            val mgr = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            mgr.notify(NOTIFICATION_ID, build(this))
        } catch (_: Exception) { }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        try { wakeLock?.takeIf { it.isHeld }?.release() } catch (_: Exception) { }
        wakeLock = null
        running = false
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun acquireWakeLock() {
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            val lock = wakeLock ?: pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, WAKELOCK_TAG).also {
                it.setReferenceCounted(false)
                wakeLock = it
            }
            // 每次刷新续 30 分钟；长思一直跑就一直续
            lock.acquire(30 * 60 * 1000L)
        } catch (e: Exception) {
            Log.w(TAG, "wakelock: ${e.message}")
        }
    }
}
