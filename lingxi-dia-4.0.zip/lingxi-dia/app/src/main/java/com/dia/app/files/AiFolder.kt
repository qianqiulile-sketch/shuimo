package com.dia.app.files

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.util.Log
import androidx.core.content.FileProvider
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 灵犀 AI 的专属文件夹：AI 自己生成的一切都放在这里。
 *
 * ```
 * 灵犀AI/
 *   作品/   新建 / 转换 / 另存的文档（Word、PPT、Excel、PDF、Markdown…）
 *   图片/   生成的图片
 *   长思/   每个「自主长思」一个子目录：计划、日志、阶段总结、各步产出
 *   转写/   语音转文字的结果
 *   笔记/   AI 自己记的笔记、草稿
 *   主题/   导出的主题包
 * ```
 *
 * 位置：开启「所有文件访问」后放在手机存储根目录 `/灵犀AI`（任何文件管理器都能看到）；
 * 否则放在应用专属目录 `Android/data/com.dia.app/files/灵犀AI`（不需要任何权限，App 内「AI 文件夹」可浏览、分享、导出）。
 * 权限开启后会自动把旧目录里的内容搬到根目录。
 */
object AiFolder {

    private const val TAG = "AiFolder"
    const val NAME = "灵犀AI"

    val SUBDIRS = listOf("作品", "图片", "长思", "转写", "笔记", "主题")

    private lateinit var appCtx: Context

    /** 每次目录内容变化时 +1，界面据此刷新。 */
    private val _version = MutableStateFlow(0L)
    val version: StateFlow<Long> = _version.asStateFlow()

    fun init(context: Context) {
        if (::appCtx.isInitialized) return
        appCtx = context.applicationContext
        try {
            migrateIfNeeded()
            ensureLayout()
        } catch (e: Exception) {
            Log.w(TAG, "init: ${e.message}")
        }
    }

    val isReady: Boolean get() = ::appCtx.isInitialized

    fun touch() { _version.value = _version.value + 1 }

    private fun privateRoot(): File =
        File(appCtx.getExternalFilesDir(null) ?: appCtx.filesDir, NAME)

    @Suppress("DEPRECATION")
    private fun publicRoot(): File = File(Environment.getExternalStorageDirectory(), NAME)

    private fun canUsePublic(): Boolean =
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && Environment.isExternalStorageManager()

    /** 当前的根目录。 */
    fun root(): File {
        val r = if (canUsePublic()) publicRoot() else privateRoot()
        if (!r.exists()) r.mkdirs()
        return r
    }

    /** 根目录是否在公共存储（用户用任何文件管理器都能看到）。 */
    fun isPublic(): Boolean = canUsePublic()

    /** 给用户看的位置描述。 */
    fun locationLabel(): String = if (isPublic()) "手机存储/$NAME" else "App 内「AI 文件夹」（Android/data/com.dia.app/files/$NAME）"

    fun dir(sub: String): File = File(root(), sub).apply { mkdirs() }

    private fun ensureLayout() {
        val r = root()
        for (s in SUBDIRS) File(r, s).mkdirs()
        val readme = File(r, "说明.txt")
        if (!readme.exists()) {
            readme.writeText(
                "这里是灵犀 AI 的专属文件夹，AI 自己生成的文件都会放在这里：\n" +
                    "作品/ 文档；图片/ 生成的图片；长思/ 自主长思的计划、日志与产出；转写/ 语音转文字；笔记/ AI 的笔记；主题/ 导出的主题包。\n" +
                    "可以随意查看、复制；删除前请确认不再需要。\n",
            )
        }
    }

    /** 开启「所有文件访问」后，把应用专属目录里的内容搬到公共目录（只做一次）。 */
    fun migrateIfNeeded() {
        if (!canUsePublic()) return
        val from = privateRoot()
        if (!from.exists() || from.listFiles().isNullOrEmpty()) return
        val to = publicRoot()
        try {
            to.mkdirs()
            from.walkTopDown().forEach { f ->
                val rel = f.relativeTo(from).path
                if (rel.isEmpty()) return@forEach
                val dst = File(to, rel)
                if (f.isDirectory) dst.mkdirs()
                else if (!dst.exists()) { dst.parentFile?.mkdirs(); f.copyTo(dst) }
            }
            from.deleteRecursively()
            touch()
        } catch (e: Exception) {
            Log.w(TAG, "migrate failed: ${e.message}")
        }
    }

    // ───────── 路径解析（AI 用相对路径读写，禁止跳出根目录） ─────────

    /**
     * 把 AI 给的路径解析成根目录里的文件。
     * @param base 相对路径的起点（长思时是该长思的目录），默认根目录
     */
    fun resolve(path: String, base: File? = null): File {
        val root = root().canonicalFile
        val clean = path.trim().replace('\\', '/').removePrefix("灵犀AI/").removePrefix("/灵犀AI/")
        val start = (base ?: root)
        val f = when {
            clean.isEmpty() || clean == "." || clean == "/" -> start
            clean.startsWith("/") && File(clean).canonicalPath.startsWith(root.path) -> File(clean)
            clean.startsWith("~/") -> File(root, clean.removePrefix("~/"))
            else -> File(start, clean.trimStart('/'))
        }.canonicalFile
        if (!f.path.startsWith(root.path)) throw IllegalArgumentException("只能访问「$NAME」文件夹里的文件：$path")
        return f
    }

    /** 相对根目录的显示路径，如「长思/xxx/计划.md」。 */
    fun rel(f: File): String = try {
        f.canonicalFile.relativeTo(root().canonicalFile).path.ifEmpty { "." }
    } catch (_: Exception) {
        f.name
    }

    /** 重名时自动加序号。 */
    fun unique(dir: File, name: String): File {
        val clean = name.trim().replace(Regex("[\\\\/:*?\"<>|]"), "_").ifBlank { "未命名.txt" }
        var f = File(dir, clean)
        var n = 1
        val base = clean.substringBeforeLast('.', clean)
        val ext = clean.substringAfterLast('.', "")
        while (f.exists()) {
            f = File(dir, if (ext.isEmpty()) "$base($n)" else "$base($n).$ext"); n++
        }
        return f
    }

    /** 把生成的字节存到某个子目录，返回文件。 */
    fun save(sub: String, name: String, data: ByteArray): File {
        val f = unique(dir(sub), name)
        f.writeBytes(data)
        touch()
        return f
    }

    /** 把已有文件复制一份到 AI 文件夹（例如生成的图片）。 */
    fun saveCopy(src: String, sub: String, name: String? = null): File? = try {
        val s = File(src)
        if (!s.exists()) null else {
            val f = unique(dir(sub), name ?: s.name)
            s.copyTo(f)
            touch()
            f
        }
    } catch (e: Exception) {
        Log.w(TAG, "saveCopy: ${e.message}")
        null
    }

    // ───────── 给 AI 用的文件操作 ─────────

    private val fmt = SimpleDateFormat("MM-dd HH:mm", Locale.CHINA)

    fun list(dir: File, depth: Int = 1, limit: Int = 120): String {
        if (!dir.exists()) return "${rel(dir)}（不存在）"
        if (dir.isFile) return info(dir)
        val sb = StringBuilder()
        sb.append("📂 ").append(rel(dir)).append('\n')
        var count = 0
        fun walk(d: File, prefix: String, level: Int) {
            val items = d.listFiles()?.sortedWith(compareBy<File>({ !it.isDirectory }, { -it.lastModified() })).orEmpty()
            for (f in items) {
                if (count >= limit) return
                count++
                if (f.isDirectory) {
                    sb.append(prefix).append("📁 ").append(f.name).append("/\n")
                    if (level < depth) walk(f, "$prefix  ", level + 1)
                } else {
                    sb.append(prefix).append("📄 ").append(f.name).append("  ")
                        .append(sizeLabel(f.length())).append("  ").append(fmt.format(Date(f.lastModified()))).append('\n')
                }
            }
        }
        walk(dir, "  ", 1)
        if (count == 0) sb.append("  （空）\n")
        if (count >= limit) sb.append("  …（只列出前 $limit 项）\n")
        return sb.toString().trimEnd()
    }

    fun info(f: File): String =
        "${rel(f)}  ${if (f.isDirectory) "目录" else sizeLabel(f.length())}  修改于 ${fmt.format(Date(f.lastModified()))}"

    fun sizeLabel(n: Long): String = when {
        n < 1024 -> "${n}B"
        n < 1024 * 1024 -> "${n / 1024}KB"
        else -> String.format(Locale.US, "%.1fMB", n / 1024.0 / 1024.0)
    }

    /** 文件在系统里的 Uri（分享 / 用其它应用打开）。 */
    fun uriFor(context: Context, f: File): Uri =
        FileProvider.getUriForFile(context, context.packageName + ".files", f)

    fun openIntent(context: Context, f: File): Intent {
        val uri = uriFor(context, f)
        return Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, FileManager.guessMime(f.name))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }

    fun shareIntent(context: Context, f: File): Intent {
        val uri = uriFor(context, f)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = FileManager.guessMime(f.name)
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        return Intent.createChooser(send, "分享 ${f.name}").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    /** 文本类文件（AI 可以直接读写）。 */
    fun isText(f: File): Boolean = f.extension.lowercase() in FileManager.TEXT_EXTS || f.extension.isEmpty()
}
