package com.dia.app.files

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Word(docx) / PPT(pptx) / Excel(xlsx) 的读取与编辑。
 *
 * 这几种格式本质是 zip + XML，这里直接处理 XML 文本：
 *  - 读取：按段落拼出纯文本
 *  - 替换：在段落内替换文字；若要替换的内容跨越多个 run，会合并到第一个 run（其余 run 清空）
 *  - 追加 / 重写（仅 docx）
 *
 * 纯 Kotlin + java.util.zip，不依赖 Android，便于单元测试。
 */
object OfficeXml {

    // ───────── zip 工具 ─────────

    fun unzip(bytes: ByteArray): LinkedHashMap<String, ByteArray> {
        val map = LinkedHashMap<String, ByteArray>()
        ZipInputStream(ByteArrayInputStream(bytes)).use { zis ->
            while (true) {
                val e = zis.nextEntry ?: break
                if (!e.isDirectory) map[e.name] = zis.readBytes()
                zis.closeEntry()
            }
        }
        return map
    }

    fun zip(entries: LinkedHashMap<String, ByteArray>): ByteArray {
        val bos = ByteArrayOutputStream()
        ZipOutputStream(bos).use { zos ->
            // [Content_Types].xml 放第一个（Office 习惯）
            val ordered = entries.keys.sortedBy { if (it == "[Content_Types].xml") 0 else 1 }
            for (name in ordered) {
                zos.putNextEntry(ZipEntry(name))
                zos.write(entries.getValue(name))
                zos.closeEntry()
            }
        }
        return bos.toByteArray()
    }

    fun isZip(bytes: ByteArray): Boolean =
        bytes.size > 4 && bytes[0] == 'P'.code.toByte() && bytes[1] == 'K'.code.toByte()

    // ───────── XML 转义 ─────────

    private val numEntity = Regex("&#(x?)([0-9a-fA-F]{1,6});")

    fun unescape(s: String): String {
        if (!s.contains('&')) return s
        val t = numEntity.replace(s) { m ->
            val code = if (m.groupValues[1].isNotEmpty()) m.groupValues[2].toIntOrNull(16) else m.groupValues[2].toIntOrNull()
            if (code != null && code in 1..0x10FFFF) String(Character.toChars(code)) else m.value
        }
        return t.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"")
            .replace("&apos;", "'").replace("&amp;", "&")
    }

    fun escape(s: String): String = s
        .replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    // ───────── 通用：段落 / 文本节点 ─────────

    /** 描述一种格式里「段落」和「文本」标签的名字。 */
    private class Dialect(val para: String, val text: String) {
        val paraRe = Regex("<$para(?:\\s[^>]*)?/>|<$para(?:\\s[^>]*)?>([\\s\\S]*?)</$para>")
        val textRe = Regex("<$text(\\s[^>]*)?>([^<]*)</$text>")
    }

    private val WORD = Dialect("w:p", "w:t")
    private val DRAWING = Dialect("a:p", "a:t")

    private fun paragraphsText(xml: String, d: Dialect, extra: (String) -> String = { it }): List<String> {
        val out = ArrayList<String>()
        for (m in d.paraRe.findAll(xml)) {
            val inner = m.groupValues.getOrNull(1).orEmpty()
            val sb = StringBuilder()
            // 文本、制表、换行按出现顺序拼接
            val tokenRe = Regex("<${d.text}(?:\\s[^>]*)?>([^<]*)</${d.text}>|<w:tab/>|<w:br/>|<a:br/>")
            for (t in tokenRe.findAll(extra(inner))) {
                when {
                    t.value == "<w:tab/>" -> sb.append('\t')
                    t.value == "<w:br/>" || t.value == "<a:br/>" -> sb.append('\n')
                    else -> sb.append(unescape(t.groupValues[1]))
                }
            }
            out.add(sb.toString())
        }
        return out
    }

    /**
     * 在 [xml] 的每个段落里把 [find] 换成 [replacement]。
     * @return (新 xml, 替换次数)
     */
    private fun replaceInXml(xml: String, d: Dialect, find: String, replacement: String): Pair<String, Int> {
        if (find.isEmpty()) return xml to 0
        var total = 0
        val result = d.paraRe.replace(xml) { pm ->
            val para = pm.value
            val texts = d.textRe.findAll(para).toList()
            if (texts.isEmpty()) return@replace para
            val segs = texts.map { unescape(it.groupValues[2]) }
            val joined = segs.joinToString("")
            val count = countOccurrences(joined, find)
            if (count == 0) return@replace para
            total += count
            val perSeg = segs.sumOf { countOccurrences(it, find) }
            val newSegs: List<String> = if (perSeg == count) {
                segs.map { it.replace(find, replacement) }
            } else {
                // 跨 run：整段合并进第一个文本节点
                listOf(joined.replace(find, replacement)) + List(segs.size - 1) { "" }
            }
            rebuildTexts(para, d, texts, newSegs)
        }
        return result to total
    }

    private fun rebuildTexts(para: String, d: Dialect, texts: List<MatchResult>, newSegs: List<String>): String {
        val sb = StringBuilder()
        var last = 0
        for ((i, m) in texts.withIndex()) {
            sb.append(para, last, m.range.first)
            var attrs = m.groupValues[1]
            val content = newSegs[i]
            if (d.text == "w:t" && !attrs.contains("xml:space")) attrs = "$attrs xml:space=\"preserve\""
            sb.append("<").append(d.text).append(attrs).append(">")
                .append(escape(content))
                .append("</").append(d.text).append(">")
            last = m.range.last + 1
        }
        sb.append(para, last, para.length)
        return sb.toString()
    }

    fun countOccurrences(s: String, find: String): Int {
        if (find.isEmpty()) return 0
        var i = 0
        var n = 0
        while (true) {
            val j = s.indexOf(find, i)
            if (j < 0) break
            n++
            i = j + find.length
        }
        return n
    }

    // ───────── DOCX ─────────

    fun docxText(bytes: ByteArray): String {
        val entries = unzip(bytes)
        val doc = entries["word/document.xml"]?.toString(Charsets.UTF_8) ?: return ""
        val sb = StringBuilder()
        for (p in paragraphsText(doc, WORD)) sb.append(p).append('\n')
        // 页眉页脚 / 脚注里的文字放在后面
        for ((name, data) in entries) {
            if (name.startsWith("word/header") || name.startsWith("word/footer") || name == "word/footnotes.xml") {
                val t = paragraphsText(data.toString(Charsets.UTF_8), WORD).filter { it.isNotBlank() }
                if (t.isNotEmpty()) sb.append("\n[").append(name.substringAfterLast('/')).append("]\n").append(t.joinToString("\n")).append('\n')
            }
        }
        return sb.toString().trimEnd()
    }

    fun docxReplace(bytes: ByteArray, find: String, replacement: String): Pair<ByteArray, Int> {
        val entries = unzip(bytes)
        var total = 0
        for (name in entries.keys.toList()) {
            val isPart = name == "word/document.xml" || name.startsWith("word/header") ||
                name.startsWith("word/footer") || name == "word/footnotes.xml"
            if (!isPart) continue
            val xml = entries.getValue(name).toString(Charsets.UTF_8)
            val (nx, n) = replaceInXml(xml, WORD, find, replacement)
            if (n > 0) {
                entries[name] = nx.toByteArray(Charsets.UTF_8)
                total += n
            }
        }
        return (if (total > 0) zip(entries) else bytes) to total
    }

    private fun wordParagraph(line: String): String =
        "<w:p><w:r><w:t xml:space=\"preserve\">${escape(line)}</w:t></w:r></w:p>"

    /** body 级 sectPr 的位置（必须保持为 body 的最后一个子元素）。 */
    private fun bodyInsertIndex(doc: String): Int {
        val bodyEnd = doc.lastIndexOf("</w:body>")
        if (bodyEnd < 0) return -1
        val sect = doc.lastIndexOf("<w:sectPr", bodyEnd)
        if (sect >= 0 && doc.indexOf("</w:p>", sect) == -1 || (sect >= 0 && doc.indexOf("</w:p>", sect) > bodyEnd)) {
            return sect
        }
        return bodyEnd
    }

    fun docxAppend(bytes: ByteArray, text: String): ByteArray {
        val entries = unzip(bytes)
        val doc = entries["word/document.xml"]?.toString(Charsets.UTF_8)
            ?: throw IllegalArgumentException("不是有效的 Word 文档")
        val idx = bodyInsertIndex(doc)
        if (idx < 0) throw IllegalArgumentException("文档结构异常")
        val paras = text.split('\n').joinToString("") { wordParagraph(it) }
        val nx = doc.substring(0, idx) + paras + doc.substring(idx)
        entries["word/document.xml"] = nx.toByteArray(Charsets.UTF_8)
        return zip(entries)
    }

    /** 用新文本重写正文（保留页面设置，丢弃原有表格 / 格式）。 */
    fun docxRewrite(bytes: ByteArray, text: String): ByteArray {
        val entries = unzip(bytes)
        val doc = entries["word/document.xml"]?.toString(Charsets.UTF_8)
            ?: throw IllegalArgumentException("不是有效的 Word 文档")
        val bodyOpen = Regex("<w:body(?:\\s[^>]*)?>").find(doc) ?: throw IllegalArgumentException("文档结构异常")
        val start = bodyOpen.range.last + 1
        val end = bodyInsertIndex(doc)
        if (end < start) throw IllegalArgumentException("文档结构异常")
        val paras = text.split('\n').joinToString("") { wordParagraph(it) }
        val nx = doc.substring(0, start) + paras + doc.substring(end)
        entries["word/document.xml"] = nx.toByteArray(Charsets.UTF_8)
        return zip(entries)
    }

    /** 从纯文本新建一个最小的 Word 文档。 */
    fun docxCreate(text: String): ByteArray {
        val entries = LinkedHashMap<String, ByteArray>()
        entries["[Content_Types].xml"] = ("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
            "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
            "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
            "<Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/>" +
            "</Types>").toByteArray(Charsets.UTF_8)
        entries["_rels/.rels"] = ("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
            "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/>" +
            "</Relationships>").toByteArray(Charsets.UTF_8)
        val body = text.split('\n').joinToString("") { wordParagraph(it) }
        entries["word/document.xml"] = ("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\">" +
            "<w:body>$body<w:sectPr><w:pgSz w:w=\"11906\" w:h=\"16838\"/>" +
            "<w:pgMar w:top=\"1440\" w:right=\"1800\" w:bottom=\"1440\" w:left=\"1800\" w:header=\"851\" w:footer=\"992\" w:gutter=\"0\"/>" +
            "</w:sectPr></w:body></w:document>").toByteArray(Charsets.UTF_8)
        return zip(entries)
    }

    // ───────── PPTX ─────────

    private fun slideNames(entries: Map<String, ByteArray>): List<String> =
        entries.keys.filter { Regex("ppt/slides/slide\\d+\\.xml").matches(it) }
            .sortedBy { Regex("\\d+").find(it.substringAfterLast("slide"))?.value?.toIntOrNull() ?: 0 }

    fun pptxText(bytes: ByteArray): String {
        val entries = unzip(bytes)
        val sb = StringBuilder()
        for ((i, name) in slideNames(entries).withIndex()) {
            val xml = entries.getValue(name).toString(Charsets.UTF_8)
            val paras = paragraphsText(xml, DRAWING).filter { it.isNotBlank() }
            sb.append("【第${i + 1}页】\n")
            sb.append(paras.joinToString("\n")).append("\n\n")
            val notesName = "ppt/notesSlides/notesSlide${name.substringAfterLast("slide").substringBefore(".xml")}.xml"
            entries[notesName]?.let { nb ->
                val notes = paragraphsText(nb.toString(Charsets.UTF_8), DRAWING)
                    .filter { it.isNotBlank() && it.toIntOrNull() == null }
                if (notes.isNotEmpty()) sb.append("（备注）").append(notes.joinToString(" ")).append("\n\n")
            }
        }
        return sb.toString().trimEnd()
    }

    fun pptxReplace(bytes: ByteArray, find: String, replacement: String): Pair<ByteArray, Int> {
        val entries = unzip(bytes)
        var total = 0
        for (name in slideNames(entries)) {
            val xml = entries.getValue(name).toString(Charsets.UTF_8)
            val (nx, n) = replaceInXml(xml, DRAWING, find, replacement)
            if (n > 0) {
                entries[name] = nx.toByteArray(Charsets.UTF_8)
                total += n
            }
        }
        return (if (total > 0) zip(entries) else bytes) to total
    }

    // ───────── XLSX ─────────

    private val siRe = Regex("<si(?:\\s[^>]*)?>([\\s\\S]*?)</si>")
    private val tRe = Regex("<t(\\s[^>]*)?>([^<]*)</t>")

    private fun sharedStrings(entries: Map<String, ByteArray>): List<String> {
        val xml = entries["xl/sharedStrings.xml"]?.toString(Charsets.UTF_8) ?: return emptyList()
        return siRe.findAll(xml).map { si ->
            tRe.findAll(si.groupValues[1]).joinToString("") { unescape(it.groupValues[2]) }
        }.toList()
    }

    fun xlsxText(bytes: ByteArray, maxRows: Int = 400): String {
        val entries = unzip(bytes)
        val shared = sharedStrings(entries)
        val sheetNames = Regex("<sheet [^>]*name=\"([^\"]+)\"").findAll(
            entries["xl/workbook.xml"]?.toString(Charsets.UTF_8).orEmpty()
        ).map { unescape(it.groupValues[1]) }.toList()
        val sheets = entries.keys.filter { Regex("xl/worksheets/sheet\\d+\\.xml").matches(it) }
            .sortedBy { Regex("\\d+").find(it.substringAfterLast("sheet"))?.value?.toIntOrNull() ?: 0 }
        val rowRe = Regex("<row(?:\\s[^>]*)?>([\\s\\S]*?)</row>")
        val cellRe = Regex("<c(\\s[^>]*?)?(?:/>|>([\\s\\S]*?)</c>)")
        val vRe = Regex("<v>([^<]*)</v>")
        val sb = StringBuilder()
        for ((i, name) in sheets.withIndex()) {
            sb.append("【工作表 ").append(sheetNames.getOrNull(i) ?: "${i + 1}").append("】\n")
            val xml = entries.getValue(name).toString(Charsets.UTF_8)
            var rows = 0
            for (r in rowRe.findAll(xml)) {
                if (rows++ >= maxRows) { sb.append("…（行数过多，已截断）\n"); break }
                val cells = cellRe.findAll(r.groupValues[1]).map { c ->
                    val attrs = c.groupValues[1]
                    val inner = c.groupValues[2]
                    val type = Regex("\\st=\"([^\"]+)\"").find(attrs)?.groupValues?.get(1)
                    when (type) {
                        "s" -> vRe.find(inner)?.groupValues?.get(1)?.toIntOrNull()?.let { shared.getOrNull(it) }.orEmpty()
                        "inlineStr" -> tRe.findAll(inner).joinToString("") { unescape(it.groupValues[2]) }
                        else -> vRe.find(inner)?.groupValues?.get(1)?.let { unescape(it) }.orEmpty()
                    }
                }.toList()
                if (cells.any { it.isNotBlank() }) sb.append(cells.joinToString("\t")).append('\n')
            }
            sb.append('\n')
        }
        return sb.toString().trimEnd()
    }

    fun xlsxReplace(bytes: ByteArray, find: String, replacement: String): Pair<ByteArray, Int> {
        if (find.isEmpty()) return bytes to 0
        val entries = unzip(bytes)
        var total = 0
        val targets = entries.keys.filter { it == "xl/sharedStrings.xml" || Regex("xl/worksheets/sheet\\d+\\.xml").matches(it) }
        for (name in targets) {
            val xml = entries.getValue(name).toString(Charsets.UTF_8)
            var n = 0
            val nx = tRe.replace(xml) { m ->
                val text = unescape(m.groupValues[2])
                val c = countOccurrences(text, find)
                if (c == 0) m.value else {
                    n += c
                    "<t${m.groupValues[1]}>${escape(text.replace(find, replacement))}</t>"
                }
            }
            if (n > 0) {
                entries[name] = nx.toByteArray(Charsets.UTF_8)
                total += n
            }
        }
        return (if (total > 0) zip(entries) else bytes) to total
    }
}

/** 文本编码识别 / 旧版二进制文档的粗略文字提取。 */
object TextDecode {

    /** 先按 UTF-8 严格解码，失败再按 GB18030（兼容 GBK/GB2312）。 */
    fun decode(bytes: ByteArray): String {
        // BOM
        if (bytes.size >= 3 && bytes[0] == 0xEF.toByte() && bytes[1] == 0xBB.toByte() && bytes[2] == 0xBF.toByte()) {
            return String(bytes, 3, bytes.size - 3, Charsets.UTF_8)
        }
        if (bytes.size >= 2 && bytes[0] == 0xFF.toByte() && bytes[1] == 0xFE.toByte()) {
            return String(bytes, 2, bytes.size - 2, Charsets.UTF_16LE)
        }
        if (bytes.size >= 2 && bytes[0] == 0xFE.toByte() && bytes[1] == 0xFF.toByte()) {
            return String(bytes, 2, bytes.size - 2, Charsets.UTF_16BE)
        }
        val decoder = Charsets.UTF_8.newDecoder()
            .onMalformedInput(CodingErrorAction.REPORT)
            .onUnmappableCharacter(CodingErrorAction.REPORT)
        return try {
            decoder.decode(ByteBuffer.wrap(bytes)).toString()
        } catch (_: CharacterCodingException) {
            try { String(bytes, Charset.forName("GB18030")) } catch (_: Exception) { String(bytes, Charsets.ISO_8859_1) }
        }
    }

    /** 判断编码名（写回文件时保持原编码）。 */
    fun detectCharsetName(bytes: ByteArray): String {
        if (bytes.size >= 3 && bytes[0] == 0xEF.toByte() && bytes[1] == 0xBB.toByte() && bytes[2] == 0xBF.toByte()) return "UTF-8-BOM"
        val decoder = Charsets.UTF_8.newDecoder()
            .onMalformedInput(CodingErrorAction.REPORT)
            .onUnmappableCharacter(CodingErrorAction.REPORT)
        return try { decoder.decode(ByteBuffer.wrap(bytes)); "UTF-8" } catch (_: CharacterCodingException) { "GB18030" }
    }

    fun encode(text: String, charsetName: String): ByteArray = when (charsetName) {
        "UTF-8-BOM" -> byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()) + text.toByteArray(Charsets.UTF_8)
        "GB18030" -> text.toByteArray(Charset.forName("GB18030"))
        else -> text.toByteArray(Charsets.UTF_8)
    }

    /** 旧版 .doc/.ppt/.xls：抽取其中的 UTF-16LE 文字片段（尽力而为）。 */
    fun extractLegacyText(bytes: ByteArray, maxChars: Int = 20000): String {
        val sb = StringBuilder()
        val run = StringBuilder()
        var i = 0
        fun flush() {
            if (run.length >= 4) sb.append(run).append('\n')
            run.setLength(0)
        }
        while (i + 1 < bytes.size && sb.length < maxChars) {
            val c = ((bytes[i + 1].toInt() and 0xFF) shl 8) or (bytes[i].toInt() and 0xFF)
            val ch = c.toChar()
            val ok = (c in 0x20..0x7E) || (c in 0x4E00..0x9FFF) || (c in 0x3000..0x303F) ||
                (c in 0xFF00..0xFFEF) || ch == '\r' || ch == '\n' || ch == '\t'
            if (ok) {
                run.append(if (ch == '\r') '\n' else ch)
            } else {
                flush()
            }
            i += 2
        }
        flush()
        // 去掉大量纯 ASCII 噪声行
        return sb.lines().filter { line ->
            val t = line.trim()
            t.length >= 2 && (t.any { it.code in 0x4E00..0x9FFF } || t.count { it.isLetter() } >= t.length / 2)
        }.joinToString("\n").take(maxChars)
    }
}
