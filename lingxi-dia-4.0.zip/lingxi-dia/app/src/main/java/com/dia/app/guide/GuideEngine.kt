package com.dia.app.guide

import android.content.Context
import android.graphics.Rect
import android.graphics.RectF
import android.util.Log
import android.view.accessibility.AccessibilityNodeInfo
import com.dia.app.DiaAccessibilityService
import com.dia.app.llm.DiaEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import org.json.JSONObject
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.coroutines.resume

/**
 * Application-scoped Guide engine.
 *
 * Inspired by CursorBuddy. Unlike Pilot, Guide does NOT tap anything; it only
 * highlights the next thing the USER should tap, captions it, and speaks it.
 *
 * Key design — **iterative single-step planning**:
 *   1. Read the current screen.
 *   2. Ask the local model "what's the SINGLE next step the user should do
 *      right now to make progress toward `<goal>`, given THIS screen?"
 *   3. Render that step (highlight + pointer + caption + TTS).
 *   4. When the screen changes, treat that as the user having completed the
 *      step, re-read the screen, and re-plan a fresh single step.
 *
 * This is much more robust than planning the whole tutorial up-front because:
 *   - We never reference node IDs from a stale screen.
 *   - We can recover when the user takes an unexpected detour.
 *   - The model only has to reason about the screen it can actually see.
 */
object GuideEngine {

    private const val TAG = "GuideEngine"
    private const val SCREEN_CHAR_BUDGET = 2600
    /** Max steps before we bail out — protects against infinite loops. */
    private const val MAX_STEPS = 25
    /** Wait after a screen change before re-planning, so the new screen settles. */
    private const val SETTLE_MS = 700L
    /** If the model recommends the same action twice in a row, give up to avoid loops. */
    private const val SAME_ACTION_LIMIT = 3

    private const val SYSTEM_PROMPT = """You are a screen-guide assistant on an Android phone.

The user has a goal. You walk them through it ONE step at a time. They tap; you tell them where.

You receive each turn:
- The user's GOAL (their original question).
- The CURRENT SCREEN (compact tree of nodes they can see right now).
- A short HISTORY of the last steps you already gave.

You output ONE JSON object describing ONE next step:
{
  "node_id": "n7",            // optional — preferred when target is on screen
  "label": "Bluetooth",       // human-readable target (used as fallback)
  "action": "tap",            // tap | long_press | type | swipe_up | swipe_down | scroll | wait | done
  "text": "...",              // only for action=type
  "caption": "Tap Bluetooth", // SHORT instruction spoken to the user (max ~12 words)
  "thought": "Bluetooth is visible — direct tap"  // optional
}

ANALYSIS ORDER — DO THIS EVERY TURN:
1. Look at the SCREEN tree first. Is there a visible node whose label matches the target the user wants? If yes — use it directly with action=tap.
2. Only if NO matching node exists in the visible tree, decide whether you need to navigate (back / open app drawer / scroll).
3. Never default to "swipe up to open app drawer" before checking the visible tree. Many tasks complete entirely inside the current app.

ANDROID NAVIGATION (use only when needed):
- The screen header shows APP: <package> at the top. That's the foreground app.
- HOME LAUNCHER (com.sec.android.app.launcher / com.android.launcher* / com.miui.home / com.google.android.apps.nexuslauncher / com.oneplus.launcher): the user is on their wallpaper. Pinned apps are visible; others live in the app drawer.
    If you ARE on the launcher AND the target app's icon is NOT among the visible nodes, suggest: action="swipe_up", caption="Swipe up from the bottom to open the app drawer". On Samsung One UI this opens the drawer.
    If a search bar is visible on the home/drawer screen, prefer tapping it and typing the app's name.
- APP DRAWER: a grid of app icons sorted alphabetically. If the target app is NOT visible in the current page, the user needs to SCROLL DOWN to find it. Suggest: action="scroll", caption="Scroll down to find <app name>". Apps are alphabetical — if you see apps starting with 'C' and need 'S', scroll down.
- BACK / HOME: caption "Tap the back button" with action=tap on the visible back arrow. If no back arrow is visible, output action=wait with caption "Press the system back button" (the user has hardware/gesture back).

RULES:
- Output ONLY the JSON object. No prose, no markdown, no code fences.
- ONE step. Never plan further than the immediate next thing.
- ALWAYS prefer node_id from the visible tree when possible.
- Caption: SHORT, friendly imperative. "Tap …", "Swipe up", "Type your name". Don't say "I will" or "you can".
- Never invent a node_id that isn't in the SCREEN tree.
- If the goal is already done (the screen shows the answer or the requested setting is now active), return:
    {"action":"done","caption":"All set — <one-sentence confirmation>"}

CRITICAL — DO NOT FINISH EARLY:
- Opening an app is NEVER the final goal. If the user said "search for X in Y app" and you just opened Y, you are NOT done. You must guide them to the search bar, type the query, and submit.
- Only return "done" when the user can SEE the final result on screen (search results showing, setting toggled, message sent, etc.).
- If you're unsure whether the task is complete, give the next step rather than finishing."""

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val running = AtomicBoolean(false)
    private val cancelled = AtomicBoolean(false)
    private var currentJob: Job? = null

    private val _state = MutableStateFlow(GuideState.IDLE)
    val state: StateFlow<GuideState> = _state.asStateFlow()

    private val _currentStep = MutableStateFlow<GuideStep?>(null)
    val currentStep: StateFlow<GuideStep?> = _currentStep.asStateFlow()

    private val _guide = MutableStateFlow<Guide?>(null)
    val guide: StateFlow<Guide?> = _guide.asStateFlow()

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 16)
    val messages: SharedFlow<String> = _messages.asSharedFlow()

    @Volatile
    private var appContext: Context? = null

    private var goal: String = ""
    private val history = ArrayDeque<String>()
    private var lastScreenHash: Int = 0
    private var stepIndex = 0
    /** Set when the user interacts — triggers re-planning. */
    private val pendingReplan = AtomicBoolean(false)
    /** Action fingerprint of the last step — used to detect ping-pong loops. */
    private var lastActionFingerprint: String? = null
    private var sameActionCount = 0

    /** Backend (local Gemma vs cloud LLM) chosen for this Guide run. */
    @Volatile
    private var currentBackend: com.dia.app.pilot.cloud.TaskRouter.Backend =
        com.dia.app.pilot.cloud.TaskRouter.Backend.LOCAL

    /**
     * Conversation history we replay to the cloud model so it remembers
     * what step it already gave the user. Empty for local runs.
     */
    private val cloudHistory = mutableListOf<com.dia.app.pilot.cloud.CloudLlmClient.Message>()

    fun attach(context: Context) {
        if (appContext == null) appContext = context.applicationContext
    }

    fun isRunning(): Boolean = running.get()

    fun start(question: String) {
        if (running.getAndSet(true)) return
        cancelled.set(false)

        // Strip any "cloud:" / "local:" prefix the user may have typed —
        // the prefix only controls routing, not the content of the goal.
        val rawQuestion = question.trim()
        val cleanedQuestion = rawQuestion
            .removePrefix("cloud:").removePrefix("CLOUD:")
            .removePrefix("[cloud]").removePrefix("[CLOUD]")
            .removePrefix("local:").removePrefix("LOCAL:")
            .removePrefix("[local]").removePrefix("[LOCAL]")
            .trim()

        cloudHistory.clear()

        goal = cleanedQuestion
        history.clear()
        stepIndex = 0
        lastActionFingerprint = null
        sameActionCount = 0
        pendingReplan.set(false)
        _currentStep.value = null
        _guide.value = Guide(
            id = "guide_${System.currentTimeMillis()}",
            question = cleanedQuestion,
            appPackage = currentPackage(),
            steps = emptyList(),
        )
        _state.value = GuideState.ANALYZING

        currentJob = scope.launch {
            try {
                // Guide now respects the user's global Local/Cloud choice.
                currentBackend = when (com.dia.app.llm.BackendRouter.pick()) {
                    com.dia.app.llm.BackendRouter.Backend.LOCAL ->
                        com.dia.app.pilot.cloud.TaskRouter.Backend.LOCAL
                    com.dia.app.llm.BackendRouter.Backend.CLOUD ->
                        com.dia.app.pilot.cloud.TaskRouter.Backend.CLOUD
                }
                Log.i(
                    TAG,
                    "Backend: ${currentBackend.name.lowercase()}" +
                        if (currentBackend == com.dia.app.pilot.cloud.TaskRouter.Backend.CLOUD)
                            " (${com.dia.app.prefs.DiaPrefs.cloudModel.value})"
                        else ""
                )

                // First, try to open the target app directly. This skips
                // launcher / drawer / scroll-to-find guidance completely.
                tryAutoOpenApp(cleanedQuestion)
                runLoop()
            } catch (t: Throwable) {
                Log.e(TAG, "runLoop crashed", t)
                fail("Something went wrong. ${t.message ?: ""}")
            } finally {
                running.set(false)
            }
        }
    }

    fun stop() {
        cancelled.set(true)
        currentJob?.cancel()
        currentJob = null
        running.set(false)
        DiaEngine.cancelPilotSession()
        _state.value = GuideState.IDLE
        _currentStep.value = null
        _guide.value = null
    }

    fun next() {
        // User asked to skip — re-plan from current screen.
        pendingReplan.set(true)
    }

    fun previous() {
        // Going back is hard with iterative planning; we just re-plan the same step.
        pendingReplan.set(true)
    }

    fun replay() {
        // Re-render existing step (caption + TTS will fire again from observers).
        val s = _currentStep.value ?: return
        _currentStep.value = null
        _currentStep.value = s
    }

    fun pause() { if (_state.value == GuideState.GUIDING) _state.value = GuideState.PAUSED }
    fun resume() { if (_state.value == GuideState.PAUSED) _state.value = GuideState.GUIDING }

    /**
     * Called on generic screen changes (content updates, window changes).
     *
     * We DO advance on this signal — many real user actions (swipe to open
     * the app drawer, scroll, hardware back, system gestures, an app
     * launching) never fire TYPE_VIEW_CLICKED but DO change the screen.
     * Without this, Guide would sit idle waiting for a click event that
     * never arrives, and the user has to tap the "next" button manually.
     *
     * To avoid spamming when an app keeps redrawing itself, we ignore
     * events for SETTLE_MS after the most recent re-plan, and we only set
     * pendingReplan when the new content is meaningfully different from
     * what was last shown.
     */
    fun onScreenChanged() {
        if (_state.value != GuideState.GUIDING && _state.value != GuideState.PAUSED) return
        // Debounce: don't reset the watchdog every single time the OS sends
        // a content event. We mark pendingReplan and let the loop re-read
        // the screen — if the hash is identical, the loop will simply wait
        // again instead of looping the model on stale content.
        pendingReplan.set(true)
    }

    /**
     * Called when the user taps something on screen (TYPE_VIEW_CLICKED).
     * This is the real signal that they followed the instruction.
     */
    fun onUserClicked() {
        if (_state.value != GuideState.GUIDING && _state.value != GuideState.PAUSED) return
        pendingReplan.set(true)
    }

    // ─── Main loop (iterative, single-step planning) ───

    private suspend fun runLoop() {
        // Initial screen settle.
        delay(150)

        while (stepIndex < MAX_STEPS && !cancelled.get() && scope.isActive) {
            if (_state.value == GuideState.PAUSED) {
                delay(200)
                continue
            }

            // Read the screen with retries — apps that just opened often
            // need a beat for their accessibility tree to populate.
            var screenTree = ""
            for (attempt in 0..8) {
                screenTree = readScreenTree()
                if (screenTree.isNotBlank() &&
                    !screenTree.startsWith("Screen unavailable") &&
                    !screenTree.startsWith("No interactive nodes")
                ) break
                delay(500)
            }
            if (screenTree.isBlank() ||
                screenTree.startsWith("Screen unavailable") ||
                screenTree.startsWith("No interactive nodes")
            ) {
                fail("I can't read this screen. Try moving / scrolling and ask again.")
                return
            }

            val newHash = screenTree.hashCode()
            lastScreenHash = newHash
            pendingReplan.set(false)

            _state.value = GuideState.ANALYZING

            stepIndex++
            val planJson = planNextStep(screenTree)
            if (cancelled.get()) return

            val parsed = parseStep(planJson, screenTree, stepIndex)
            if (parsed == null) {
                // Could not parse — give up gracefully.
                fail("I couldn't figure out the next step. Try rephrasing.")
                return
            }

            // Ping-pong detection.
            val fp = "${parsed.action}|${parsed.targetLabel}|${parsed.textToType}"
            if (fp == lastActionFingerprint) {
                sameActionCount++
                if (sameActionCount >= SAME_ACTION_LIMIT) {
                    fail("It looks like nothing changed after that step. Try doing it manually.")
                    return
                }
            } else {
                lastActionFingerprint = fp
                sameActionCount = 0
            }

            // DONE
            if (parsed.action == GuideAction.DONE) {
                _currentStep.value = parsed.copy(stepNumber = stepIndex, totalSteps = stepIndex)
                appendHistory("DONE: ${parsed.caption}")
                _state.value = GuideState.COMPLETE
                return
            }

            // Render this step.
            _currentStep.value = parsed.copy(stepNumber = stepIndex, totalSteps = stepIndex /* unknown total */)
            _guide.update { g ->
                g?.copy(steps = g.steps + parsed.copy(stepNumber = stepIndex, totalSteps = stepIndex))
            }
            appendHistory("Step $stepIndex: ${parsed.action} — ${parsed.caption}")
            _state.value = GuideState.GUIDING

            // WAIT actions — pause briefly then re-plan automatically.
            if (parsed.action == GuideAction.WAIT) {
                delay(1500)
                continue
            }

            // For real user actions: wait until the user does something that
            // changes the screen. Bail out after a generous timeout so we
            // never get permanently stuck.
            val waited = waitForScreenChange(timeoutMs = 60_000L)
            if (cancelled.get()) return
            if (!waited) {
                // 60s with no change — speak a nudge and re-plan in case the
                // node bounds drifted.
                _messages.tryEmit("Still waiting for you to tap. Want me to look again?")
            }

            // Settle, then loop will re-read the screen and plan again.
            delay(SETTLE_MS)
        }

        if (stepIndex >= MAX_STEPS) {
            fail("That took longer than I expected. Try a more specific question.")
        }
    }

    /**
     * Suspend until the screen actually changes (different content hash)
     * after pendingReplan fires, or until the timeout elapses.
     *
     * Why the hash check: TYPE_WINDOW_CONTENT_CHANGED fires for animations,
     * notification badges, clock-tick redraws — events that don't represent
     * the user advancing. Without this filter, Guide would re-plan on every
     * tick and the model would say "done" prematurely.
     */
    private suspend fun waitForScreenChange(timeoutMs: Long): Boolean {
        val start = System.currentTimeMillis()
        while (System.currentTimeMillis() - start < timeoutMs) {
            if (cancelled.get() || !scope.isActive) return false
            if (_state.value == GuideState.PAUSED) {
                delay(200); continue
            }
            if (pendingReplan.get()) {
                // Let the new screen settle, then verify it's actually
                // different from the one we planned this step against.
                delay(SETTLE_MS)
                if (cancelled.get()) return false
                val freshHash = readScreenTree().hashCode()
                if (freshHash != lastScreenHash) {
                    return true
                }
                // Same screen as before — was just a redraw. Reset the flag
                // and keep waiting.
                pendingReplan.set(false)
            }
            delay(200)
        }
        return false
    }

    private fun appendHistory(line: String) {
        history.addLast(line)
        while (history.size > 6) history.removeFirst()

        // Cloud-only: record user-visible progress so the remote model
        // remembers what step the user already followed.
        if (currentBackend == com.dia.app.pilot.cloud.TaskRouter.Backend.CLOUD) {
            cloudHistory += com.dia.app.pilot.cloud.CloudLlmClient.Message(
                role = "user", content = "PROGRESS: $line",
            )
            while (cloudHistory.size > 16) cloudHistory.removeAt(0)
        }
    }

    private fun readScreenTree(): String {
        val service = DiaAccessibilityService.getInstance() ?: return ""
        return service.getScreenTree().orEmpty()
    }

    private fun currentPackage(): String? =
        DiaAccessibilityService.getInstance()?.rootInActiveWindow?.packageName?.toString()

    private fun fail(msg: String) {
        // Emit the message first so the overlay can display it, then sleep
        // before going to IDLE so the user can actually read it.
        scope.launch {
            _messages.emit(msg)
            delay(3500)
            _state.value = GuideState.IDLE
            _currentStep.value = null
            _guide.value = null
        }
    }

    /**
     * If the user's question references a specific app, launch it directly
     * via the package manager. This skips home-screen / app-drawer guidance
     * entirely and lets the model focus on what to do INSIDE the app.
     *
     * Examples that match: "open whatsapp and send …", "send a message on
     * instagram", "search youtube for …", "in chrome go to …".
     *
     * If no app is mentioned (e.g. "turn on bluetooth"), we just continue
     * with the normal loop.
     */
    private suspend fun tryAutoOpenApp(question: String) {
        val ctx = appContext ?: return
        val pm = ctx.packageManager
        val q = question.lowercase()

        // Quick map of common app names to packages — covers what most users ask.
        // For anything not in this list we scan installed apps by label.
        val knownApps = mapOf(
            "whatsapp" to "com.whatsapp",
            "instagram" to "com.instagram.android",
            "facebook" to "com.facebook.katana",
            "messenger" to "com.facebook.orca",
            "youtube" to "com.google.android.youtube",
            "youtube music" to "com.google.android.apps.youtube.music",
            "spotify" to "com.spotify.music",
            "twitter" to "com.twitter.android",
            "x" to "com.twitter.android",
            "snapchat" to "com.snapchat.android",
            "tiktok" to "com.zhiliaoapp.musically",
            "telegram" to "org.telegram.messenger",
            "discord" to "com.discord",
            "reddit" to "com.reddit.frontpage",
            "gmail" to "com.google.android.gm",
            "google" to "com.google.android.googlequicksearchbox",
            "chrome" to "com.android.chrome",
            "maps" to "com.google.android.apps.maps",
            "google maps" to "com.google.android.apps.maps",
            "drive" to "com.google.android.apps.docs",
            "google drive" to "com.google.android.apps.docs",
            "settings" to "com.android.settings",
            "camera" to "com.sec.android.app.camera",
            "gallery" to "com.sec.android.gallery3d",
            "photos" to "com.google.android.apps.photos",
            "play store" to "com.android.vending",
            "playstore" to "com.android.vending",
            "calculator" to "com.sec.android.app.popupcalculator",
            "calendar" to "com.samsung.android.calendar",
            "clock" to "com.sec.android.app.clockpackage",
            "notes" to "com.samsung.android.app.notes",
            "phone" to "com.samsung.android.dialer",
            "dialer" to "com.samsung.android.dialer",
            "contacts" to "com.samsung.android.app.contacts",
            "email" to "com.samsung.android.email.provider",
            "samsung internet" to "com.sec.android.app.sbrowser",
            "internet" to "com.sec.android.app.sbrowser",
            "files" to "com.sec.android.app.myfiles",
            "my files" to "com.sec.android.app.myfiles",
        )

        // 1. Try the known-apps shortcut.
        var matchedPackage: String? = null
        var matchedName: String? = null
        for ((label, pkg) in knownApps) {
            if (q.contains(label)) {
                matchedPackage = pkg
                matchedName = label
                break
            }
        }

        // 2. Fall back to scanning installed apps by label.
        if (matchedPackage == null) {
            try {
                val apps = pm.getInstalledApplications(0)
                for (app in apps) {
                    val label = pm.getApplicationLabel(app).toString().lowercase()
                    if (label.length < 3) continue
                    if (q.contains(label)) {
                        matchedPackage = app.packageName
                        matchedName = label
                        break
                    }
                }
            } catch (_: Exception) {}
        }

        if (matchedPackage == null) return

        try {
            val intent = pm.getLaunchIntentForPackage(matchedPackage)
            if (intent != null) {
                intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(intent)
                Log.d(TAG, "Auto-opened $matchedName ($matchedPackage)")
                appendHistory("Opened $matchedName")
                _messages.emit("Opening ${matchedName ?: "app"}…")
                // Wait for the app to actually be in the foreground.
                delay(1400)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Auto-open failed: ${e.message}")
        }
    }

    // ─── Planning ───

    private suspend fun planNextStep(screen: String): String {
        val trimmed = if (screen.length <= SCREEN_CHAR_BUDGET) screen
        else screen.take(SCREEN_CHAR_BUDGET) + "\n…(truncated)"

        val historyBlock = if (history.isEmpty()) "(none)" else history.joinToString("\n")

        val prompt = buildString {
            append("GOAL: ").append(goal).append('\n')
            append("\nCURRENT SCREEN:\n").append(trimmed)
            append("\n\nHISTORY:\n").append(historyBlock)
            append("\n\nAnalyze the screen tree above. Is the target already visible? If yes, point to it. If not, decide how to navigate. Return ONE JSON object with the SINGLE next step.")
        }
        return callModel(prompt)
    }

    private suspend fun callModel(prompt: String): String {
        return when (currentBackend) {
            com.dia.app.pilot.cloud.TaskRouter.Backend.CLOUD -> callCloud(prompt)
            com.dia.app.pilot.cloud.TaskRouter.Backend.LOCAL -> callLocal(prompt)
        }
    }

    private suspend fun callLocal(prompt: String): String = suspendCancellableCoroutine { cont ->
        val sb = StringBuilder()
        DiaEngine.sendPilotTurn(
            systemInstruction = SYSTEM_PROMPT,
            text = prompt,
            onToken = { partial, done ->
                if (partial.isNotEmpty()) sb.append(partial)
                if (done && cont.isActive) cont.resume(sb.toString())
            },
            onError = { msg ->
                Log.e(TAG, "Model error: $msg")
                if (cont.isActive) cont.resume("""{"action":"done","caption":"Error: $msg"}""")
            }
        )
    }

    private suspend fun callCloud(prompt: String): String {
        val baseUrl = com.dia.app.prefs.DiaPrefs.cloudBaseUrl.value
        val apiKey = com.dia.app.prefs.DiaPrefs.cloudApiKey.value
        val modelName = com.dia.app.prefs.DiaPrefs.cloudModel.value
        if (baseUrl.isBlank() || modelName.isBlank()) {
            return """{"action":"done","caption":"Cloud not configured. Add base URL and model in Settings."}"""
        }
        val client = com.dia.app.pilot.cloud.CloudLlmClient(baseUrl, apiKey, modelName)
        val result = client.chat(
            systemPrompt = SYSTEM_PROMPT,
            userPrompt = prompt,
            screenshotPngBase64 = null,
            history = cloudHistory.toList(),
            temperature = 0.1,
            maxTokens = 1024,
        )
        val content = result.content
        if (content == null) {
            return """{"action":"done","caption":"Cloud error: ${result.error?.replace("\"", "'")?.take(120)}"}"""
        }
        // Record the assistant's reply so the next cloud turn remembers
        // what step it just gave the user.
        cloudHistory += com.dia.app.pilot.cloud.CloudLlmClient.Message(
            role = "assistant", content = content,
        )
        // Bound history.
        while (cloudHistory.size > 16) cloudHistory.removeAt(0)
        return content
    }

    private fun extractJson(text: String): String? {
        val trimmed = text.trim()
        val fenced = Regex("```(?:json)?(.*?)```", RegexOption.DOT_MATCHES_ALL)
            .find(trimmed)?.groupValues?.getOrNull(1)?.trim()
        val candidate = fenced ?: trimmed
        val start = candidate.indexOf('{')
        if (start == -1) return null
        var depth = 0
        var inString = false
        var escape = false
        var lastValidEnd = -1
        for (i in start until candidate.length) {
            val c = candidate[i]
            if (escape) { escape = false; continue }
            if (c == '\\' && inString) { escape = true; continue }
            if (c == '"') { inString = !inString; continue }
            if (inString) continue
            when (c) {
                '{' -> depth++
                '}' -> { depth--; if (depth == 0) { lastValidEnd = i; break } }
            }
        }
        if (lastValidEnd == -1) {
            val end = candidate.lastIndexOf('}')
            if (end > start) return candidate.substring(start, end + 1)
            return null
        }
        return candidate.substring(start, lastValidEnd + 1)
    }

    private fun parseStep(raw: String, screen: String, stepNum: Int): GuideStep? {
        val json = extractJson(raw) ?: return null
        val obj = try { JSONObject(json) } catch (e: Exception) {
            Log.w(TAG, "bad JSON: $json")
            return null
        }
        val action = when (obj.optString("action").lowercase()) {
            "tap", "click" -> GuideAction.TAP
            "long_press", "long" -> GuideAction.LONG_PRESS
            "type", "input_text" -> GuideAction.TYPE
            "scroll" -> GuideAction.SCROLL
            "swipe_up" -> GuideAction.SWIPE
            "swipe_down" -> GuideAction.SWIPE
            "swipe" -> GuideAction.SWIPE
            "wait" -> GuideAction.WAIT
            "done", "finish" -> GuideAction.DONE
            else -> GuideAction.TAP
        }

        val nodeId = obj.optString("node_id").takeIf { it.isNotBlank() }
            ?.replace("[", "")?.replace("]", "")?.trim()
        val captionFromModel = obj.optString("caption").trim()
        val labelFromModel = obj.optString("label").trim()
        val textToType = obj.optString("text").takeIf { it.isNotBlank() && action == GuideAction.TYPE }

        val service = DiaAccessibilityService.getInstance()

        var bounds: RectF? = null
        var label = labelFromModel.ifBlank { captionFromModel }

        if (nodeId != null && service != null) {
            val n = service.getNodeById(nodeId)
            if (n != null) {
                val r = Rect().apply { n.getBoundsInScreen(this) }
                if (r.width() > 0 && r.height() > 0) bounds = RectF(r)
                val t = n.text?.toString() ?: n.contentDescription?.toString()
                if (!t.isNullOrBlank()) label = t
            }
        }

        // If model gave us a label but no usable bounds, try to locate the node by text.
        if (bounds == null && service != null && label.isNotBlank() && action != GuideAction.SWIPE && action != GuideAction.WAIT) {
            val node = findNodeForLabel(service, label)
            if (node != null) {
                val r = Rect().apply { node.getBoundsInScreen(this) }
                if (r.width() > 0 && r.height() > 0) bounds = RectF(r)
            }
        }

        // For swipe actions we synthesize bounds at the bottom of the screen so
        // the highlight + pointer give the user a visual cue.
        if (action == GuideAction.SWIPE && bounds == null && service != null) {
            val dm = service.resources.displayMetrics
            val w = dm.widthPixels.toFloat()
            val h = dm.heightPixels.toFloat()
            bounds = RectF(w / 2 - 80f, h - 220f, w / 2 + 80f, h - 60f)
        }

        val caption = captionFromModel.ifBlank {
            when (action) {
                GuideAction.TAP -> if (label.isNotBlank()) "Tap $label" else "Tap here"
                GuideAction.LONG_PRESS -> if (label.isNotBlank()) "Long-press $label" else "Long-press here"
                GuideAction.TYPE -> "Type ${textToType.orEmpty()}"
                GuideAction.SCROLL -> "Scroll to find it"
                GuideAction.SWIPE -> "Swipe up from the bottom to open the app drawer"
                GuideAction.WAIT -> "Wait a moment"
                GuideAction.DONE -> "All done"
            }
        }

        return GuideStep(
            stepNumber = stepNum,
            totalSteps = stepNum,
            action = action,
            targetBounds = bounds,
            targetLabel = label,
            caption = caption,
            textToType = textToType,
        )
    }

    private fun findNodeForLabel(service: DiaAccessibilityService, label: String): AccessibilityNodeInfo? {
        if (label.isBlank()) return null
        val nodes = service.findNodesByText(label)
        if (nodes.isNotEmpty()) return nodes.first()
        val words = label.split(' ', '\n').filter { it.length > 2 }
        for (w in words) {
            val hits = service.findNodesByText(w)
            if (hits.isNotEmpty()) return hits.first()
        }
        return null
    }
}
