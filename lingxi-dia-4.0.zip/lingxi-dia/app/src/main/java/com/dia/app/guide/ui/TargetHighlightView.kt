package com.dia.app.guide.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.View

/**
 * Thin rounded rectangle with a glow around the next tap target.
 *
 * When [highContrast] is true (the user's accessibility pref), we switch to
 * bright yellow with a black outline — WCAG-style contrast that still works
 * for users with low vision and color-blindness.
 */
class TargetHighlightView(
    context: Context,
    private val highContrast: Boolean = false,
) : View(context) {

    /** Samsung touch-through: let all touches fall through to the app below. */
    override fun dispatchTouchEvent(event: android.view.MotionEvent?): Boolean = false
    override fun onTouchEvent(event: android.view.MotionEvent?): Boolean = false

    private val fillColor = if (highContrast) 0x33FFD600 else 0x2200E676
    private val glowColor = if (highContrast) 0xFFFFD600.toInt() else 0xFF00E676.toInt()
    private val borderColor = if (highContrast) 0xFF000000.toInt() else 0xFFFFFFFF.toInt()
    private val borderWidth = if (highContrast) 4f else 2f

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = fillColor
        style = Paint.Style.FILL
    }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = glowColor
        style = Paint.Style.STROKE
        strokeWidth = if (highContrast) 7f else 5f
        setShadowLayer(if (highContrast) 22f else 16f, 0f, 0f, glowColor)
    }
    private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = borderColor
        style = Paint.Style.STROKE
        strokeWidth = borderWidth
    }

    init { setLayerType(LAYER_TYPE_SOFTWARE, null) }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val pad = 6f
        val rect = RectF(pad, pad, width - pad, height - pad)
        val r = 20f
        canvas.drawRoundRect(rect, r, r, fill)
        canvas.drawRoundRect(rect, r, r, glow)
        canvas.drawRoundRect(rect, r, r, border)
    }
}
