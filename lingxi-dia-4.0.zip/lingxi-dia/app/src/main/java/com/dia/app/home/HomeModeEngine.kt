package com.dia.app.home

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import com.dia.app.llm.BackendRouter
import com.dia.app.prefs.DiaPrefs
import com.dia.app.voice.DiaTts
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.coroutines.resume

/**
 * Home Mode engine — always-listening smart home assistant loop.
 *
 * Flow: Wake/tap -> STT -> LLM (with HA tools) -> execute tool -> TTS response -> back to listening
 */
object HomeModeEngine {
    private const val TAG = "HomeModeEngine"

    enum class State { IDLE, LISTENING, THINKING, SPEAKING, ERROR }

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val _state = MutableStateFlow(State.IDLE)
    val state: StateFlow<State> = _state.asStateFlow()

    private val _lastCommand = MutableStateFlow("")
    val lastCommand: StateFlow<String> = _lastCommand.asStateFlow()

    private val _lastResponse = MutableStateFlow("")
    val lastResponse: StateFlow<String> = _lastResponse.asStateFlow()

    private val _connected = MutableStateFlow(false)
    val connected: StateFlow<Boolean> = _connected.asStateFlow()

    private val _entities = MutableStateFlow<List<HaClient.HaEntity>>(emptyList())
    val entities: StateFlow<List<HaClient.HaEntity>> = _entities.asStateFlow()

    private val active = AtomicBoolean(false)
    private val wakeActive = AtomicBoolean(false)
    private var loopJob: Job? = null
    private var wakeJob: Job? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var wakeRecognizer: SpeechRecognizer? = null
    @Volatile private var appContext: Context? = null

    /** Wake-word phrases — Dia listens continuously for any of these. */
    private val WAKE_WORDS = listOf("hey dia", "hi dia", "ok dia", "dia")

    private const val SYSTEM_PROMPT = """You are Dia, a smart home voice assistant. You control the user's home via Home Assistant.

You have these tools (output ONE JSON object per turn):
- ha_call_service(domain, service, entity_id) — call a HA service. Examples:
  {"tool":"ha_call_service","params":{"domain":"light","service":"turn_on","entity_id":"light.bedroom"}}
  {"tool":"ha_call_service","params":{"domain":"light","service":"turn_off","entity_id":"light.kitchen"}}
  {"tool":"ha_call_service","params":{"domain":"switch","service":"toggle","entity_id":"switch.fan"}}
- ha_get_state(entity_id) — check current state of a device
  {"tool":"ha_get_state","params":{"entity_id":"light.bedroom"}}
- ha_list_entities(domain?) — list available devices
  {"tool":"ha_list_entities","params":{"domain":"light"}}
- respond(message) — speak a response to the user without controlling anything
  {"tool":"respond","params":{"message":"The bedroom light is already on."}}

AVAILABLE ENTITIES:
{ENTITIES}

RULES:
- Output ONLY one JSON object. No prose.
- For "turn on/off X" -> ha_call_service with the matching entity
- For "is X on?" -> ha_get_state
- For "what devices do I have?" -> ha_list_entities
- For greetings or questions you can't answer with tools -> respond
- Match entity names fuzzily: "bedroom light" = "light.bed_light" or "light.bedroom"
- If unsure which entity, use ha_list_entities first, then respond with options
- Any free-text "message" field must be written in Simplified Chinese (简体中文). Keep JSON keys, tool names and entity_ids unchanged."""

    fun attach(context: Context) {
        appContext = context.applicationContext
    }

    fun start() {
        if (active.getAndSet(true)) return
        _state.value = State.IDLE
        loopJob = scope.launch {
            // Check HA connection
            checkConnection()
            refreshEntities()
            // Enter listening state
            _state.value = State.IDLE
            // If the user has wake-word enabled, kick off the listen loop.
            if (DiaPrefs.homeWakeWord.value) startWakeWord()
        }
    }

    fun stop() {
        active.set(false)
        loopJob?.cancel()
        loopJob = null
        speechRecognizer?.destroy()
        speechRecognizer = null
        stopWakeWord()
        _state.value = State.IDLE
    }

    /** Manual refresh of HA connection + entity list. */
    fun refresh() {
        scope.launch {
            checkConnection()
            refreshEntities()
        }
    }

    /**
     * Start the always-on wake-word listener. It re-arms after every result
     * or error so it survives indefinitely. When it hears a wake word, it
     * triggers a regular listen-and-process cycle.
     *
     * Uses Android's free-form speech recognizer which isn't ideal for true
     * always-on but is the only on-device option that ships with the OS.
     */
    fun startWakeWord() {
        val ctx = appContext ?: return
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) return
        if (wakeActive.getAndSet(true)) return
        wakeJob = scope.launch {
            while (wakeActive.get()) {
                // Don't compete with the main listen flow.
                if (_state.value == State.LISTENING || _state.value == State.THINKING ||
                    _state.value == State.SPEAKING) {
                    delay(500)
                    continue
                }
                val heard = listenOnce(ctx, partial = false)?.lowercase()?.trim().orEmpty()
                if (!wakeActive.get()) break
                val matched = WAKE_WORDS.any { heard.contains(it) }
                if (matched) {
                    // Strip the wake word from the beginning so the user can
                    // say "Hey Dia, turn off the light" in one breath.
                    val command = WAKE_WORDS.fold(heard) { acc, w ->
                        if (acc.startsWith(w)) acc.removePrefix(w).trim().trimStart(',', ' ')
                        else acc
                    }
                    if (command.isNotBlank()) {
                        handleCommand(command)
                    } else {
                        triggerListen()
                    }
                    // Wait for the cycle to complete before re-arming.
                    while (_state.value != State.IDLE && wakeActive.get()) delay(300)
                }
                // Tiny pause before re-arming to avoid pegging the recognizer.
                delay(200)
            }
        }
    }

    fun stopWakeWord() {
        wakeActive.set(false)
        wakeJob?.cancel()
        wakeJob = null
        try { wakeRecognizer?.cancel() } catch (_: Exception) {}
        try { wakeRecognizer?.destroy() } catch (_: Exception) {}
        wakeRecognizer = null
    }

    /** Trigger one listen -> process -> respond cycle. */
    fun triggerListen() {
        if (!active.get()) return
        scope.launch {
            listenAndProcess()
        }
    }

    /** Process a text command directly (e.g. from typed input). */
    fun processCommand(text: String) {
        if (text.isBlank()) return
        scope.launch {
            handleCommand(text)
        }
    }

    private suspend fun checkConnection() {
        val url = DiaPrefs.haBaseUrl.value
        val token = DiaPrefs.haToken.value
        _connected.value = if (url.isNotBlank() && token.isNotBlank()) {
            HaClient.ping(url, token)
        } else false
    }

    private suspend fun refreshEntities() {
        val url = DiaPrefs.haBaseUrl.value
        val token = DiaPrefs.haToken.value
        if (url.isBlank() || token.isBlank()) return
        val all = HaClient.listEntities(url, token)
        // Only keep controllable domains
        val controllable = all.filter {
            it.domain in listOf(
                "light", "switch", "fan", "cover", "climate",
                "media_player", "lock", "scene", "script", "automation"
            )
        }
        _entities.value = controllable
    }

    private suspend fun listenAndProcess() {
        val ctx = appContext ?: return
        _state.value = State.LISTENING

        val text = listenForSpeech(ctx)
        if (text.isNullOrBlank()) {
            _state.value = if (active.get()) State.IDLE else State.IDLE
            return
        }
        handleCommand(text)
    }

    /**
     * Single-shot listen wrapper used by both the manual mic button and
     * the wake-word loop. Returns the recognized text or null if nothing
     * was heard / errored out.
     */
    private suspend fun listenOnce(ctx: Context, partial: Boolean): String? =
        listenForSpeech(ctx)

    private suspend fun handleCommand(text: String) {
        val ctx = appContext ?: return
        _lastCommand.value = text
        _state.value = State.THINKING

        // Build prompt with available entities
        val entitiesBlock = _entities.value.joinToString("\n") {
            "- ${it.friendlyName} (${it.entityId}) [${it.state}]"
        }.ifBlank { "(no entities loaded \u2014 try ha_list_entities)" }
        val systemPrompt = SYSTEM_PROMPT.replace("{ENTITIES}", entitiesBlock)

        // Call LLM
        val response = callLlm(systemPrompt, "User said: \"$text\"\nOutput one JSON tool call:")
        val json = extractJson(response)

        if (json == null) {
            // Model gave a plain text response — speak it
            val spoken = response.take(200)
            _lastResponse.value = spoken
            _state.value = State.SPEAKING
            speak(ctx, spoken)
            return
        }

        // Parse and execute tool
        val toolName = json.optString("tool", "")
        val params = json.optJSONObject("params") ?: JSONObject()

        val result = when (toolName) {
            "ha_call_service" -> {
                val domain = params.optString("domain")
                val service = params.optString("service")
                val entityId = params.optString("entity_id")
                HaTools.callService(domain, service, entityId)
            }
            "ha_get_state" -> {
                val entityId = params.optString("entity_id")
                HaTools.getState(entityId)
            }
            "ha_list_entities" -> {
                val domain = params.optString("domain").ifBlank { null }
                HaTools.listEntities(domain)
            }
            "respond" -> {
                params.optString("message", "好的")
            }
            else -> "我不太确定该怎么做。"
        }

        _lastResponse.value = result
        _state.value = State.SPEAKING
        speak(ctx, result)

        // Refresh entities after a service call (state may have changed)
        if (toolName == "ha_call_service") {
            delay(500)
            refreshEntities()
        }
    }

    private suspend fun callLlm(systemPrompt: String, userPrompt: String): String =
        suspendCancellableCoroutine { cont ->
            val sb = StringBuilder()
            BackendRouter.sendSingleTurn(
                text = userPrompt,
                images = emptyList(),
                onToken = { partial, done ->
                    if (partial.isNotEmpty()) sb.append(partial)
                    if (done && cont.isActive) cont.resume(sb.toString())
                },
                onError = { msg ->
                    Log.e(TAG, "LLM error: $msg")
                    if (cont.isActive) cont.resume("抱歉，我没能理解你的意思。")
                },
                systemInstruction = systemPrompt,
                temperature = 0.1,
            )
        }

    private suspend fun speak(ctx: Context, text: String) {
        DiaTts.speak(ctx, "home_mode", text)
        // Wait for TTS to finish (approximate)
        delay((text.length * 60L).coerceIn(1000, 8000))
        _state.value = if (active.get()) State.IDLE else State.IDLE
    }

    private suspend fun listenForSpeech(ctx: Context): String? =
        suspendCancellableCoroutine { cont ->
            try {
                if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
                    cont.resume(null)
                    return@suspendCancellableCoroutine
                }
                // Permission gate — without RECORD_AUDIO the recognizer
                // silently fails on most devices.
                val perm = androidx.core.content.ContextCompat.checkSelfPermission(
                    ctx, android.Manifest.permission.RECORD_AUDIO,
                )
                if (perm != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    cont.resume(null)
                    return@suspendCancellableCoroutine
                }
                val recognizer = SpeechRecognizer.createSpeechRecognizer(ctx)
                speechRecognizer = recognizer
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(
                        RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                        RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                    )
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "zh-CN")
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                }
                recognizer.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(p: Bundle?) {}
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(p: Float) {}
                    override fun onBufferReceived(p: ByteArray?) {}
                    override fun onEndOfSpeech() {}
                    override fun onError(e: Int) {
                        if (cont.isActive) cont.resume(null)
                    }
                    override fun onResults(results: Bundle?) {
                        val text = results
                            ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            ?.firstOrNull()
                        if (cont.isActive) cont.resume(text)
                    }
                    override fun onPartialResults(p: Bundle?) {}
                    override fun onEvent(p: Int, q: Bundle?) {}
                })
                recognizer.startListening(intent)
            } catch (e: Exception) {
                if (cont.isActive) cont.resume(null)
            }
        }

    private fun extractJson(text: String): JSONObject? {
        val trimmed = text.trim()
        val start = trimmed.indexOf('{')
        if (start == -1) return null
        var depth = 0
        var inStr = false
        var esc = false
        var end = -1
        for (i in start until trimmed.length) {
            val c = trimmed[i]
            if (esc) { esc = false; continue }
            if (c == '\\' && inStr) { esc = true; continue }
            if (c == '"') { inStr = !inStr; continue }
            if (inStr) continue
            when (c) {
                '{' -> depth++
                '}' -> {
                    depth--
                    if (depth == 0) { end = i; break }
                }
            }
        }
        if (end == -1) return null
        return try { JSONObject(trimmed.substring(start, end + 1)) } catch (_: Exception) { null }
    }
}
