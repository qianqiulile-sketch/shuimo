package com.dia.app.imagegen

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.util.Log
import com.dia.app.prefs.DiaSettings
import com.dia.app.web.Http
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.URLEncoder
import java.util.zip.ZipInputStream

/**
 * 生图 AI（程序里的第二个 AI）。四种方式：
 *  - pollinations：免费在线生图，无需密钥（默认）
 *  - openai：任意 OpenAI 兼容的 /images/generations（硅基流动、OpenAI、通义等兼容网关）
 *  - sdwebui：局域网电脑上的 Stable Diffusion WebUI（/sdapi/v1/txt2img）
 *  - local：手机本机 MediaPipe Image Generator（模型需后下载 / 导入）
 */
object ImageGen {

    private const val TAG = "ImageGen"

    data class Result(val path: String, val provider: String, val promptUsed: String)

    val PROVIDERS = listOf(
        "pollinations" to "在线 · Pollinations（免费）",
        "openai" to "在线 · OpenAI 兼容接口",
        "sdwebui" to "局域网 · SD WebUI",
        "local" to "本机 · MediaPipe（需下载模型）",
    )

    fun providerLabel(id: String): String = PROVIDERS.firstOrNull { it.first == id }?.second ?: id

    private lateinit var appCtx: Context

    fun init(context: Context) {
        if (!::appCtx.isInitialized) appCtx = context.applicationContext
    }

    private val outDir: File get() = File(appCtx.filesDir, "generated").apply { mkdirs() }

    private fun parseSize(s: String): Pair<Int, Int> {
        val m = Regex("(\\d{3,4})\\s*[x×*]\\s*(\\d{3,4})").find(s)
        val w = m?.groupValues?.get(1)?.toIntOrNull() ?: 1024
        val h = m?.groupValues?.get(2)?.toIntOrNull() ?: 1024
        return w.coerceIn(256, 2048) to h.coerceIn(256, 2048)
    }

    /** 同步执行（请在 IO 线程调用）。 */
    fun generate(prompt: String, size: String? = null, provider: String? = null): Result {
        val p = provider?.takeIf { it.isNotBlank() } ?: DiaSettings.imageProvider.value
        val (w, h) = parseSize(size ?: DiaSettings.imageSize.value)
        val bitmap: Bitmap = when (p) {
            "openai" -> openAi(prompt, w, h)
            "sdwebui" -> sdWebUi(prompt, w, h)
            "local" -> LocalImageGen.generate(appCtx, prompt, DiaSettings.localImageSteps.value)
            else -> pollinations(prompt, w, h)
        }
        val f = File(outDir, "img_${System.currentTimeMillis()}.png")
        FileOutputStream(f).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
        return Result(f.absolutePath, p, prompt)
    }

    private fun decode(bytes: ByteArray): Bitmap =
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            ?: throw IllegalStateException("返回的不是图片：${String(bytes.copyOf(minOf(bytes.size, 200)))}")

    private fun pollinations(prompt: String, w: Int, h: Int): Bitmap {
        val seed = (Math.random() * 1_000_000).toInt()
        val model = DiaSettings.imageModel.value.ifBlank { "flux" }
        val url = "https://image.pollinations.ai/prompt/" + URLEncoder.encode(prompt, "UTF-8").replace("+", "%20") +
            "?width=$w&height=$h&seed=$seed&nologo=true&model=$model"
        val headers = DiaSettings.imageApiKey.value.takeIf { it.isNotBlank() }
            ?.let { mapOf("Authorization" to "Bearer $it") } ?: emptyMap()
        val resp = Http.get(url, maxBytes = 15_000_000, timeoutMs = 120_000, headers = headers)
        if (resp.code !in 200..299) throw IllegalStateException("在线生图失败（HTTP ${resp.code}）。可在设置里换一种生图方式。")
        return decode(resp.bytes)
    }

    private fun openAi(prompt: String, w: Int, h: Int): Bitmap {
        val base = DiaSettings.imageBaseUrl.value.trim().trimEnd('/')
        if (base.isBlank()) throw IllegalStateException("请先在 设置 → 生图 里填写接口地址")
        val endpoint = when {
            base.endsWith("/images/generations") -> base
            base.endsWith("/v1") -> "$base/images/generations"
            else -> "$base/v1/images/generations"
        }
        val body = JSONObject()
            .put("prompt", prompt)
            .put("n", 1)
            .put("size", "${w}x$h")
            .put("image_size", "${w}x$h") // 硅基流动等使用该字段
        val model = DiaSettings.imageModel.value
        if (model.isNotBlank()) body.put("model", model)
        val key = DiaSettings.imageApiKey.value
        val headers = if (key.isNotBlank()) mapOf("Authorization" to "Bearer $key") else emptyMap()
        val resp = Http.postJson(endpoint, body, headers, timeoutMs = 180_000)
        val text = String(resp.bytes, Charsets.UTF_8)
        if (resp.code !in 200..299) throw IllegalStateException("生图接口错误 HTTP ${resp.code}：${text.take(200)}")
        val root = JSONObject(text)
        val item = root.optJSONArray("data")?.optJSONObject(0) ?: root.optJSONArray("images")?.optJSONObject(0)
            ?: throw IllegalStateException("接口返回中没有图片：${text.take(200)}")
        val b64 = item.optString("b64_json")
        if (b64.isNotBlank()) return decode(Base64.decode(b64, Base64.DEFAULT))
        val url = item.optString("url")
        if (url.isBlank()) throw IllegalStateException("接口返回中没有图片地址")
        val img = Http.get(url, maxBytes = 20_000_000, timeoutMs = 60_000)
        return decode(img.bytes)
    }

    private fun sdWebUi(prompt: String, w: Int, h: Int): Bitmap {
        val base = DiaSettings.imageBaseUrl.value.trim().trimEnd('/')
        if (base.isBlank()) throw IllegalStateException("请先在 设置 → 生图 里填写 SD WebUI 地址，例如 http://192.168.1.10:7860")
        val body = JSONObject()
            .put("prompt", prompt)
            .put("negative_prompt", "lowres, bad anatomy, blurry, watermark, text")
            .put("steps", DiaSettings.localImageSteps.value.coerceIn(4, 60))
            .put("width", w)
            .put("height", h)
        val resp = Http.postJson("$base/sdapi/v1/txt2img", body, timeoutMs = 300_000)
        val text = String(resp.bytes, Charsets.UTF_8)
        if (resp.code !in 200..299) throw IllegalStateException("SD WebUI 错误 HTTP ${resp.code}：${text.take(200)}")
        val b64 = JSONObject(text).optJSONArray("images")?.optString(0).orEmpty()
        if (b64.isBlank()) throw IllegalStateException("SD WebUI 没有返回图片")
        return decode(Base64.decode(b64.substringAfter("base64,"), Base64.DEFAULT))
    }

    /** 保存到系统相册（Pictures/Dia）。 */
    fun saveToGallery(context: Context, path: String): Uri? {
        val src = File(path)
        if (!src.exists()) return null
        val name = src.name
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, name)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                    put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Dia")
                }
                val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return null
                context.contentResolver.openOutputStream(uri)?.use { out -> src.inputStream().use { it.copyTo(out) } }
                uri
            } else {
                @Suppress("DEPRECATION")
                val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "Dia").apply { mkdirs() }
                val dst = File(dir, name)
                src.copyTo(dst, overwrite = true)
                Uri.fromFile(dst)
            }
        } catch (e: Exception) {
            Log.e(TAG, "saveToGallery", e)
            null
        }
    }
}

/**
 * 本机生图：MediaPipe Image Generator（Stable Diffusion 1.5 转换后的模型）。
 *
 * 为了不让 MediaPipe 依赖影响主程序构建，这里通过反射调用：
 * 构建时加上 `-Pdia.localImageGen=true`（默认开启）即可打包 MediaPipe 库；
 * 如果打包时没带库，会提示改用在线 / 局域网生图。
 *
 * 模型放在 `files/imagegen/bins/`，可在设置里「从文件夹导入」或「从网址下载 zip」。
 */
object LocalImageGen {

    private const val TAG = "LocalImageGen"
    private const val CLS_GEN = "com.google.mediapipe.tasks.vision.imagegenerator.ImageGenerator"
    private const val CLS_OPTS = "com.google.mediapipe.tasks.vision.imagegenerator.ImageGenerator\$ImageGeneratorOptions"
    private const val CLS_EXTRACT = "com.google.mediapipe.framework.image.BitmapExtractor"

    private var generator: Any? = null
    private var loadedDir: String? = null

    private val _status = MutableStateFlow("")
    val status: StateFlow<String> = _status.asStateFlow()

    fun libraryAvailable(): Boolean = try { Class.forName(CLS_GEN); true } catch (_: Throwable) { false }

    fun modelDir(context: Context): File = File(context.filesDir, "imagegen/bins")

    fun modelInstalled(context: Context): Boolean {
        val d = modelDir(context)
        return d.isDirectory && (d.listFiles()?.size ?: 0) >= 5
    }

    fun describe(context: Context): String = when {
        !libraryAvailable() -> "当前安装包未包含 MediaPipe 生图库"
        !modelInstalled(context) -> "未安装模型"
        else -> "模型已就绪（${modelDir(context).listFiles()?.size ?: 0} 个文件）"
    }

    @Synchronized
    fun generate(context: Context, prompt: String, steps: Int): Bitmap {
        if (!libraryAvailable()) throw IllegalStateException("当前安装包没有包含本机生图库（构建参数 dia.localImageGen=false）。请在设置里改用在线或局域网生图。")
        val dir = modelDir(context)
        if (!modelInstalled(context)) throw IllegalStateException("本机生图模型未安装。请到 设置 → 生图 → 本机模型 导入或下载。")
        val gen = ensureGenerator(context, dir.absolutePath)
        val seed = (Math.random() * 100000).toInt()
        val method = gen.javaClass.methods.firstOrNull {
            it.name == "generate" && it.parameterTypes.size == 3 && it.parameterTypes[0] == String::class.java
        } ?: throw IllegalStateException("MediaPipe 版本不兼容（找不到 generate）")
        val result = method.invoke(gen, prompt, steps.coerceIn(5, 50), seed)
            ?: throw IllegalStateException("生图失败（无结果）")
        val mpImage = result.javaClass.getMethod("generatedImage").invoke(result)
            ?: throw IllegalStateException("生图失败（无图片）")
        val extract = Class.forName(CLS_EXTRACT).methods.first { it.name == "extract" && it.parameterTypes.size == 1 }
        return extract.invoke(null, mpImage) as Bitmap
    }

    private fun ensureGenerator(context: Context, dir: String): Any {
        generator?.let { if (loadedDir == dir) return it }
        close()
        _status.value = "正在加载本机生图模型…"
        val optsCls = Class.forName(CLS_OPTS)
        val builder = optsCls.getMethod("builder").invoke(null)
            ?: throw IllegalStateException("MediaPipe builder 为空")
        builder.javaClass.getMethod("setImageGeneratorModelDirectory", String::class.java).invoke(builder, dir)
        val opts = builder.javaClass.getMethod("build").invoke(builder)
        val genCls = Class.forName(CLS_GEN)
        val create = genCls.methods.first { it.name == "createFromOptions" && it.parameterTypes.size == 2 }
        val gen = create.invoke(null, context.applicationContext, opts)
            ?: throw IllegalStateException("本机生图模型加载失败")
        generator = gen
        loadedDir = dir
        _status.value = "本机生图模型已加载"
        return gen
    }

    fun close() {
        val g = generator ?: return
        try { g.javaClass.getMethod("close").invoke(g) } catch (t: Throwable) { Log.w(TAG, "close: ${t.message}") }
        generator = null
        loadedDir = null
    }

    /** 从用户选择的文件夹（SAF 树）复制模型文件。 */
    fun importFromTree(context: Context, treeUri: Uri): Int {
        close()
        val dir = modelDir(context)
        dir.deleteRecursively()
        dir.mkdirs()
        val cr = context.contentResolver
        val docId = android.provider.DocumentsContract.getTreeDocumentId(treeUri)
        val children = android.provider.DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, docId)
        var n = 0
        cr.query(children, arrayOf(
            android.provider.DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            android.provider.DocumentsContract.Document.COLUMN_MIME_TYPE,
        ), null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val id = c.getString(0)
                val name = c.getString(1) ?: continue
                val mime = c.getString(2).orEmpty()
                if (mime == android.provider.DocumentsContract.Document.MIME_TYPE_DIR) continue
                val fileUri = android.provider.DocumentsContract.buildDocumentUriUsingTree(treeUri, id)
                cr.openInputStream(fileUri)?.use { input ->
                    FileOutputStream(File(dir, name)).use { input.copyTo(it) }
                    n++
                }
                _status.value = "已导入 $n 个文件…"
            }
        }
        _status.value = "导入完成：$n 个文件"
        return n
    }

    /** 下载 zip 并解压到模型目录（调用前需用户确认）。 */
    fun downloadZip(context: Context, url: String): Int {
        close()
        val dir = modelDir(context)
        dir.deleteRecursively()
        dir.mkdirs()
        val conn = java.net.URL(url).openConnection() as java.net.HttpURLConnection
        conn.connectTimeout = 20_000
        conn.readTimeout = 60_000
        conn.setRequestProperty("User-Agent", Http.UA)
        var n = 0
        try {
            val total = conn.contentLengthLong
            val counting = object : java.io.FilterInputStream(conn.inputStream) {
                var bytesRead = 0L
                override fun read(b: ByteArray, off: Int, len: Int): Int {
                    val r = super.read(b, off, len)
                    if (r > 0) {
                        bytesRead += r
                        if (total > 0) _status.value = "下载中 ${bytesRead * 100 / total}%" else _status.value = "已下载 ${bytesRead / 1024 / 1024} MB"
                    }
                    return r
                }
            }
            ZipInputStream(counting).use { zis ->
                while (true) {
                    val e = zis.nextEntry ?: break
                    if (!e.isDirectory) {
                        val name = e.name.substringAfterLast('/')
                        if (name.isNotBlank()) {
                            FileOutputStream(File(dir, name)).use { zis.copyTo(it) }
                            n++
                        }
                    }
                    zis.closeEntry()
                }
            }
        } finally {
            conn.disconnect()
        }
        _status.value = "下载完成：$n 个文件"
        return n
    }
}
