package com.dia.app.llm

/**
 * 16-bit signed little-endian mono PCM audio along with its sample rate.
 *
 * LiteRT-LM's `Content.AudioBytes(bytes)` is decoded by miniaudio, which
 * needs a real container (WAV/MP3/etc.) — feeding it raw PCM produces
 * `INTERNAL: Failed to initialize miniaudio decoder, error code: -10`.
 * We carry sample rate alongside the PCM and prepend a WAV header before
 * crossing the JNI boundary.
 */
data class AudioClip(
    val pcm: ByteArray,
    val sampleRate: Int,
) {
    /**
     * Build a self-contained WAV byte array (44-byte header + PCM payload),
     * which is the byte format LiteRT-LM's audio backend can decode.
     *
     * Mirrors `ChatMessageAudioClip.genByteArrayForWav` in AI Edge Gallery.
     */
    fun toWavBytes(): ByteArray {
        val pcmDataSize = pcm.size
        val wavFileSize = pcmDataSize + 36 // RIFF chunk header reports overall - 8
        val channels = 1
        val bitsPerSample: Short = 16
        val byteRate = sampleRate * channels * bitsPerSample / 8

        val header = ByteArray(44)

        // "RIFF" chunk
        header[0] = 'R'.code.toByte(); header[1] = 'I'.code.toByte()
        header[2] = 'F'.code.toByte(); header[3] = 'F'.code.toByte()
        header[4] = (wavFileSize and 0xff).toByte()
        header[5] = (wavFileSize shr 8 and 0xff).toByte()
        header[6] = (wavFileSize shr 16 and 0xff).toByte()
        header[7] = (wavFileSize shr 24 and 0xff).toByte()
        header[8] = 'W'.code.toByte(); header[9] = 'A'.code.toByte()
        header[10] = 'V'.code.toByte(); header[11] = 'E'.code.toByte()

        // "fmt " sub-chunk
        header[12] = 'f'.code.toByte(); header[13] = 'm'.code.toByte()
        header[14] = 't'.code.toByte(); header[15] = ' '.code.toByte()
        header[16] = 16; header[17] = 0; header[18] = 0; header[19] = 0  // sub-chunk size = 16
        header[20] = 1; header[21] = 0                                    // audio format = PCM
        header[22] = channels.toByte(); header[23] = 0                    // num channels
        header[24] = (sampleRate and 0xff).toByte()
        header[25] = (sampleRate shr 8 and 0xff).toByte()
        header[26] = (sampleRate shr 16 and 0xff).toByte()
        header[27] = (sampleRate shr 24 and 0xff).toByte()
        header[28] = (byteRate and 0xff).toByte()
        header[29] = (byteRate shr 8 and 0xff).toByte()
        header[30] = (byteRate shr 16 and 0xff).toByte()
        header[31] = (byteRate shr 24 and 0xff).toByte()
        header[32] = (channels * bitsPerSample / 8).toByte(); header[33] = 0  // block align
        header[34] = bitsPerSample.toByte(); header[35] = 0                   // bits per sample

        // "data" sub-chunk
        header[36] = 'd'.code.toByte(); header[37] = 'a'.code.toByte()
        header[38] = 't'.code.toByte(); header[39] = 'a'.code.toByte()
        header[40] = (pcmDataSize and 0xff).toByte()
        header[41] = (pcmDataSize shr 8 and 0xff).toByte()
        header[42] = (pcmDataSize shr 16 and 0xff).toByte()
        header[43] = (pcmDataSize shr 24 and 0xff).toByte()

        return header + pcm
    }

    /** Approximate duration in seconds, computed from PCM byte count. */
    val durationSeconds: Float
        get() = pcm.size / 2f / sampleRate.toFloat()

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is AudioClip) return false
        return sampleRate == other.sampleRate && pcm.contentEquals(other.pcm)
    }
    override fun hashCode(): Int = 31 * sampleRate + pcm.contentHashCode()
}
