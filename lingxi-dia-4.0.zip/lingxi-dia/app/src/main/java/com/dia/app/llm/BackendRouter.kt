package com.dia.app.llm

import android.graphics.Bitmap
import android.util.Base64
import android.util.Log
import com.dia.app.pilot.cloud.CloudLlmClient
import com.dia.app.prefs.DiaPrefs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream

/**
 * Routes a model call to either the on-device Gemma engine or the
 * configured cloud endpoint, based on the user's backend preference.
 *
 * Two modes (from [DiaPrefs]):
 *   - **Local only**: `cloudEnabled = false` → always local (default).
 *   - **Cloud only**: `cloudEnabled = true && cloud is configured` → always cloud.
 *
 * No "Auto" / no heuristic — keeps behaviour predictable and keeps the
 * routing matching what the user picked in Settings, every call.
 *
 * Any feature can also force a one-session override via [sessionOverride]
 * — useful for letting a screen flip itself to Local even when Settings
 * says Cloud (or vice-versa) without changing the user's global default.
 *
 * Cloud calls go through [CloudLlmClient] which already supports text +
 * one image (base64 PNG), and works against any OpenAI-compatible endpoint
 * (OpenAI, OpenRouter, Gemini, Ollama, LM Studio, etc).
 *
 * Cloud is non-streaming for now — we deliver the full reply in a single
 * onToken() call when it returns. Local stays streaming as before. The
 * caller's signature doesn't change either way.
 */
object BackendRouter {

    private const val TAG = "BackendRouter"

    /** Which backend was used for the last call. Surfaced in UI for debugging. */
    @Volatile var lastUsed: Backend = Backend.LOCAL
        private set

    /**
     * Per-session override. When non-null this beats the Settings choice,
     * so a feature can force itself to Local or Cloud for one session
     * without flipping the user's global default. Set to null to fall
     * back to Settings.
     */
    @Volatile var sessionOverride: Backend? = null

    enum class Backend { LOCAL, CLOUD }

    /**
     * Pick the backend to use for one request.
     *   1. [sessionOverride] wins if set (some feature forced itself).
     *   2. Otherwise: cloud iff Settings has cloud enabled AND cloud is
     *      configured. No heuristic, no auto-route — keeps the choice
     *      predictable.
     */
    fun pick(): Backend {
        sessionOverride?.let { return it }
        if (!DiaPrefs.cloudEnabled.value) return Backend.LOCAL
        if (!DiaPrefs.cloudIsConfigured()) return Backend.LOCAL
        return Backend.CLOUD
    }

    /** Clears the per-session override. */
    fun clearSessionOverride() { sessionOverride = null }

    /**
     * Single-turn call (used by Slate, Lens still-shot, Bubble, Pilot
     * one-shot, Chat single-message paths). The signature mirrors
     * [DiaEngine.sendSingleTurn] so call sites can swap with one line.
     */
    fun sendSingleTurn(
        text: String,
        images: List<Bitmap> = emptyList(),
        onToken: (partialResult: String, done: Boolean) -> Unit,
        onError: (message: String) -> Unit,
        systemInstruction: String? = null,
        temperature: Double = 0.4,
    ) {
        when (pick()) {
            Backend.LOCAL -> {
                lastUsed = Backend.LOCAL
                DiaEngine.sendSingleTurn(
                    text = text,
                    images = images,
                    onToken = onToken,
                    onError = onError,
                    systemInstruction = systemInstruction,
                    temperature = temperature,
                )
            }
            Backend.CLOUD -> {
                lastUsed = Backend.CLOUD
                callCloudSingleTurn(
                    text = text,
                    images = images,
                    onToken = onToken,
                    onError = onError,
                    systemInstruction = systemInstruction,
                    temperature = temperature,
                )
            }
        }
    }

    /**
     * Pilot-style turn: text only, with system instruction + history. Most
     * of the Pilot/Guide loop uses this. Local path goes through
     * [DiaEngine.sendPilotTurn]; cloud path goes through CloudLlmClient.
     */
    fun sendPilotTurn(
        systemInstruction: String,
        text: String,
        onToken: (partialResult: String, done: Boolean) -> Unit,
        onError: (message: String) -> Unit,
        temperature: Double = 0.2,
    ) {
        when (pick()) {
            Backend.LOCAL -> {
                lastUsed = Backend.LOCAL
                DiaEngine.sendPilotTurn(
                    systemInstruction = systemInstruction,
                    text = text,
                    onToken = onToken,
                    onError = onError,
                )
            }
            Backend.CLOUD -> {
                lastUsed = Backend.CLOUD
                callCloudSingleTurn(
                    text = text,
                    images = emptyList(),
                    onToken = onToken,
                    onError = onError,
                    systemInstruction = systemInstruction,
                    temperature = temperature,
                )
            }
        }
    }

    /**
     * Lens-style call: image + text + system prompt, single shot. Used by
     * the Lens Live screens (Think / Translate / Guide). This is the
     * same shape as [sendSingleTurn] but mirrors the original
     * [DiaEngine.sendLensQuery] signature so call sites can swap one to
     * one. Local goes through `sendLensQuery` (which keeps a Lens-only
     * conversation alive for follow-ups); cloud goes through the
     * shared cloud path.
     */
    fun sendLensTurn(
        text: String,
        image: Bitmap?,
        systemInstruction: String?,
        extraContext: Map<String, String> = emptyMap(),
        onToken: (partialResult: String, done: Boolean) -> Unit,
        onError: (message: String) -> Unit,
        temperature: Double = 0.4,
    ) {
        when (pick()) {
            Backend.LOCAL -> {
                lastUsed = Backend.LOCAL
                DiaEngine.sendLensQuery(
                    text = text,
                    image = image,
                    systemInstruction = systemInstruction,
                    extraContext = extraContext,
                    onToken = onToken,
                    onError = onError,
                )
            }
            Backend.CLOUD -> {
                lastUsed = Backend.CLOUD
                callCloudSingleTurn(
                    text = text,
                    images = listOfNotNull(image),
                    onToken = onToken,
                    onError = onError,
                    systemInstruction = systemInstruction,
                    temperature = temperature,
                )
            }
        }
    }

    /**
     * Lens-style translate call routed to the user's chosen backend.
     * Local goes through [DiaEngine.sendLensTranslate]; cloud uses the
     * same translation system prompt template but runs via the cloud
     * endpoint.
     */
    fun sendLensTranslate(
        image: Bitmap?,
        targetLanguage: String,
        onToken: (partialResult: String, done: Boolean) -> Unit,
        onError: (message: String) -> Unit,
    ) {
        when (pick()) {
            Backend.LOCAL -> {
                lastUsed = Backend.LOCAL
                DiaEngine.sendLensTranslate(
                    image = image,
                    targetLanguage = targetLanguage,
                    onToken = onToken,
                    onError = onError,
                )
            }
            Backend.CLOUD -> {
                lastUsed = Backend.CLOUD
                val systemPrompt = """You are a translation engine. Look at the image and find any visible text — signs, labels, screens, captions, handwriting, anything readable.

Your output MUST follow this exact format with TWO lines:
Line 1: the original text exactly as it appears.
Line 2: the translation of that text into $targetLanguage.

DO NOT add any prefixes, labels, arrows, dashes, or explanations.
DO NOT describe the scene or the image.
DO NOT use markdown, bullets, or quotation marks.

If the original is already in $targetLanguage, output Line 1 as the text and Line 2 as the same text (a copy).
If you cannot find any readable text, output exactly: No text detected"""
                callCloudSingleTurn(
                    text = "Translate any visible text in the image to $targetLanguage. Output exactly two lines.",
                    images = listOfNotNull(image),
                    onToken = onToken,
                    onError = onError,
                    systemInstruction = systemPrompt,
                    temperature = 0.2,
                )
            }
        }
    }

    /**
     * Lens-style multi-turn conversation. Local goes through
     * [DiaEngine.sendLensConversation]; cloud collapses to a single-turn
     * call (no rolling memory). Each call sends `image` if non-null —
     * over cloud the image is sent every turn since there's no
     * server-side conversation reuse.
     */
    fun sendLensConversation(
        text: String,
        image: Bitmap?,
        isFirstTurn: Boolean,
        onToken: (partialResult: String, done: Boolean) -> Unit,
        onError: (message: String) -> Unit,
        cloudSystemPrompt: String? = null,
    ) {
        when (pick()) {
            Backend.LOCAL -> {
                lastUsed = Backend.LOCAL
                DiaEngine.sendLensConversation(
                    text = text,
                    image = image,
                    isFirstTurn = isFirstTurn,
                    onToken = onToken,
                    onError = onError,
                )
            }
            Backend.CLOUD -> {
                lastUsed = Backend.CLOUD
                callCloudSingleTurn(
                    text = text,
                    images = listOfNotNull(image),
                    onToken = onToken,
                    onError = onError,
                    systemInstruction = cloudSystemPrompt
                        ?: "You are a visual guide. Look at the image and answer the user's question about it. Be concise.",
                    temperature = 0.3,
                )
            }
        }
    }

    /* ─── Cloud HTTP call ─── */

    @OptIn(kotlinx.coroutines.DelicateCoroutinesApi::class)
    private fun callCloudSingleTurn(
        text: String,
        images: List<Bitmap>,
        onToken: (partialResult: String, done: Boolean) -> Unit,
        onError: (message: String) -> Unit,
        systemInstruction: String?,
        temperature: Double,
    ) {
        // Snapshot config now in case the user changes prefs mid-flight.
        val baseUrl = DiaPrefs.cloudBaseUrl.value
        val apiKey = DiaPrefs.cloudApiKey.value
        val model = DiaPrefs.cloudModel.value

        if (baseUrl.isBlank() || model.isBlank()) {
            onError("Cloud not configured. Set base URL and model in Settings.")
            return
        }

        val client = CloudLlmClient(baseUrl, apiKey, model)
        val sysPrompt = systemInstruction
            ?: "You are a helpful assistant. Be concise and accurate."
        val firstImage = images.firstOrNull()
        val imageB64 = firstImage?.let { encodeBase64Png(it) }
        if (images.size > 1) {
            Log.w(TAG, "Cloud route only supports one image per turn; ignoring ${images.size - 1} extras.")
        }

        // Run on IO so we don't block the caller's thread (most call sites
        // are already on Dispatchers.IO, but the public contract has been
        // "non-blocking call returns immediately" so we keep that here).
        GlobalScope.launch(Dispatchers.IO) {
            val result = try {
                client.chat(
                    systemPrompt = sysPrompt,
                    userPrompt = text,
                    screenshotPngBase64 = imageB64,
                    history = emptyList(),
                    temperature = temperature,
                    maxTokens = 4096,
                )
            } catch (t: Throwable) {
                Log.e(TAG, "Cloud call threw", t)
                onError("Cloud error: ${t.message ?: t.javaClass.simpleName}")
                return@launch
            }
            val content = result.content
            if (content.isNullOrBlank()) {
                onError(result.error ?: "Cloud returned empty response")
            } else {
                // Surface the full reply in a single token, then signal done.
                // Streaming would be nice but cloud SSE adds complexity we
                // don't need today.
                onToken(content, false)
                onToken("", true)
            }
        }
    }

    private fun encodeBase64Png(bitmap: Bitmap): String? {
        return try {
            val baos = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos)
            val encoded = Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
            Log.d(TAG, "encodeBase64Png: ${bitmap.width}x${bitmap.height} → ${encoded.length} chars")
            encoded
        } catch (t: Throwable) {
            Log.e(TAG, "Bitmap → base64 failed", t)
            null
        }
    }
}
