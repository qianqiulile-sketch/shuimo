package com.dia.app.llm

import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Content
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.ExperimentalApi
import com.google.ai.edge.litertlm.ExperimentalFlags
import com.google.ai.edge.litertlm.Message
import com.google.ai.edge.litertlm.MessageCallback
import com.google.ai.edge.litertlm.SamplerConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.concurrent.CancellationException

private const val TAG = "DiaEngine"

private const val SYSTEM_INSTRUCTION =
    "You are Dia, a helpful, concise, and friendly AI assistant running locally on this device. " +
    "Keep responses clear and to the point. Use markdown formatting when helpful " +
    "(bold, lists, code blocks). Do not repeat the question back. " +
    "If you don't know something, say so briefly. Stay on topic."

/**
 * Application-level singleton wrapping LiteRT-LM Engine + Conversation.
 *
 * Scoped at Application level (not ViewModel) so the native session survives
 * navigation and ViewModel recreation. The ChatViewModel just references this.
 */
object DiaEngine {

    private var engine: Engine? = null
    private var conversation: Conversation? = null
    @Volatile
    private var pilotConversation: Conversation? = null
    private val pilotLock = Any()

    /**
     * Serializes calls to [initialize] / [unload] / [close] so that two
     * features kicking off model loads concurrently can never race the
     * native JNI layer. This is the belt-and-braces partner to
     * [ModelManager.mutex] — every public lifecycle method that touches
     * `engine`/`conversation` takes this lock.
     */
    private val initMutex = Mutex()

    private val _state = MutableStateFlow<ModelState>(ModelState.NotLoaded)
    val state: StateFlow<ModelState> = _state.asStateFlow()

    val isReady: Boolean
        get() = _state.value is ModelState.Ready

    private var loadedModelPath: String? = null

    /** Which backend is currently active */
    var activeBackend: String = "CPU"
        private set

    /** The path of the last loaded model, for reload */
    val currentModelPath: String?
        get() = loadedModelPath

    /**
     * Initialize the LiteRT-LM engine with the model at [modelPath].
     *
     * Tries GPU backend first, falls back to CPU if GPU fails.
     * Use [preferredBackend] to force a specific backend.
     *
     * Multi-Token Prediction (MTP / speculative decoding) is enabled before
     * each engine init — recommended for all tasks on GPU and for most tasks
     * on CPU per the LiteRT-LM Gemma 4 guidance, with significant decode
     * speedups and zero quality loss. The flag is reset right after
     * `engine.initialize()` so other engines created in the same process
     * (e.g. benchmarks) aren't affected.
     */
    @OptIn(ExperimentalApi::class)
    suspend fun initialize(
        context: Context,
        modelPath: String,
        preferredBackend: String? = null,
    ): Unit = initMutex.withLock {
        if (isReady && loadedModelPath == modelPath && (preferredBackend == null || preferredBackend == activeBackend)) {
            Log.d(TAG, "Already initialized with $modelPath on $activeBackend")
            return@withLock
        }

        closeLocked()

        if (!File(modelPath).exists()) {
            _state.value = ModelState.Error("Model file not found: $modelPath")
            return
        }

        val fileSize = File(modelPath).length()
        Log.d(TAG, "Model file size: ${fileSize / 1024 / 1024} MB")
        if (fileSize < 1_000_000) {
            _state.value = ModelState.Error(
                "Model file too small (${fileSize / 1024} KB). May be corrupted."
            )
            return
        }

        _state.value = ModelState.Loading("Preparing engine…")

        withContext(Dispatchers.IO) {
            val backends = when (preferredBackend) {
                "GPU" -> listOf("GPU" to Backend.GPU())
                "CPU" -> listOf("CPU" to Backend.CPU())
                else -> listOf("GPU" to Backend.GPU(), "CPU" to Backend.CPU())
            }

            for ((backendName, backend) in backends) {
                try {
                    _state.value = ModelState.Loading("Trying $backendName…")
                    Log.d(TAG, "Init with $backendName: $modelPath")

                    val newEngine = Engine(
                        EngineConfig(
                            modelPath = modelPath,
                            backend = backend,
                            visionBackend = if (backendName == "GPU") Backend.GPU() else Backend.CPU(),
                            audioBackend = Backend.CPU(),
                            // 上下文长度可在设置里调整（默认 4096）。对话里
                            // 带工具说明 + 记忆 + 历史时，8192 体验更好。
                            maxNumTokens = com.dia.app.prefs.DiaSettings.contextTokens.value
                                .coerceIn(2048, 32768),
                        )
                    )

                    _state.value = ModelState.Loading("Initializing $backendName…")
                    // MTP: turn on speculative decoding for the duration of
                    // engine.initialize(), then reset it. Per Google AI Edge
                    // recommendations this gives meaningful decode speedups
                    // on both CPU and GPU with zero quality drop.
                    ExperimentalFlags.enableSpeculativeDecoding = true
                    try {
                        newEngine.initialize()
                    } finally {
                        ExperimentalFlags.enableSpeculativeDecoding = false
                    }

                    _state.value = ModelState.Loading("Creating conversation…")
                    val newConversation = newEngine.createConversation(buildConversationConfig())

                    engine = newEngine
                    conversation = newConversation
                    loadedModelPath = modelPath
                    activeBackend = backendName

                    val modelName = File(modelPath).nameWithoutExtension
                    _state.value = ModelState.Ready("$modelName ($backendName)")
                    Log.d(TAG, "Ready on $backendName: $modelName")
                    return@withContext

                } catch (e: OutOfMemoryError) {
                    Log.e(TAG, "OOM on $backendName", e)
                    closeLocked()
                    _state.value = ModelState.InsufficientMemory(
                        "Not enough memory. Close some apps and try again."
                    )
                    return@withContext
                } catch (e: Exception) {
                    Log.e(TAG, "$backendName failed: ${e.message}", e)
                    try { engine?.close() } catch (_: Exception) {}
                    engine = null
                    conversation = null

                    if (backendName == backends.last().first) {
                        val msg = e.message ?: "Unknown error"
                        if (msg.contains("memory", true) || msg.contains("OOM", true)) {
                            _state.value = ModelState.InsufficientMemory(msg)
                        } else {
                            _state.value = ModelState.Error("Failed on all backends.\n\n$msg")
                        }
                        return@withContext
                    }
                    Log.w(TAG, "$backendName failed, trying next…")
                }
            }
        }
    }

    /**
     * Unload the model — release all native resources and go back to NotLoaded.
     *
     * Non-suspend for ergonomic use from menus / overflow actions. The
     * underlying [closeLocked] is safe to call without [initMutex] because
     * LiteRT-LM's `Engine.close()` is itself synchronized at the JNI layer
     * and our state writes are atomic.
     */
    fun unload() {
        closeLocked()
        _state.value = ModelState.NotLoaded
    }

    /**
     * Reload the current model, optionally on a different backend.
     */
    suspend fun reload(context: Context, backend: String? = null) {
        val path = loadedModelPath ?: return
        unload()
        initialize(context, path, backend)
    }

    // ─── Messaging ───

    /**
     * Send a message with optional images and audio.
     * Images are converted to PNG bytes, matching the Gallery's approach:
     * Content.ImageBytes(bitmap.toPngByteArray())
     */
    fun sendMessage(
        text: String,
        images: List<Bitmap> = emptyList(),
        audioClips: List<AudioClip> = emptyList(),
        thinking: Boolean = false,
        onToken: (partialResult: String, done: Boolean, thought: String?) -> Unit,
        onError: (message: String) -> Unit,
    ) {
        val eng = engine
        if (eng == null) {
            onError("Engine not initialized")
            return
        }

        // Lazily recreate the main conversation if a previous Pilot/Slate/Lens
        // turn closed it. Same retry logic used elsewhere to handle session
        // conflicts gracefully.
        if (conversation == null) {
            // Close any other lingering sessions first.
            val prevPilot = synchronized(pilotLock) {
                val p = pilotConversation
                pilotConversation = null
                p
            }
            if (prevPilot != null) {
                try { prevPilot.cancelProcess() } catch (_: Exception) {}
                try { prevPilot.close() } catch (_: Exception) {}
            }
            val prevLens = lensConversation
            lensConversation = null
            if (prevLens != null) {
                try { prevLens.cancelProcess() } catch (_: Exception) {}
                try { prevLens.close() } catch (_: Exception) {}
            }
            try { Thread.sleep(80) } catch (_: InterruptedException) {}

            var newConv: com.google.ai.edge.litertlm.Conversation? = null
            var delayMs = 250L
            for (attempt in 1..7) {
                try {
                    newConv = eng.createConversation(buildConversationConfig())
                    break
                } catch (e: Exception) {
                    val msg = e.message?.lowercase().orEmpty()
                    val isConflict = msg.contains("session already exists") ||
                        msg.contains("only one session") ||
                        msg.contains("failed_precondition")
                    if (!isConflict) throw e
                    Log.w(TAG, "Chat: session conflict attempt $attempt, sleeping ${delayMs}ms")
                    try { Thread.sleep(delayMs) } catch (_: InterruptedException) {}
                    delayMs = (delayMs * 2).coerceAtMost(1200L)
                }
            }
            if (newConv == null) {
                onError("Could not start chat session")
                return
            }
            conversation = newConv
        }

        val conv = conversation
        if (conv == null) {
            onError("Could not start chat session")
            return
        }

        try {
            // Build content list: images first, then audio, then text (Gallery pattern)
            val contents = mutableListOf<Content>()

            // Add images — wrapped individually so one bad image doesn't kill everything
            for (image in images) {
                try {
                    contents.add(Content.ImageBytes(image.toPngByteArray()))
                } catch (e: Exception) {
                    Log.e(TAG, "Failed to add image content", e)
                    // Skip this image, continue with others
                }
            }

            // Add audio clips — WAV-wrapped so LiteRT-LM's miniaudio
            // decoder can parse them. Raw PCM fails with miniaudio error -10.
            for (clip in audioClips) {
                try {
                    val wav = clip.toWavBytes()
                    Log.d(
                        TAG,
                        "Audio: ${clip.pcm.size} pcm bytes @ ${clip.sampleRate} Hz → ${wav.size} wav bytes (header=${wav.take(4).joinToString("") { (it.toInt() and 0xff).toChar().toString() }})",
                    )
                    contents.add(Content.AudioBytes(wav))
                } catch (e: Exception) {
                    Log.e(TAG, "Failed to add audio content", e)
                }
            }

            // Always add text last (Gallery pattern)
            if (text.trim().isNotEmpty()) {
                contents.add(Content.Text(text))
            }

            // Must have at least one content piece
            if (contents.isEmpty()) {
                onError("No content to send")
                return
            }

            conv.sendMessageAsync(
                Contents.of(contents),
                object : MessageCallback {
                    override fun onMessage(message: Message) {
                        try {
                            // Gemma 4's thinking trace lives in
                            // message.channels["thought"] — separate from
                            // the visible answer text. Surface both via
                            // the same callback so the VM can place
                            // tokens into the right slot.
                            onToken(
                                message.toString(),
                                false,
                                message.channels["thought"]?.takeIf { it.isNotEmpty() },
                            )
                        } catch (e: Exception) {
                            Log.e(TAG, "Error processing token", e)
                        }
                    }

                    override fun onDone() {
                        onToken("", true, null)
                    }

                    override fun onError(throwable: Throwable) {
                        if (throwable is CancellationException) {
                            Log.i(TAG, "Inference cancelled")
                            onToken("", true, null)
                        } else {
                            Log.e(TAG, "Inference error", throwable)
                            onError("Error: ${throwable.message}")
                        }
                    }
                },
                if (thinking) mapOf("enable_thinking" to "true") else emptyMap(),
            )
        } catch (e: Exception) {
            Log.e(TAG, "sendMessage crashed", e)
            onError("Send failed: ${e.message}")
        }
    }

    /**
     * Single-turn query using a FRESH temporary conversation.
     * Used by Lens to avoid corrupting the main Chat conversation.
     * Creates a new conversation, sends the message, then closes it.
     */
    fun sendSingleTurn(
        text: String,
        images: List<Bitmap> = emptyList(),
        onToken: (partialResult: String, done: Boolean) -> Unit,
        onError: (message: String) -> Unit,
        systemInstruction: String? = null,
        /**
         * Override the default sampling temperature. Lower values (e.g.
         * 0.05) yield more deterministic output — useful for grading,
         * classification, and other tasks where you want the same input
         * to give the same answer every time.
         */
        temperature: Double = 0.4,
    ) {
        val eng = engine
        if (eng == null) {
            onError("Engine not initialized")
            return
        }
        if (text.trim().isEmpty() && images.isEmpty()) {
            onError("No content to send")
            return
        }

        try {
            // Close ALL sessions and wait for native release.
            closeAllConversationsForPilot()

            val sysText = systemInstruction
                ?: "You are a helpful vision assistant. Describe what you see accurately and concisely."
            val config = ConversationConfig(
                samplerConfig = SamplerConfig(topK = 40, topP = 0.92, temperature = temperature),
                systemInstruction = Contents.of(listOf(Content.Text(sysText))),
            )

            val tempConv = createPilotConversationWithRetry(eng, config)
            if (tempConv == null) {
                onError("Could not create session after retries")
                return
            }

            val contents = mutableListOf<Content>()
            for (image in images) {
                try {
                    contents.add(Content.ImageBytes(image.toPngByteArray()))
                } catch (e: Exception) {
                    Log.e(TAG, "SingleTurn: image encode failed", e)
                }
            }
            if (text.trim().isNotEmpty()) {
                contents.add(Content.Text(text))
            }
            if (contents.isEmpty()) {
                try { tempConv.close() } catch (_: Exception) {}
                onError("No content to send")
                return
            }

            // Use synchronous latch — blocks until inference completes.
            // This guarantees the session is fully done before we return,
            // so the next caller never hits "session already exists".
            val latch = java.util.concurrent.CountDownLatch(1)
            val sb = StringBuilder()
            val errorRef = java.util.concurrent.atomic.AtomicReference<String?>(null)

            tempConv.sendMessageAsync(
                Contents.of(contents),
                object : MessageCallback {
                    override fun onMessage(message: Message) {
                        try {
                            val token = message.toString()
                            sb.append(token)
                            onToken(token, false)
                        } catch (e: Exception) { Log.e(TAG, "SingleTurn token error", e) }
                    }
                    override fun onDone() {
                        latch.countDown()
                    }
                    override fun onError(throwable: Throwable) {
                        if (throwable !is CancellationException) {
                            errorRef.set(throwable.message)
                        }
                        latch.countDown()
                    }
                },
                emptyMap(),
            )

            // Wait up to 60s for inference to complete.
            latch.await(60, java.util.concurrent.TimeUnit.SECONDS)

            // Close the conversation SYNCHRONOUSLY before returning.
            try { tempConv.cancelProcess() } catch (_: Exception) {}
            try { tempConv.close() } catch (_: Exception) {}
            // Small settle for native layer.
            try { Thread.sleep(100) } catch (_: InterruptedException) {}

            val err = errorRef.get()
            if (err != null) {
                onError("Vision error: $err")
            } else {
                onToken("", true)
            }
        } catch (e: Exception) {
            Log.e(TAG, "sendSingleTurn crashed", e)
            onError("Vision failed: ${e.message}")
        }
    }

    /**
     * Pilot single-turn with a custom system instruction.
     *
     * Stateless — each call creates a fresh conversation and closes it on
     * completion so the input token count never drifts upward across the
     * agent loop. Pilot keeps its own screen/history context in the prompt,
     * so the engine doesn't need to.
     *
     * Hardened against LiteRT-LM's async close behaviour: if we hit
     * "session already exists" while creating the new conversation we retry
     * with backoff, and as a last resort close the old session from the lock
     * and create again. Matches PokeClaw's LocalModelRuntime pattern.
     */
    fun sendPilotTurn(
        systemInstruction: String,
        text: String,
        onToken: (partialResult: String, done: Boolean) -> Unit,
        onError: (message: String) -> Unit,
    ) {
        val eng = engine
        if (eng == null) {
            onError("Engine not initialized")
            return
        }
        if (text.trim().isEmpty()) {
            onError("No content to send")
            return
        }

        try {
            val pilotConfig = ConversationConfig(
                samplerConfig = SamplerConfig(topK = 40, topP = 0.9, temperature = 0.2),
                systemInstruction = Contents.of(listOf(Content.Text(systemInstruction))),
            )

            // Always tear down any prior session before starting a pilot turn.
            closeAllConversationsForPilot()

            val tempConv = createPilotConversationWithRetry(eng, pilotConfig)
                ?: run {
                    onError("Pilot session not available")
                    return
                }

            synchronized(pilotLock) { pilotConversation = tempConv }

            // We use the synchronous sendMessage() API here. It blocks this
            // background thread (the caller is already on Dispatchers.IO via
            // suspendCancellableCoroutine) until the engine has fully finished
            // inference — which also means it has released its session slot
            // by the time we close. That is what makes back-to-back Pilot
            // turns race-free.
            try {
                val response = runBlockingSend(tempConv, text)
                onToken(response.orEmpty(), false)
                onToken("", true)
            } catch (e: CancellationException) {
                onToken("", true)
            } catch (e: Throwable) {
                Log.e(TAG, "Pilot inference error", e)
                onError("Pilot error: ${e.message}")
            } finally {
                // Close this turn's conversation so the next call starts from
                // a clean token budget and a free session slot.
                val toClose = synchronized(pilotLock) {
                    val p = pilotConversation
                    pilotConversation = null
                    p
                }
                if (toClose != null) {
                    try { toClose.cancelProcess() } catch (_: Exception) {}
                    try { toClose.close() } catch (_: Exception) {}
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "sendPilotTurn crashed", e)
            onError("Pilot failed: ${e.message}")
        }
    }

    /** Synchronously run sendMessage using the streaming API, collecting tokens. */
    private fun runBlockingSend(conv: com.google.ai.edge.litertlm.Conversation, text: String): String? {
        val latch = java.util.concurrent.CountDownLatch(1)
        val sb = StringBuilder()
        val errorRef = java.util.concurrent.atomic.AtomicReference<Throwable?>(null)

        conv.sendMessageAsync(
            Contents.of(listOf(Content.Text(text))),
            object : MessageCallback {
                override fun onMessage(message: Message) {
                    try { sb.append(message.toString()) } catch (e: Exception) { Log.e(TAG, "Pilot token append error", e) }
                }

                override fun onDone() { latch.countDown() }

                override fun onError(throwable: Throwable) {
                    errorRef.set(throwable)
                    latch.countDown()
                }
            },
            emptyMap(),
        )

        // 60s hard ceiling — per-turn; more than enough for local inference.
        latch.await(60, java.util.concurrent.TimeUnit.SECONDS)
        errorRef.get()?.let { throw it }
        return sb.toString()
    }

    /** Close ALL active conversations before starting a new one. */
    private fun closeAllConversationsForPilot() {
        // Close main chat conversation
        val main = conversation
        conversation = null
        if (main != null) {
            try { main.cancelProcess() } catch (_: Exception) {}
            try { main.close() } catch (_: Exception) {}
        }
        // Close pilot conversation
        val prevPilot = synchronized(pilotLock) {
            val p = pilotConversation
            pilotConversation = null
            p
        }
        if (prevPilot != null) {
            try { prevPilot.cancelProcess() } catch (_: Exception) {}
            try { prevPilot.close() } catch (_: Exception) {}
        }
        // Close lens/translate conversation
        val prevLens = lensConversation
        lensConversation = null
        if (prevLens != null) {
            try { prevLens.cancelProcess() } catch (_: Exception) {}
            try { prevLens.close() } catch (_: Exception) {}
        }
        closeGenConversation()
        // LiteRT-LM's close() is async at native layer — give the engine
        // enough time to actually release the session slot.
        try { Thread.sleep(200) } catch (_: InterruptedException) { Thread.currentThread().interrupt() }
    }

    /**
     * Create a pilot conversation, with up to 6 retries on session conflicts.
     * Matches the backoff pattern PokeClaw's LocalModelRuntime.openConversation uses.
     */
    private fun createPilotConversationWithRetry(
        eng: Engine,
        cfg: ConversationConfig,
    ): com.google.ai.edge.litertlm.Conversation? {
        var lastError: Exception? = null
        var delayMs = 250L
        for (attempt in 1..7) {
            try {
                return eng.createConversation(cfg)
            } catch (e: Exception) {
                lastError = e
                val msg = e.message?.lowercase().orEmpty()
                val isConflict =
                    msg.contains("session already exists") ||
                    msg.contains("only one session") ||
                    msg.contains("session already in use") ||
                    msg.contains("failed_precondition")
                if (!isConflict) throw e

                Log.w(TAG, "Pilot: session conflict on attempt $attempt, sleeping ${delayMs}ms and retrying")
                try { Thread.sleep(delayMs) } catch (_: InterruptedException) {
                    Thread.currentThread().interrupt()
                    return null
                }
                // Grow the wait — native close can be slow under load.
                delayMs = (delayMs * 2).coerceAtMost(1200L)

                // Final attempt: force-close anything we still reference.
                if (attempt >= 5) {
                    val main = conversation
                    conversation = null
                    try { main?.cancelProcess() } catch (_: Exception) {}
                    try { main?.close() } catch (_: Exception) {}
                    val p = synchronized(pilotLock) {
                        val cur = pilotConversation
                        pilotConversation = null
                        cur
                    }
                    try { p?.cancelProcess() } catch (_: Exception) {}
                    try { p?.close() } catch (_: Exception) {}
                }
            }
        }
        Log.e(TAG, "Pilot: gave up creating conversation after retries", lastError)
        return null
    }

    fun cancelPilotSession() {
        val prev = synchronized(pilotLock) {
            val current = pilotConversation
            pilotConversation = null
            current
        }
        if (prev != null) {
            try { prev.cancelProcess() } catch (_: Exception) {}
            try { prev.close() } catch (_: Exception) {}
        }
        // Restore main conversation after pilot finishes
        val eng = engine ?: return
        if (conversation == null) {
            try { conversation = eng.createConversation(buildConversationConfig()) } catch (_: Exception) {}
        }
    }

    // Dedicated lens conversation tracker to avoid session conflicts
    @Volatile
    private var lensConversation: com.google.ai.edge.litertlm.Conversation? = null

    /**
     * Closes ALL conversations (lens + main) and waits for the engine to release the session slot.
     * LiteRT-LM's close() is internally async — the session isn't freed instantly.
     */
    private fun closeAllConversations() {
        val prevLens = lensConversation
        lensConversation = null
        if (prevLens != null) {
            try { prevLens.cancelProcess() } catch (_: Exception) {}
            try { prevLens.close() } catch (_: Exception) {}
            Log.d(TAG, "LensLive: closed previous lens conversation")
        }

        val mainConv = conversation
        conversation = null
        if (mainConv != null) {
            try { mainConv.cancelProcess() } catch (_: Exception) {}
            try { mainConv.close() } catch (_: Exception) {}
            Log.d(TAG, "LensLive: closed main conversation")
        }
        closeGenConversation()
    }

    private fun closeGenConversation() {
        val g = genConversation
        genConversation = null
        if (g != null) {
            try { g.cancelProcess() } catch (_: Exception) {}
            try { g.close() } catch (_: Exception) {}
        }
    }

    /**
     * Lens Live query — optimized for continuous realtime camera + voice usage.
     * Creates a fresh conversation per query to avoid context growth that degrades performance.
     *
     * Uses retry logic because LiteRT-LM's close() is async — the engine may still
     * think a session is active for a short time after close() returns.
     */
    fun sendLensQuery(
        text: String,
        image: Bitmap?,
        onToken: (partialResult: String, done: Boolean) -> Unit,
        onError: (message: String) -> Unit,
        systemInstruction: String? = null,
        extraContext: Map<String, Any> = emptyMap(),
    ) {
        val eng = engine
        if (eng == null) {
            onError("Engine not initialized")
            return
        }

        try {
            // Close everything first to ensure the backend session slot is freed
            closeAllConversations()

            // Recreate conversational context cleanly. Caller can override
            // the system prompt to flip Lens Live between describe / answer
            // / solve modes without baking the prompt into the user content.
            val sysText = systemInstruction
                ?: ("You are a realtime vision assistant. The user is speaking to you while showing their camera. " +
                    "Describe what you ACTUALLY see in the image — the person's posture, actions, surroundings, objects. " +
                    "Respond concisely in 1-3 sentences. Be natural and conversational. Focus on the image content.")
            val lensConfig = ConversationConfig(
                samplerConfig = SamplerConfig(topK = 40, topP = 0.92, temperature = 0.4),
                systemInstruction = Contents.of(listOf(Content.Text(sysText))),
            )

            var tempConv: com.google.ai.edge.litertlm.Conversation? = null
            for (i in 0..4) {
                try {
                    tempConv = eng.createConversation(lensConfig)
                    break
                } catch (e: Exception) {
                    val msg = e.message?.lowercase() ?: ""
                    if (msg.contains("session") || msg.contains("exist")) {
                        Log.w(TAG, "LensLive: Native session busy/closing. Waiting 150ms... (Attempt $i)")
                        Thread.sleep(150)
                    } else {
                        throw e
                    }
                }
            }
            if (tempConv == null) {
                tempConv = eng.createConversation(lensConfig)
            }
            Log.d(TAG, "LensLive: conversation created cleanly")

            lensConversation = tempConv

            val contents = mutableListOf<Content>()
            if (image != null) {
                try {
                    contents.add(Content.ImageBytes(image.toPngByteArray()))
                    Log.d(TAG, "LensLive: image added to query")
                } catch (e: Exception) {
                    Log.e(TAG, "LensLive: failed to encode frame", e)
                }
            } else {
                Log.w(TAG, "LensLive: NO IMAGE available for query!")
            }
            if (text.trim().isNotEmpty()) {
                contents.add(Content.Text(text))
            }
            if (contents.isEmpty()) {
                try { tempConv.close() } catch (_: Exception) {}
                lensConversation = null
                onError("No content to send")
                return
            }

            val conv = tempConv  // capture for callback
            conv.sendMessageAsync(
                Contents.of(contents),
                object : MessageCallback {
                    override fun onMessage(message: Message) {
                        try { onToken(message.toString(), false) } catch (e: Exception) { Log.e(TAG, "LensLive token error", e) }
                    }
                    override fun onDone() {
                        Log.d(TAG, "LensLive: query done")
                        onToken("", true)
                    }
                    override fun onError(throwable: Throwable) {
                        Log.e(TAG, "LensLive: callback error", throwable)
                        if (throwable is CancellationException) {
                            onToken("", true)
                        } else {
                            onError("Vision error: ${throwable.message}")
                        }
                    }
                },
                extraContext,
            )
        } catch (e: Exception) {
            Log.e(TAG, "sendLensQuery crashed", e)
            lensConversation = null
            onError("Vision failed: ${e.message}")
        }
    }

    /**
     * Translate mode — single-turn query with a translation-specific system prompt.
     *
     * The model is asked to emit two clean lines (original + translated)
     * separated by a newline, no arrow, no markdown. The screen splits on
     * the first newline to render side-by-side.
     */
    fun sendLensTranslate(
        image: Bitmap?,
        targetLanguage: String = "English",
        onToken: (partialResult: String, done: Boolean) -> Unit,
        onError: (message: String) -> Unit,
    ) {
        val eng = engine
        if (eng == null) { onError("Engine not initialized"); return }

        try {
            closeAllConversations()

            val systemPrompt = """You are a translation engine. Look at the image and find any visible text — signs, labels, screens, captions, handwriting, anything readable.

Your output MUST follow this exact format with TWO lines:
Line 1: the original text exactly as it appears.
Line 2: the translation of that text into $targetLanguage.

DO NOT add any prefixes, labels, arrows, dashes, or explanations.
DO NOT describe the scene or the image.
DO NOT use markdown, bullets, or quotation marks.

If the original is already in $targetLanguage, output Line 1 as the text and Line 2 as the same text (a copy).
If you cannot find any readable text, output exactly: No text detected"""

            val translateConfig = ConversationConfig(
                samplerConfig = SamplerConfig(topK = 40, topP = 0.92, temperature = 0.2),
                systemInstruction = Contents.of(listOf(Content.Text(systemPrompt))),
            )

            var tempConv: com.google.ai.edge.litertlm.Conversation? = null
            for (i in 0..4) {
                try { tempConv = eng.createConversation(translateConfig); break }
                catch (e: Exception) {
                    val msg = e.message?.lowercase() ?: ""
                    if (msg.contains("session") || msg.contains("exist")) { Thread.sleep(150) } else throw e
                }
            }
            if (tempConv == null) tempConv = eng.createConversation(translateConfig)
            lensConversation = tempConv

            val contents = mutableListOf<Content>()
            if (image != null) {
                try { contents.add(Content.ImageBytes(image.toPngByteArray())) } catch (e: Exception) { Log.e(TAG, "Translate: image encode failed", e) }
            }
            contents.add(Content.Text("Read the text in this image and translate it to $targetLanguage. Output only the original on line 1 and the $targetLanguage translation on line 2."))

            val conv = tempConv
            conv.sendMessageAsync(
                Contents.of(contents),
                object : MessageCallback {
                    override fun onMessage(message: Message) { try { onToken(message.toString(), false) } catch (_: Exception) {} }
                    override fun onDone() { onToken("", true) }
                    override fun onError(throwable: Throwable) {
                        if (throwable is CancellationException) onToken("", true)
                        else onError("Translation error: ${throwable.message}")
                    }
                },
                emptyMap(),
            )
        } catch (e: Exception) {
            Log.e(TAG, "sendLensTranslate crashed", e)
            lensConversation = null
            onError("Translation failed: ${e.message}")
        }
    }

    /**
     * Guide mode — multi-turn conversation WITH image context.
     * First call creates a new conversation with image. Subsequent calls reuse
     * the same conversation for natural back-and-forth.
     *
     * @param isFirstTurn Pass true for the first message (attaches image context). Subsequent messages are text-only.
     */
    fun sendLensConversation(
        text: String,
        image: Bitmap?,
        isFirstTurn: Boolean,
        onToken: (partialResult: String, done: Boolean) -> Unit,
        onError: (message: String) -> Unit,
    ) {
        val eng = engine
        if (eng == null) { onError("Engine not initialized"); return }

        try {
            if (isFirstTurn) {
                // Start a fresh guide conversation
                closeAllConversations()

                val guideConfig = ConversationConfig(
                    samplerConfig = SamplerConfig(topK = 40, topP = 0.92, temperature = 0.3),
                    systemInstruction = Contents.of(listOf(
                        Content.Text(
                            """You are a visual guide. The user points their phone camera at something and asks what to do or where to find things. EVERY answer must be grounded in what is actually visible in the image they just sent — never use prior knowledge of apps, products, layouts, or places.

═══════════════ TASK ═══════════════

The user is in front of a screen, sign, document, room, machine, or interface. They ask things like:
  • "Where is X?" — find X in the image and point at it.
  • "How do I do Y?" — describe the action using only buttons, controls, or paths VISIBLE in the image.
  • "What does this say / mean?" — read the visible text.
  • "What's the next step?" — describe the next visible action.

═══════════════ HARD RULES ═══════════════

1. GROUND EVERYTHING IN THE IMAGE. If something is not in the current frame, say so:
       "I can't see X in this frame. Try moving the camera so it's in view."
   Do NOT guess. Do NOT recall from prior knowledge.

2. POINT ONLY WHEN APPROPRIATE. Emit a [BOX] line ONLY when the user asks you to LOCATE or POINT AT a specific element ("where is X", "find X", "show me X"). Do NOT emit a [BOX] when the user just asks a general question, asks what something says, or asks a follow-up.

3. WHEN POINTING, use this EXACT format on the FIRST line, alone, and ONLY ONCE per reply:
       [BOX:x1,y1,x2,y2]
   Coordinates are normalized 0.0-1.0 (top-left = 0,0 ; bottom-right = 1,1). The box must enclose the actual visible thing TIGHTLY — no looser than necessary. Be PRECISE. If you're not confident the thing is in the frame, do not emit a box at all.

4. AFTER THE BOX (or as your only output when not pointing), write 1-2 short sentences. Refer to neighbouring visible elements ("just under the search bar", "to the left of the menu icon") instead of names you might know from outside the image.

5. CITE WHAT YOU SEE. When you mention a button or control, describe its visible appearance: "the blue circle with a paper-plane icon", "the row labelled 'Inbox'", etc.

6. NO FLUFF. No "great question", no "I can see", no "the image shows", no markdown headings, no lists.

═══════════════ EXAMPLES ═══════════════

User: "Where is the search button?"
Frame contains a clear magnifying-glass icon at top-right.
Reply:
[BOX:0.85,0.05,0.95,0.13]
Top-right, the magnifying-glass icon next to your profile picture.

User: "How do I send a message?"
Frame contains an open chat with a text field and a paper-plane button.
Reply:
[BOX:0.88,0.78,0.96,0.86]
Type in the field at the bottom, then tap the blue paper-plane on its right.

User: "Where can I find settings?"
Frame contains only a homepage with no settings icon.
Reply:
I can't see a settings option in this frame. Try opening the menu — usually three lines at the top-left — so it shows in view.

User: "What does this sign say?"
Frame contains a sign reading "PUSH".
Reply:
It says PUSH.

(Note: no BOX in the last reply — the user wasn't asking to locate, they were asking to read.)

═══════════════ END ═══════════════"""
                        )
                    )),
                )

                var tempConv: com.google.ai.edge.litertlm.Conversation? = null
                for (i in 0..4) {
                    try { tempConv = eng.createConversation(guideConfig); break }
                    catch (e: Exception) {
                        val msg = e.message?.lowercase() ?: ""
                        if (msg.contains("session") || msg.contains("exist")) { Thread.sleep(150) } else throw e
                    }
                }
                if (tempConv == null) tempConv = eng.createConversation(guideConfig)
                lensConversation = tempConv
            }

            val conv = lensConversation
            if (conv == null) { onError("No active guide session"); return }

            val contents = mutableListOf<Content>()
            // Attach image on the first turn — ALWAYS include it for visual context
            if (image != null) {
                try {
                    contents.add(Content.ImageBytes(image.toPngByteArray()))
                    Log.d(TAG, "Guide: image attached (firstTurn=$isFirstTurn)")
                } catch (e: Exception) { Log.e(TAG, "Guide: image encode failed", e) }
            } else {
                Log.w(TAG, "Guide: NO IMAGE available!")
            }
            val userText = if (isFirstTurn)
                "Look ONLY at the image above. Question: ${text.trim()}\n\nRemember: ground your answer in what's visible. If the thing isn't in the image, say so."
            else
                "Look at the latest image (above). Question: ${text.trim()}\n\nRemember: ground your answer in what's visible. If the thing isn't in this frame, say so."
            if (userText.isNotEmpty()) contents.add(Content.Text(userText))
            if (contents.isEmpty()) { onError("No content to send"); return }

            conv.sendMessageAsync(
                Contents.of(contents),
                object : MessageCallback {
                    override fun onMessage(message: Message) { try { onToken(message.toString(), false) } catch (_: Exception) {} }
                    override fun onDone() { onToken("", true) }
                    override fun onError(throwable: Throwable) {
                        if (throwable is CancellationException) onToken("", true)
                        else onError("Guide error: ${throwable.message}")
                    }
                },
                emptyMap(),
            )
        } catch (e: Exception) {
            Log.e(TAG, "sendLensConversation crashed", e)
            onError("Guide failed: ${e.message}")
        }
    }

    // ─── 统一对话生成（灵犀对话主界面 / 记忆提取 / 自循环使用） ───

    @Volatile
    private var genConversation: Conversation? = null

    /**
     * 无状态的单次生成：每次都新建一个 Conversation，历史由调用方拼进
     * [text]，结束后立即关闭。这样可以随时继续任何历史对话，也不会因为
     * 会话累积导致 token 超限。
     *
     * - 流式回调 [onDelta]：(新增可见文本, 新增思考文本)
     * - 协程被取消时会调用 cancelProcess() 立刻停止推理
     * - [timeoutMs] 到时返回已生成的部分
     *
     * @return 完整的可见文本
     */
    suspend fun generate(
        systemInstruction: String,
        text: String,
        images: List<Bitmap> = emptyList(),
        audioClips: List<AudioClip> = emptyList(),
        temperature: Double = 0.6,
        thinking: Boolean = false,
        timeoutMs: Long = 180_000L,
        onDelta: (delta: String, thought: String?) -> Unit = { _, _ -> },
    ): String = withContext(Dispatchers.IO) {
        val eng = engine ?: throw IllegalStateException("模型未加载")
        closeAllConversationsForPilot()
        val prevGen = genConversation
        genConversation = null
        if (prevGen != null) {
            try { prevGen.cancelProcess() } catch (_: Exception) {}
            try { prevGen.close() } catch (_: Exception) {}
        }

        val config = ConversationConfig(
            samplerConfig = SamplerConfig(topK = 40, topP = 0.92, temperature = temperature),
            systemInstruction = Contents.of(listOf(Content.Text(systemInstruction))),
        )
        val conv = createPilotConversationWithRetry(eng, config)
            ?: throw IllegalStateException("无法创建推理会话，请稍后重试")
        genConversation = conv

        val contents = mutableListOf<Content>()
        for (image in images) {
            try { contents.add(Content.ImageBytes(image.toPngByteArray())) } catch (e: Exception) {
                Log.e(TAG, "generate: image encode failed", e)
            }
        }
        for (clip in audioClips) {
            try { contents.add(Content.AudioBytes(clip.toWavBytes())) } catch (e: Exception) {
                Log.e(TAG, "generate: audio encode failed", e)
            }
        }
        if (text.isNotBlank()) contents.add(Content.Text(text))
        if (contents.isEmpty()) {
            try { conv.close() } catch (_: Exception) {}
            genConversation = null
            throw IllegalArgumentException("没有可发送的内容")
        }

        val sb = StringBuilder()
        try {
            kotlinx.coroutines.withTimeoutOrNull(timeoutMs) {
                kotlinx.coroutines.suspendCancellableCoroutine<Unit> { cont ->
                    cont.invokeOnCancellation {
                        try { conv.cancelProcess() } catch (_: Exception) {}
                    }
                    try {
                        conv.sendMessageAsync(
                            Contents.of(contents),
                            object : MessageCallback {
                                override fun onMessage(message: Message) {
                                    try {
                                        val delta = message.toString()
                                        val thought = message.channels["thought"]?.takeIf { it.isNotEmpty() }
                                        if (delta.isNotEmpty()) sb.append(delta)
                                        if (delta.isNotEmpty() || thought != null) onDelta(delta, thought)
                                    } catch (e: Exception) {
                                        Log.e(TAG, "generate token error", e)
                                    }
                                }

                                override fun onDone() {
                                    if (cont.isActive) cont.resumeWith(Result.success(Unit))
                                }

                                override fun onError(throwable: Throwable) {
                                    if (!cont.isActive) return
                                    if (throwable is CancellationException) {
                                        cont.resumeWith(Result.success(Unit))
                                    } else {
                                        cont.resumeWith(Result.failure(throwable))
                                    }
                                }
                            },
                            if (thinking) mapOf("enable_thinking" to "true") else emptyMap(),
                        )
                    } catch (e: Exception) {
                        if (cont.isActive) cont.resumeWith(Result.failure(e))
                    }
                }
            }
        } finally {
            try { conv.cancelProcess() } catch (_: Exception) {}
            try { conv.close() } catch (_: Exception) {}
            if (genConversation === conv) genConversation = null
            try { Thread.sleep(60) } catch (_: InterruptedException) {}
        }
        sb.toString()
    }

    /** 立即停止 [generate] 中正在进行的推理。 */
    fun cancelGenerate() {
        try { genConversation?.cancelProcess() } catch (_: Exception) {}
    }

    /** Cancel any active lens generation + close the lens conversation */
    fun cancelLensQuery() {
        closeAllConversations()
    }

    fun cancelGeneration() {
        try {
            conversation?.cancelProcess()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to cancel", e)
        }
    }

    fun resetConversation() {
        try {
            conversation?.close()
            conversation = engine?.createConversation(buildConversationConfig())
            Log.d(TAG, "Conversation reset")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to reset conversation", e)
        }
    }

    private fun buildConversationConfig(): ConversationConfig {
        return ConversationConfig(
            samplerConfig = SamplerConfig(
                topK = 40,
                topP = 0.92,
                temperature = 0.7,
            ),
            systemInstruction = Contents.of(
                listOf(Content.Text(SYSTEM_INSTRUCTION))
            ),
        )
    }

    fun close() {
        closeLocked()
    }

    /**
     * Same as [close] but assumes the caller already holds [initMutex].
     * Internal lifecycle paths use this.
     */
    private fun closeLocked() {
        closeAllConversations()
        cancelPilotSession()
        try { engine?.close() } catch (e: Exception) { Log.e(TAG, "Engine close", e) }
        engine = null
        loadedModelPath = null
        if (_state.value is ModelState.Ready || _state.value is ModelState.Loading) {
            _state.value = ModelState.NotLoaded
        }
    }

    // ─── Helpers ───

    /** Match Gallery's exact encoding: PNG 100% on already-sampled bitmap */
    private fun Bitmap.toPngByteArray(): ByteArray {
        val stream = ByteArrayOutputStream()
        this.compress(Bitmap.CompressFormat.PNG, 100, stream)
        Log.d(TAG, "Image encoded: ${stream.size() / 1024}KB (${width}x${height})")
        return stream.toByteArray()
    }
}
