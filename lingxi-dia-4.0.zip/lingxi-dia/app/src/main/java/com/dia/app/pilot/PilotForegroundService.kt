package com.dia.app.pilot

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.dia.app.MainActivity
import com.dia.app.R

/**
 * Lightweight foreground service that runs while Pilot is executing a task.
 *
 * Purpose: raise Dia's process priority so Android doesn't kill it when the
 * assistant is in the background controlling another app. Also grabs a
 * partial wake lock so the CPU keeps running for inference during the task.
 */
class PilotForegroundService : Service() {

    companion object {
        private const val TAG = "PilotForegroundService"
        private const val CHANNEL_ID = "dia_pilot_channel"
        private const val NOTIFICATION_ID = 4711
        private const val EXTRA_TITLE = "title"
        private const val EXTRA_TEXT = "text"
        private const val WAKELOCK_TAG = "Dia::PilotWakeLock"

        @Volatile
        private var running = false

        fun isRunning(): Boolean = running

        fun start(context: Context, title: String, text: String) {
            // Notifications are optional — we start the service even without them.
            val intent = Intent(context, PilotForegroundService::class.java).apply {
                putExtra(EXTRA_TITLE, title)
                putExtra(EXTRA_TEXT, text)
            }
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            } catch (e: Exception) {
                Log.w(TAG, "startForegroundService blocked: ${e.message}")
            }
        }

        /** Update the ongoing notification text without restarting the service. */
        fun update(context: Context, title: String, text: String) {
            if (!running) return
            try {
                val appCtx = context.applicationContext
                val mgr = appCtx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

                // Ensure channel exists (may be called before onCreate on some OEMs)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    if (mgr.getNotificationChannel(CHANNEL_ID) == null) {
                        val channel = NotificationChannel(
                            CHANNEL_ID, "灵犀 Pilot", NotificationManager.IMPORTANCE_LOW
                        ).apply {
                            description = "Pilot 控制你的手机时显示"
                            setShowBadge(false)
                        }
                        mgr.createNotificationChannel(channel)
                    }
                }

                val contentIntent = Intent(appCtx, com.dia.app.MainActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                }
                val pending = PendingIntent.getActivity(
                    appCtx, 0, contentIntent,
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
                val notif = NotificationCompat.Builder(appCtx, CHANNEL_ID)
                    .setContentTitle(title)
                    .setContentText(text.take(120))
                    .setStyle(NotificationCompat.BigTextStyle().bigText(text))
                    .setSmallIcon(com.dia.app.R.drawable.ic_dia_logo)
                    .setOngoing(true)
                    .setOnlyAlertOnce(true)
                    .setPriority(NotificationCompat.PRIORITY_LOW)
                    .setContentIntent(pending)
                    .build()
                mgr.notify(NOTIFICATION_ID, notif)
            } catch (e: Exception) {
                Log.w(TAG, "notification update failed: ${e.message}")
            }
        }

        fun stop(context: Context) {
            try {
                context.stopService(Intent(context, PilotForegroundService::class.java))
            } catch (e: Exception) {
                Log.w(TAG, "stopService error: ${e.message}")
            }
        }

        private fun hasPostNotificationsPermission(context: Context): Boolean {
            return Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
                ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED
        }
    }

    private var wakeLock: PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        createChannel()
        val notification = buildNotification("Pilot", "运行中…")
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (e: Exception) {
            Log.w(TAG, "startForeground failed: ${e.message}")
            // Even if the notification can't show, keep the service alive so
            // process priority stays elevated.
        }
        acquireWakeLock()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val title = intent?.getStringExtra(EXTRA_TITLE) ?: "Pilot"
        val text = intent?.getStringExtra(EXTRA_TEXT) ?: "运行中…"
        try {
            val mgr = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            mgr.notify(NOTIFICATION_ID, buildNotification(title, text))
        } catch (_: Exception) {
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        releaseWakeLock()
        running = false
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    // ── Internals ──

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "灵犀 Pilot",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Pilot 控制你的手机时显示"
                setShowBadge(false)
            }
            val mgr = getSystemService(NotificationManager::class.java)
            mgr?.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(title: String, text: String): Notification {
        val contentIntent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        val pending = PendingIntent.getActivity(
            this, 0, contentIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(text.take(120))
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setSmallIcon(R.drawable.ic_dia_logo)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(pending)
            .build()
    }

    private fun acquireWakeLock() {
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            val lock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, WAKELOCK_TAG).apply {
                setReferenceCounted(false)
            }
            // 10-minute safety ceiling — Pilot tasks are bounded.
            lock.acquire(10 * 60 * 1000L)
            wakeLock = lock
        } catch (e: Exception) {
            Log.w(TAG, "wakelock acquire failed: ${e.message}")
        }
    }

    private fun releaseWakeLock() {
        try {
            wakeLock?.takeIf { it.isHeld }?.release()
        } catch (_: Exception) {
        }
        wakeLock = null
    }
}
