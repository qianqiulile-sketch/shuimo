package com.dia.app.pilot.tool.impl

import android.content.Intent
import com.dia.app.pilot.tool.BaseTool
import com.dia.app.pilot.tool.ToolParameter
import com.dia.app.pilot.tool.ToolResult

/**
 * List launchable apps installed on the device. Optional keyword filter.
 * Useful when the user asks "what apps do I have" or when the model needs
 * to find the exact package name for an app it doesn't know.
 */
class GetInstalledAppsTool : BaseTool() {

    override fun getName(): String = "get_installed_apps"

    override fun getDescription(): String =
        "List installed launchable apps on the device. Optional keyword filter to narrow results."

    override fun getParameters(): List<ToolParameter> = listOf(
        ToolParameter("keyword", "string", "Optional substring filter (case-insensitive)", false),
    )

    override fun execute(params: Map<String, Any>): ToolResult {
        val service = requireAccessibilityService()
            ?: return ToolResult.error("Accessibility service is not running")
        val ctx = service.applicationContext
        val keyword = optionalString(params, "keyword", "").lowercase().trim()

        return try {
            val pm = ctx.packageManager
            val mainIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val infos = pm.queryIntentActivities(mainIntent, 0)
            if (infos.isEmpty()) return ToolResult.success("No launchable apps found.")

            val rows = infos.mapNotNull { info ->
                val name = info.loadLabel(pm).toString()
                val pkg = info.activityInfo.packageName
                if (keyword.isNotEmpty() &&
                    !name.lowercase().contains(keyword) &&
                    !pkg.lowercase().contains(keyword)
                ) null else "$name | $pkg"
            }.sorted().distinct()

            if (rows.isEmpty()) {
                return ToolResult.success("No apps match keyword: $keyword")
            }

            val sb = StringBuilder()
            sb.append("Found ").append(rows.size).append(" apps:\n")
            // Cap output so we don't blow up the model context.
            val cap = 60
            rows.take(cap).forEach { sb.append(it).append('\n') }
            if (rows.size > cap) sb.append("…and ").append(rows.size - cap).append(" more")
            ToolResult.success(sb.toString().trim())
        } catch (e: Exception) {
            ToolResult.error("Failed to list installed apps: ${e.message}")
        }
    }
}
