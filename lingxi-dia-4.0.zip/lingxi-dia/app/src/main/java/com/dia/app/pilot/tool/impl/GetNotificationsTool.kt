package com.dia.app.pilot.tool.impl

import android.app.Notification
import com.dia.app.DiaNotificationListenerService
import com.dia.app.pilot.tool.BaseTool
import com.dia.app.pilot.tool.ToolParameter
import com.dia.app.pilot.tool.ToolResult

/**
 * Read active notifications directly from the NotificationListenerService.
 * Faster and more reliable than pulling down the notification shade.
 */
class GetNotificationsTool : BaseTool() {

    override fun getName(): String = "get_notifications"

    override fun getDescription(): String =
        "Read all active notifications without opening the notification shade. " +
            "Returns app, title, text, and time for each. Requires Notification Access."

    override fun getParameters(): List<ToolParameter> = emptyList()

    override fun execute(params: Map<String, Any>): ToolResult {
        if (!DiaNotificationListenerService.isConnected()) {
            return ToolResult.error(
                "Notification Access is not enabled. Enable Dia in Settings → Apps → Special access → Notification access."
            )
        }

        val notifications = DiaNotificationListenerService.getActiveNotificationList()
        if (notifications.isEmpty()) {
            return ToolResult.success("No active notifications.")
        }

        val service = requireAccessibilityService()
        val ctx = service?.applicationContext

        val sb = StringBuilder()
        var count = 0
        for (sbn in notifications) {
            // Skip our own notifications
            if (sbn.packageName == "com.dia.app") continue
            val notif = sbn.notification ?: continue
            val extras = notif.extras ?: continue

            val title = extras.getString(Notification.EXTRA_TITLE, "").orEmpty()
            val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
            val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty()
            val displayText = bigText.ifEmpty { text }

            if (title.isEmpty() && displayText.isEmpty()) continue

            count++
            val timeAgo = formatTimeAgo(notif.`when`)
            val appLabel = ctx?.let { resolveAppLabel(it, sbn.packageName) } ?: sbn.packageName

            sb.append(count).append(". ").append(appLabel)
            if (title.isNotEmpty()) sb.append(": ").append(title)
            if (displayText.isNotEmpty()) {
                val truncated = if (displayText.length > 120) {
                    displayText.substring(0, 120) + "…"
                } else displayText
                sb.append(" — ").append(truncated)
            }
            sb.append(" (").append(timeAgo).append(")\n")

            if (count >= 15) {
                sb.append("…and more notifications\n")
                break
            }
        }

        return if (count == 0) {
            ToolResult.success("No app notifications (only system ones).")
        } else {
            ToolResult.success(sb.toString().trim())
        }
    }

    private fun formatTimeAgo(whenMs: Long): String {
        if (whenMs == 0L) return "just now"
        val diff = System.currentTimeMillis() - whenMs
        if (diff < 0) return "just now"
        val minutes = diff / 60_000
        if (minutes < 1) return "just now"
        if (minutes < 60) return "$minutes min ago"
        val hours = minutes / 60
        if (hours < 24) return "${hours}h ago"
        val days = hours / 24
        return "${days}d ago"
    }

    private fun resolveAppLabel(ctx: android.content.Context, packageName: String): String {
        return try {
            val pm = ctx.packageManager
            val info = pm.getApplicationInfo(packageName, 0)
            pm.getApplicationLabel(info).toString()
        } catch (_: Exception) {
            packageName.substringAfterLast('.')
        }
    }
}
