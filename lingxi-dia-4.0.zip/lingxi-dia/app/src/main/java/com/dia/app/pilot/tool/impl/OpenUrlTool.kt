package com.dia.app.pilot.tool.impl

import android.content.Intent
import android.net.Uri
import com.dia.app.pilot.tool.BaseTool
import com.dia.app.pilot.tool.ToolParameter
import com.dia.app.pilot.tool.ToolResult

/**
 * Open a web URL in the system browser, or run a web search.
 *
 * This is usually far more reliable than fighting the Chrome UI to tap the
 * address bar and type — one intent and we're there.
 */
class OpenUrlTool : BaseTool() {
    override fun getName(): String = "open_url"

    override fun getDescription(): String =
        "Open a website URL in the browser. ONLY use for actual websites, NOT for opening apps. Use open_app for apps."

    override fun getParameters(): List<ToolParameter> = listOf(
        ToolParameter("url", "string", "Full URL. Either 'url' or 'query' is required.", false),
        ToolParameter("query", "string", "Search query — will be sent to Google.", false),
    )

    override fun execute(params: Map<String, Any>): ToolResult {
        return try {
            val ctx = requireAccessibilityService()?.applicationContext
                ?: return ToolResult.error("Accessibility service is not running")

            val rawUrl = optionalString(params, "url", "").trim()
            val query = optionalString(params, "query", "").trim()

            val uri = when {
                rawUrl.isNotEmpty() -> {
                    val hasScheme = rawUrl.startsWith("http://") || rawUrl.startsWith("https://")
                    Uri.parse(if (hasScheme) rawUrl else "https://$rawUrl")
                }
                query.isNotEmpty() -> Uri.parse(
                    "https://www.google.com/search?q=" + Uri.encode(query)
                )
                else -> return ToolResult.error("Provide a 'url' or 'query'")
            }

            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            ctx.startActivity(intent)
            ToolResult.success("Opened $uri")
        } catch (e: Exception) {
            ToolResult.error("Open URL error: ${e.message}")
        }
    }
}
