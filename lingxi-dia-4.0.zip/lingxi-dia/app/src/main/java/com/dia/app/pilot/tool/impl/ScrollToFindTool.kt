package com.dia.app.pilot.tool.impl

import android.util.DisplayMetrics
import com.dia.app.pilot.tool.BaseTool
import com.dia.app.pilot.tool.ToolParameter
import com.dia.app.pilot.tool.ToolResult

class ScrollToFindTool : BaseTool() {
    override fun getName(): String = "scroll_to_find"

    override fun getDescription(): String = "Scroll and find visible text, tapping when found."

    override fun getParameters(): List<ToolParameter> = listOf(
        ToolParameter("text", "string", "Text to find", true),
        ToolParameter("max_swipes", "integer", "Max swipes (default 5)", false),
    )

    override fun execute(params: Map<String, Any>): ToolResult {
        return try {
            val service = requireAccessibilityService() ?: return ToolResult.error("Accessibility service is not running")
            val query = requireString(params, "text")
            val maxSwipes = optionalLong(params, "max_swipes", 5).toInt().coerceIn(1, 10)

            repeat(maxSwipes) { idx ->
                val nodes = service.findNodesByText(query)
                if (nodes.isNotEmpty()) {
                    val target = nodes.firstOrNull { it.isClickable } ?: nodes.first()
                    val ok = target.performAction(android.view.accessibility.AccessibilityNodeInfo.ACTION_CLICK)
                    service.recycleNodes(nodes)
                    return if (ok) ToolResult.success("Tapped after ${idx} swipes")
                    else ToolResult.error("Found but failed to tap")
                }
                service.recycleNodes(nodes)

                val metrics: DisplayMetrics = service.resources.displayMetrics
                val w = metrics.widthPixels
                val h = metrics.heightPixels
                val startX = w / 2
                val startY = (h * 0.75f).toInt()
                val endY = (h * 0.35f).toInt()
                service.performSwipe(startX, startY, startX, endY)
                try {
                    Thread.sleep(600)
                } catch (_: InterruptedException) {
                    Thread.currentThread().interrupt()
                }
            }

            return ToolResult.error("Not found: $query")
        } catch (e: Exception) {
            ToolResult.error("Scroll find error: ${e.message}")
        }
    }
}
