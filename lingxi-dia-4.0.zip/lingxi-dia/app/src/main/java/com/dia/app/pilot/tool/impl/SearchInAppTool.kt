package com.dia.app.pilot.tool.impl

import android.graphics.Rect
import android.os.Bundle
import android.view.accessibility.AccessibilityNodeInfo
import com.dia.app.DiaAccessibilityService
import com.dia.app.pilot.tool.BaseTool
import com.dia.app.pilot.tool.ToolParameter
import com.dia.app.pilot.tool.ToolResult

/**
 * Smart search tool — finds the search bar automatically, taps it, types the
 * query, and submits.
 *
 * The tricky part: many apps put a mic icon, camera icon, or voice-search
 * button RIGHT next to or inside the search bar, with contentDescription
 * containing "search". Naive "find anything labeled search" picks them and
 * we end up tapping mic over and over. We explicitly reject those.
 *
 * Verification: after typing, we re-read the focused field. If its text is
 * still empty, we treat the call as failed so the caller can recover instead
 * of looping back asking us to search again.
 */
class SearchInAppTool : BaseTool() {
    override fun getName(): String = "search_in_app"

    override fun getDescription(): String =
        "Search for text inside the current app. Automatically finds the search bar, taps it, types the query, and submits. Use this whenever you need to search."

    override fun getParameters(): List<ToolParameter> = listOf(
        ToolParameter("query", "string", "The text to search for", true),
    )

    override fun execute(params: Map<String, Any>): ToolResult {
        val service = requireAccessibilityService()
            ?: return ToolResult.error("Accessibility service is not running")
        val query = requireString(params, "query")

        val root = service.rootInActiveWindow
            ?: return ToolResult.error("No active window")

        // Strategy 1: Find an editable search-like node directly.
        val searchNode = findSearchEditNode(root)
        if (searchNode != null) {
            if (typeAndSubmit(service, searchNode, query)) {
                return ToolResult.success("Searched for: $query")
            }
        }

        // Strategy 2: Find a clickable thing labeled "Search" (NOT mic / voice
        // / camera / lens), tap it, then type into whatever input appears.
        val searchTapTarget = findSafeSearchTapTarget(root)
        if (searchTapTarget != null) {
            val bounds = Rect().apply { searchTapTarget.getBoundsInScreen(this) }
            service.performTap(bounds.centerX(), bounds.centerY())
            sleep(700)

            val refreshed = service.rootInActiveWindow ?: root
            val focused = refreshed.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
                ?: findFirstEditable(refreshed)
            if (focused != null && typeAndSubmit(service, focused, query)) {
                return ToolResult.success("Searched for: $query")
            }
        }

        return ToolResult.error(
            "Could not find a search bar in this app. Try find_and_tap on the search " +
                "icon, then input_text(text=\"$query\", submit=true)."
        )
    }

    // ── Node search ──

    /**
     * An editable node that looks like a search field.
     * Excludes things that aren't real text inputs (e.g. invisible 0-size
     * web shadow nodes).
     */
    private fun findSearchEditNode(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val candidates = mutableListOf<AccessibilityNodeInfo>()
        collectEditCandidates(root, candidates)
        if (candidates.isEmpty()) return null

        // Prefer ones that explicitly say "search" or "find".
        val withSearchHint = candidates.firstOrNull { node ->
            val hint = node.hintText?.toString()?.lowercase().orEmpty()
            val desc = node.contentDescription?.toString()?.lowercase().orEmpty()
            val cls = node.className?.toString()?.lowercase().orEmpty()
            (hint.contains("search") || desc.contains("search") ||
                cls.contains("search") || hint.contains("find"))
        }
        if (withSearchHint != null) return withSearchHint
        // Otherwise use the topmost editable.
        return candidates.minByOrNull {
            val r = Rect(); it.getBoundsInScreen(r); r.top
        }
    }

    private fun collectEditCandidates(
        node: AccessibilityNodeInfo,
        out: MutableList<AccessibilityNodeInfo>,
    ) {
        val cls = node.className?.toString().orEmpty()
        val isEditLike = node.isEditable ||
            cls.contains("EditText", true) ||
            cls.contains("SearchView", true) ||
            cls.contains("AutoComplete", true) ||
            cls.contains("TextField", true)

        if (isEditLike) {
            val bounds = Rect().apply { node.getBoundsInScreen(this) }
            // Real text inputs have meaningful width and height. Small icons
            // like a search button are usually <= 100px wide.
            if (bounds.width() > 150 && bounds.height() in 30..200) {
                out.add(node)
            }
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            collectEditCandidates(child, out)
        }
    }

    /**
     * A clickable thing labeled "Search" that's a real search entry point.
     * Mic / voice / camera / lens get last priority because they don't open
     * a text field, but they're not blacklisted — sometimes a search "bar"
     * surface is the only thing on screen and tapping it is correct.
     */
    private fun findSafeSearchTapTarget(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val all = mutableListOf<AccessibilityNodeInfo>()
        collectClickable(root, all)
        val matches = all.filter { mentionsSearch(it) }
        if (matches.isEmpty()) return null
        // Prefer the one that does NOT look like a mic / voice / camera button.
        val nonMic = matches.firstOrNull { !looksLikeVoiceOrCamera(it) }
        return nonMic ?: matches.first()
    }

    private fun collectClickable(node: AccessibilityNodeInfo, out: MutableList<AccessibilityNodeInfo>) {
        if (node.isClickable) out.add(node)
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            collectClickable(child, out)
        }
    }

    private fun mentionsSearch(node: AccessibilityNodeInfo): Boolean {
        val combined = labelText(node)
        return combined.contains("search") || combined.contains("find") ||
            combined.contains("query")
    }

    private fun looksLikeVoiceOrCamera(node: AccessibilityNodeInfo): Boolean {
        val combined = labelText(node)
        val markers = listOf(
            "voice", "mic", "microphone", "speak",
            "camera", "lens", "scan", "image", "barcode", "qr"
        )
        return markers.any { combined.contains(it) }
    }

    private fun labelText(node: AccessibilityNodeInfo): String {
        val text = node.text?.toString()?.lowercase().orEmpty()
        val desc = node.contentDescription?.toString()?.lowercase().orEmpty()
        val hint = node.hintText?.toString()?.lowercase().orEmpty()
        return "$text|$desc|$hint"
    }

    private fun findFirstEditable(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isEditable) {
            val r = Rect().apply { node.getBoundsInScreen(this) }
            if (r.width() > 100 && r.height() > 20) return node
        }
        val cls = node.className?.toString().orEmpty()
        if (cls.contains("EditText", true) || cls.contains("SearchView", true)) {
            val r = Rect().apply { node.getBoundsInScreen(this) }
            if (r.width() > 100 && r.height() > 20) return node
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val result = findFirstEditable(child)
            if (result != null) return result
        }
        return null
    }

    // ── Type + verify ──

    /**
     * Tap, type, verify text actually landed, then press Enter.
     * Returns false when we couldn't get the query into the field — caller
     * surfaces a real error instead of a fake success.
     */
    private fun typeAndSubmit(
        service: DiaAccessibilityService,
        node: AccessibilityNodeInfo,
        query: String,
    ): Boolean {
        val bounds = Rect().apply { node.getBoundsInScreen(this) }
        service.performTap(bounds.centerX(), bounds.centerY())
        sleep(500)

        // Try ACTION_SET_TEXT on the node we tapped.
        var ok = setTextOnNode(node, query)

        if (!ok || !verifyText(service, query)) {
            // Re-resolve focus and try again — the tap may have created a
            // new field.
            sleep(300)
            val refreshed = service.rootInActiveWindow
                ?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            if (refreshed != null) {
                ok = setTextOnNode(refreshed, query)
            }
        }
        if (!ok) return false
        // One last verify before submitting — if no text reached the field,
        // pressing Enter does nothing useful.
        if (!verifyText(service, query)) return false

        sleep(200)
        service.performImeEnter()
        return true
    }

    private fun setTextOnNode(node: AccessibilityNodeInfo, text: String): Boolean {
        val args = Bundle().apply {
            putCharSequence(
                AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                text,
            )
        }
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    /**
     * Confirm the typed text is actually visible somewhere in an editable
     * node. Prevents fake "search succeeded" returns when nothing landed.
     */
    private fun verifyText(service: DiaAccessibilityService, expected: String): Boolean {
        val root = service.rootInActiveWindow ?: return false
        val needle = expected.trim().lowercase()
        if (needle.isEmpty()) return true
        return containsTextInEditable(root, needle)
    }

    private fun containsTextInEditable(node: AccessibilityNodeInfo, needle: String): Boolean {
        val cls = node.className?.toString().orEmpty()
        val isInputLike = node.isEditable ||
            cls.contains("EditText", true) ||
            cls.contains("SearchView", true) ||
            cls.contains("AutoComplete", true) ||
            cls.contains("TextField", true)

        if (isInputLike) {
            val t = node.text?.toString()?.lowercase().orEmpty()
            if (t.contains(needle)) return true
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            if (containsTextInEditable(child, needle)) return true
        }
        return false
    }

    private fun sleep(ms: Long) {
        try { Thread.sleep(ms) } catch (_: InterruptedException) { Thread.currentThread().interrupt() }
    }
}
