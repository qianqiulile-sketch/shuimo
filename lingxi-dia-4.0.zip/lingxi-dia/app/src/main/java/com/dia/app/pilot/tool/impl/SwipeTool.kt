package com.dia.app.pilot.tool.impl

import com.dia.app.pilot.tool.BaseTool
import com.dia.app.pilot.tool.ToolParameter
import com.dia.app.pilot.tool.ToolResult

class SwipeTool : BaseTool() {
    override fun getName(): String = "swipe"

    override fun getDescription(): String = "Swipe from (start_x, start_y) to (end_x, end_y)."

    override fun getParameters(): List<ToolParameter> = listOf(
        ToolParameter("start_x", "integer", "Start X coordinate", true),
        ToolParameter("start_y", "integer", "Start Y coordinate", true),
        ToolParameter("end_x", "integer", "End X coordinate", true),
        ToolParameter("end_y", "integer", "End Y coordinate", true),
        ToolParameter("duration_ms", "integer", "Swipe duration in ms (default 450)", false),
    )

    override fun execute(params: Map<String, Any>): ToolResult {
        return try {
            val service = requireAccessibilityService() ?: return ToolResult.error("Accessibility service is not running")
            val sx = requireInt(params, "start_x")
            val sy = requireInt(params, "start_y")
            val ex = requireInt(params, "end_x")
            val ey = requireInt(params, "end_y")
            val duration = optionalLong(params, "duration_ms", 450L)
            val success = service.performSwipe(sx, sy, ex, ey, duration)
            return if (success) ToolResult.success("Swiped from ($sx, $sy) to ($ex, $ey)")
            else ToolResult.error("Failed to swipe")
        } catch (e: Exception) {
            ToolResult.error("Swipe error: ${e.message}")
        }
    }
}
