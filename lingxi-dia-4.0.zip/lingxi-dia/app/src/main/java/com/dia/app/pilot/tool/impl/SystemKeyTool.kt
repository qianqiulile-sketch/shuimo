package com.dia.app.pilot.tool.impl

import android.accessibilityservice.AccessibilityService
import com.dia.app.pilot.tool.BaseTool
import com.dia.app.pilot.tool.ToolParameter
import com.dia.app.pilot.tool.ToolResult

class SystemKeyTool : BaseTool() {
    override fun getName(): String = "system_key"

    override fun getDescription(): String =
        "Press a system/IME key. Supported: back, home, recents, enter (submits focused field)."

    override fun getParameters(): List<ToolParameter> = listOf(
        ToolParameter("key", "string", "Key name: back|home|recents|enter", true)
    )

    override fun execute(params: Map<String, Any>): ToolResult {
        return try {
            val service = requireAccessibilityService()
                ?: return ToolResult.error("Accessibility service is not running")
            when (requireString(params, "key").lowercase()) {
                "back" -> {
                    val ok = service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
                    if (ok) ToolResult.success("Pressed back") else ToolResult.error("Back failed")
                }
                "home" -> {
                    val ok = service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
                    if (ok) ToolResult.success("Pressed home") else ToolResult.error("Home failed")
                }
                "recents", "recent_apps" -> {
                    val ok = service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS)
                    if (ok) ToolResult.success("Opened recents") else ToolResult.error("Recents failed")
                }
                "enter", "submit", "done", "search" -> {
                    val ok = service.performImeEnter()
                    if (ok) ToolResult.success("Pressed Enter / submitted")
                    else ToolResult.error("No focused input to submit")
                }
                else -> ToolResult.error("Unsupported key")
            }
        } catch (e: Exception) {
            ToolResult.error("System key error: ${e.message}")
        }
    }
}
