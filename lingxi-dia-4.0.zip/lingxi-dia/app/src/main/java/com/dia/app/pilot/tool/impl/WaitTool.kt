package com.dia.app.pilot.tool.impl

import com.dia.app.pilot.tool.BaseTool
import com.dia.app.pilot.tool.ToolParameter
import com.dia.app.pilot.tool.ToolResult

class WaitTool : BaseTool() {
    override fun getName(): String = "wait"

    override fun getDescription(): String = "Wait for a duration in milliseconds."

    override fun getParameters(): List<ToolParameter> = listOf(
        ToolParameter("duration_ms", "integer", "Milliseconds to wait", true)
    )

    override fun execute(params: Map<String, Any>): ToolResult {
        return try {
            val duration = requireInt(params, "duration_ms").toLong().coerceIn(0, 10000)
            try {
                Thread.sleep(duration)
            } catch (_: InterruptedException) {
                Thread.currentThread().interrupt()
            }
            ToolResult.success("Waited ${duration}ms")
        } catch (e: Exception) {
            ToolResult.error("Wait error: ${e.message}")
        }
    }
}
