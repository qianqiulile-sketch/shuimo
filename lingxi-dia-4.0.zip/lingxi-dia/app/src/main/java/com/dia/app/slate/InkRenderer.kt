package com.dia.app.slate

import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke as DrawStroke

/**
 * Builds a smooth Compose Path from a list of InkPoints using midpoint
 * quadratic interpolation — the trick GoodNotes / Notability use.
 */
internal fun buildSmoothPath(points: List<InkPoint>): Path {
    val path = Path()
    if (points.isEmpty()) return path
    if (points.size == 1) {
        val p = points[0]
        path.addOval(
            androidx.compose.ui.geometry.Rect(p.x - 0.5f, p.y - 0.5f, p.x + 0.5f, p.y + 0.5f)
        )
        return path
    }
    path.moveTo(points[0].x, points[0].y)
    for (i in 1 until points.size - 1) {
        val cur = points[i]
        val nxt = points[i + 1]
        val midX = (cur.x + nxt.x) / 2f
        val midY = (cur.y + nxt.y) / 2f
        path.quadraticBezierTo(cur.x, cur.y, midX, midY)
    }
    val last = points.last()
    path.lineTo(last.x, last.y)
    return path
}

/**
 * Draw one ink stroke. Pressure modulates width subtly so the stroke
 * feels alive. Drawn in whatever DrawScope coords the caller has set up
 * (we apply a [scale] transform at the call site for zoom).
 */
internal fun DrawScope.drawInkStroke(stroke: Stroke) {
    val pts = stroke.points
    if (pts.isEmpty()) return
    val path = buildSmoothPath(pts)
    var sumPressure = 0f
    for (p in pts) sumPressure += p.pressure
    val avgPressure = sumPressure / pts.size
    val width = stroke.width * (0.85f + avgPressure * 0.3f)

    val isHighlight = stroke.mode == PenMode.HIGHLIGHTER
    val alpha = if (isHighlight) 0.32f else 1f

    drawPath(
        path = path,
        color = stroke.color,
        alpha = alpha,
        style = DrawStroke(
            width = width,
            cap = StrokeCap.Round,
            join = StrokeJoin.Round,
        ),
    )
}
