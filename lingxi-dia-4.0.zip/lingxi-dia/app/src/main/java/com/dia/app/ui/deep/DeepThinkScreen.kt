package com.dia.app.ui.deep

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dia.app.deep.DeepEngine
import com.dia.app.deep.DeepEvent
import com.dia.app.deep.DeepSession
import com.dia.app.deep.DeepStep
import com.dia.app.deep.FlatStep
import com.dia.app.deep.PlanOps
import com.dia.app.files.AiFolder
import com.dia.app.files.FileManager
import com.dia.app.llm.LlmGateway
import com.dia.app.prefs.DiaSettings
import com.dia.app.ui.chat.ChatController
import com.dia.app.ui.chat.findActivity
import com.dia.app.ui.theme.CloudDivider
import com.dia.app.ui.theme.DiaPal
import com.dia.app.ui.theme.DiaPalette
import com.dia.app.ui.theme.DiaSerif
import com.dia.app.ui.theme.ThemedIcon
import com.dia.app.ui.theme.ToolGlyph
import com.dia.app.ui.theme.inkWashBackground
import com.dia.app.ui.theme.paperGrain
import com.dia.app.ui.theme.scrollFrame
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 「自主长思」页：列表 + 单个长思的计划 / 进程 / 成果。
 * 计划随时可改（增删、细化、调整顺序、标记完成或跳过），底部随时插话。
 */
@Composable
fun DeepThinkScreen(initialId: String?, onBack: () -> Unit, onOpenFolder: () -> Unit) {
    val p = DiaPal.current
    val context = LocalContext.current
    val sessions by DeepEngine.sessions.collectAsState()
    val confirm by DeepEngine.confirm.collectAsState()
    var openId by rememberSaveable { mutableStateOf(initialId) }
    var showNew by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        DeepEngine.init(context)
        ChatController.events.collect { e ->
            when {
                e == "move_to_back" -> context.findActivity()?.moveTaskToBack(true)
                e.startsWith("toast:") -> Toast.makeText(context, e.removePrefix("toast:"), Toast.LENGTH_SHORT).show()
            }
        }
    }
    BackHandler(enabled = openId != null && initialId == null) { openId = null }

    Column(Modifier.fillMaxSize().inkWashBackground(p).windowInsetsPadding(WindowInsets.statusBars)) {
        val s = openId?.let { id -> sessions.firstOrNull { it.id == id } }
        if (s == null) {
            SessionList(p, sessions, onBack = onBack, onOpen = { openId = it }, onNew = { showNew = true })
        } else {
            SessionDetail(p, s, onBack = { if (initialId == null) openId = null else onBack() }, onOpenFolder = onOpenFolder)
        }
    }

    if (showNew) {
        NewDeepDialog(p, onDismiss = { showNew = false }) { topic, web, auto, review, max ->
            showNew = false
            if (!LlmGateway.isAvailable()) Toast.makeText(context, "还没有可用的模型：会在模型加载后自动开始", Toast.LENGTH_LONG).show()
            openId = DeepEngine.create(context, topic, web = web, autoApprove = auto, maxCycles = max, reviewFirst = review)
        }
    }
    confirm?.let { c ->
        AlertDialog(
            onDismissRequest = {},
            title = { Text("长思请求批准：${c.title}") },
            text = { Text(c.detail.take(800)) },
            confirmButton = { TextButton(onClick = { DeepEngine.resolveConfirm(true) }) { Text("准", color = p.cinnabar) } },
            dismissButton = { TextButton(onClick = { DeepEngine.resolveConfirm(false) }) { Text("驳") } },
        )
    }
}

// ───────── 列表 ─────────

@Composable
private fun SessionList(p: DiaPalette, sessions: List<DeepSession>, onBack: () -> Unit, onOpen: (String) -> Unit, onNew: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "返回", tint = p.text) }
        Column(Modifier.weight(1f)) {
            Text("自主长思", style = MaterialTheme.typography.headlineMedium, color = p.text, fontFamily = DiaSerif)
            Text("给一个主题，灵犀自己拆计划、调用一切工具、一步步做下去，直到你暂停", style = MaterialTheme.typography.labelSmall, color = p.textTertiary)
        }
    }
    CloudDivider(p, Modifier.padding(horizontal = 16.dp))
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(p.cinnabar).clickable(onClick = onNew).padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                ThemedIcon("deep.new", Icons.Rounded.Add, null, p.onCinnabar, 22.dp)
                Spacer(Modifier.width(8.dp))
                Column {
                    Text("新建长思", color = p.onCinnabar, style = MaterialTheme.typography.titleMedium, fontFamily = DiaSerif)
                    Text("例如：研究国产大模型的技术路线并写成报告 / 持续跟进某个项目 / 为我规划半年的学习", color = p.onCinnabar.copy(alpha = 0.8f),
                        style = MaterialTheme.typography.labelSmall)
                }
            }
        }
        if (sessions.isEmpty()) {
            item {
                Text(
                    "还没有长思。它会在后台持续运行（通知栏可随时暂停），每一步的思考、产出和总结都写进「灵犀AI/长思」文件夹。",
                    style = MaterialTheme.typography.bodySmall, color = p.textSecondary, modifier = Modifier.padding(8.dp),
                )
            }
        }
        items(sessions, key = { it.id }) { s -> SessionCard(p, s) { onOpen(s.id) } }
    }
}

@Composable
private fun StatusDot(p: DiaPalette, s: DeepSession, running: Boolean) {
    val tr = rememberInfiniteTransition(label = "dot")
    val a by tr.animateFloat(0.3f, 1f, infiniteRepeatable(tween(800), RepeatMode.Reverse), label = "a")
    val c = when (s.status) {
        "running", "planning" -> p.bamboo
        "review" -> p.gold
        "error" -> p.error
        "done" -> p.indigo
        else -> p.textTertiary
    }
    Box(Modifier.size(9.dp).clip(CircleShape).background(c.copy(alpha = if (running) a else 1f)))
}

@Composable
private fun SessionCard(p: DiaPalette, s: DeepSession, onClick: () -> Unit) {
    val (d, t) = PlanOps.counts(s.plan)
    val running = DeepEngine.isRunning(s.id)
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(p.surface.copy(alpha = p.bubbleAlpha))
            .paperGrain(0.06f).scrollFrame(p).clickable(onClick = onClick).padding(14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            StatusDot(p, s, running)
            Spacer(Modifier.width(8.dp))
            Text(s.topic, style = MaterialTheme.typography.titleSmall, color = p.text, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            Text(s.statusLabel, style = MaterialTheme.typography.labelSmall, color = p.textTertiary)
        }
        Spacer(Modifier.height(4.dp))
        Text("第 ${s.cycles} 轮 · 完成 $d/$t 步 · ${SimpleDateFormat("M月d日 HH:mm", Locale.CHINA).format(Date(s.updatedAt))}",
            style = MaterialTheme.typography.labelSmall, color = p.textSecondary)
        if (s.activity.isNotBlank()) Text(s.activity, style = MaterialTheme.typography.labelSmall, color = p.textTertiary, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

// ───────── 单个长思 ─────────

@Composable
private fun ColumnScope.SessionDetail(p: DiaPalette, s: DeepSession, onBack: () -> Unit, onOpenFolder: () -> Unit) {
    val context = LocalContext.current
    val running = DeepEngine.isRunning(s.id) || s.status == "running" || s.status == "planning"
    var tab by rememberSaveable(s.id) { mutableStateOf(0) }
    var menu by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    val (d, t) = PlanOps.counts(s.plan)

    Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "返回", tint = p.text) }
        Column(Modifier.weight(1f)) {
            Text(s.topic, style = MaterialTheme.typography.titleMedium, color = p.text, fontFamily = DiaSerif, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Row(verticalAlignment = Alignment.CenterVertically) {
                StatusDot(p, s, DeepEngine.isRunning(s.id))
                Spacer(Modifier.width(6.dp))
                Text("${s.statusLabel} · 第 ${s.cycles} 轮 · $d/$t", style = MaterialTheme.typography.labelSmall, color = p.textSecondary)
            }
        }
        // ▶ / ⏸
        IconButton(onClick = { if (DeepEngine.isRunning(s.id)) DeepEngine.pause(s.id) else DeepEngine.start(s.id) }) {
            if (DeepEngine.isRunning(s.id)) ThemedIcon("deep.pause", Icons.Rounded.Pause, "暂停", p.cinnabar, 26.dp)
            else ThemedIcon("deep.start", Icons.Rounded.PlayArrow, "继续", p.bamboo, 28.dp)
        }
        IconButton(onClick = onOpenFolder) { ThemedIcon("deep.folder", Icons.Rounded.Folder, "文件夹", p.textSecondary) }
        Box {
            IconButton(onClick = { menu = true }) { Icon(Icons.Rounded.MoreVert, "更多", tint = p.textSecondary) }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(text = { Text("在 AI 文件夹里查看") }, onClick = { menu = false; onOpenFolder() })
                DropdownMenuItem(text = { Text("把总结发到对话里继续聊") }, onClick = {
                    menu = false
                    ChatController.setDraft("（关于长思「${s.topic}」）\n" + s.summary.ifBlank { "请读一下长思目录「灵犀AI/${AiFolder.rel(File(s.folder))}」里的总结和产出，" } + "\n")
                    com.dia.app.screen.NavBus.requestChat()
                })
                HorizontalDivider()
                DropdownMenuItem(text = { Text("删除（保留文件）") }, onClick = { menu = false; DeepEngine.delete(s.id, false); onBack() })
                DropdownMenuItem(text = { Text("删除（连同文件）", color = p.error) }, onClick = { menu = false; confirmDelete = true })
            }
        }
    }
    // 选项：联网 / 自动批准
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 2.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically,
    ) {
        Text("联网", style = MaterialTheme.typography.labelSmall, color = p.textTertiary)
        for ((k, label) in listOf("auto" to "AI 决定", "on" to "允许", "off" to "不联网")) {
            Chip(p, label, s.web == k) { DeepEngine.setOptions(s.id, web = k) }
        }
        Spacer(Modifier.width(6.dp))
        Chip(p, if (s.autoApprove) "⚡ 自动批准" else "逐项批准", s.autoApprove) { DeepEngine.setOptions(s.id, autoApprove = !s.autoApprove) }
        Chip(p, if (s.maxCycles > 0) "上限 ${s.maxCycles} 轮" else "不限轮数", s.maxCycles == 0) {
            DeepEngine.setOptions(s.id, maxCycles = when (s.maxCycles) { 0 -> 30; 30 -> 100; else -> 0 })
        }
    }
    if (s.activity.isNotBlank()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            if (running) CircularProgressIndicator(color = p.gold, strokeWidth = 1.5.dp, modifier = Modifier.size(12.dp))
            Spacer(Modifier.width(6.dp))
            Text(s.activity, style = MaterialTheme.typography.labelSmall, color = p.textSecondary, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
    }
    if (s.status == "review") {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp).clip(RoundedCornerShape(10.dp))
                .background(p.gold.copy(alpha = 0.15f)).padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("计划已生成：可以先改一改（增删、细化、调整顺序），满意了再开始", style = MaterialTheme.typography.labelMedium, color = p.text, modifier = Modifier.weight(1f))
            Box(Modifier.clip(RoundedCornerShape(8.dp)).background(p.cinnabar).clickable { DeepEngine.approvePlan(s.id) }.padding(horizontal = 12.dp, vertical = 8.dp)) {
                Text("开始执行", color = p.onCinnabar, style = MaterialTheme.typography.labelLarge)
            }
        }
    }
    // 标签页
    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        for ((i, name) in listOf("计划", "进程", "成果").withIndex()) {
            val sel = tab == i
            Text(
                name, color = if (sel) p.cinnabar else p.textSecondary, fontFamily = DiaSerif, fontSize = 18.sp,
                modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(if (sel) p.cinnabar.copy(alpha = 0.10f) else p.surface.copy(alpha = 0f))
                    .clickable { tab = i }.padding(horizontal = 14.dp, vertical = 4.dp),
            )
        }
    }
    CloudDivider(p, Modifier.padding(horizontal = 16.dp))
    Box(Modifier.fillMaxWidth().weight(1f)) {
        when (tab) {
            0 -> PlanTab(p, s)
            1 -> ProcessTab(p, s)
            else -> ResultTab(p, s)
        }
    }
    NoteInput(p, s)

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("删除长思和它的全部文件？") },
            text = { Text("「灵犀AI/${AiFolder.rel(File(s.folder))}」整个目录都会删除，无法恢复。") },
            confirmButton = { TextButton(onClick = { confirmDelete = false; DeepEngine.delete(s.id, true); onBack() }) { Text("删除", color = p.error) } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("取消") } },
        )
    }
}

// ───────── 计划 ─────────

@Composable
private fun PlanTab(p: DiaPalette, s: DeepSession) {
    val flat = PlanOps.flatten(s.plan)
    var editing by remember { mutableStateOf<FlatStep?>(null) }
    var adding by remember { mutableStateOf<Pair<String?, String?>?>(null) } // (parentId, afterId)
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp)) {
        if (flat.isEmpty()) {
            item {
                Text(
                    if (s.status == "planning") "正在拆解主题、制定计划…" else "还没有计划。点「继续」让 AI 先拆解主题，或者自己添加步骤。",
                    color = p.textSecondary, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(12.dp),
                )
            }
        }
        items(flat, key = { it.step.id }) { f -> StepRow(p, s, f, onEdit = { editing = f }, onAddChild = { adding = f.step.id to null }, onAddAfter = { adding = f.parentId to f.step.id }) }
        item {
            Text(
                "＋ 添加步骤", color = p.indigo, style = MaterialTheme.typography.labelLarge,
                modifier = Modifier.padding(8.dp).clip(RoundedCornerShape(8.dp)).clickable { adding = null to null }.padding(8.dp),
            )
            Text(
                "图例：○ 待办  ▶ 进行中  ✓ 完成  ⊘ 跳过  ✗ 失败。点左边的符号切换状态；AI 每一轮都会重新读取计划，你的修改下一轮就生效。",
                color = p.textTertiary, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(horizontal = 12.dp),
            )
        }
    }
    editing?.let { f ->
        StepDialog(p, "修改步骤 ${f.label}", f.step.title, f.step.detail, onDismiss = { editing = null }) { title, detail ->
            editing = null
            DeepEngine.editStep(s.id, f.step.id, title, detail)
        }
    }
    adding?.let { (parent, after) ->
        StepDialog(p, if (parent != null && after == null) "添加子步骤" else "添加步骤", "", "", onDismiss = { adding = null }) { title, detail ->
            adding = null
            DeepEngine.addStep(s.id, title, parent, after, detail)
        }
    }
}

@Composable
private fun StepRow(p: DiaPalette, s: DeepSession, f: FlatStep, onEdit: () -> Unit, onAddChild: () -> Unit, onAddAfter: () -> Unit) {
    val st = f.step
    var menu by remember { mutableStateOf(false) }
    var open by remember { mutableStateOf(false) }
    val current = s.currentStepId == st.id
    val color = when (st.status) {
        DeepStep.DONE -> p.bamboo
        DeepStep.DOING -> p.gold
        DeepStep.FAILED -> p.error
        DeepStep.SKIP -> p.textTertiary
        else -> p.textSecondary
    }
    Row(
        Modifier.fillMaxWidth().padding(start = (f.depth * 18).dp, top = 2.dp, bottom = 2.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(if (current) p.gold.copy(alpha = 0.12f) else p.surface.copy(alpha = p.bubbleAlpha * 0.8f))
            .border(0.6.dp, if (current) p.gold.copy(alpha = 0.6f) else p.border, RoundedCornerShape(10.dp))
            .clickable { open = !open }.padding(horizontal = 8.dp, vertical = 7.dp),
        verticalAlignment = Alignment.Top,
    ) {
        Text(
            PlanOps.statusIcon(st.status), color = color, fontSize = 16.sp,
            modifier = Modifier.width(24.dp).clickable {
                val next = when (st.status) { DeepStep.TODO -> DeepStep.DONE; DeepStep.DONE -> DeepStep.SKIP; DeepStep.SKIP -> DeepStep.TODO; DeepStep.FAILED -> DeepStep.TODO; else -> st.status }
                DeepEngine.setStepStatus(s.id, st.id, next)
            },
        )
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(f.label, color = p.textTertiary, style = MaterialTheme.typography.labelSmall)
                Spacer(Modifier.width(6.dp))
                Text(st.title, color = if (st.status == DeepStep.SKIP) p.textTertiary else p.text, style = MaterialTheme.typography.bodyMedium,
                    maxLines = if (open) 6 else 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                if (st.by == "user") {
                    Spacer(Modifier.width(4.dp))
                    Text("你", color = p.cinnabar, style = MaterialTheme.typography.labelSmall)
                }
            }
            if (st.detail.isNotBlank() && open) Text(st.detail, color = p.textSecondary, style = MaterialTheme.typography.labelSmall)
            if (st.result.isNotBlank()) {
                Text("结论：" + st.result, color = p.textSecondary, style = MaterialTheme.typography.labelSmall,
                    maxLines = if (open) 30 else 1, overflow = TextOverflow.Ellipsis)
            }
        }
        Box {
            Text("⋮", color = p.textTertiary, fontSize = 18.sp, modifier = Modifier.clickable { menu = true }.padding(horizontal = 6.dp))
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(text = { Text("修改") }, onClick = { menu = false; onEdit() })
                DropdownMenuItem(text = { Text("添加子步骤") }, onClick = { menu = false; onAddChild() })
                DropdownMenuItem(text = { Text("在后面插入") }, onClick = { menu = false; onAddAfter() })
                DropdownMenuItem(text = { Text("让 AI 细化成小步骤") }, onClick = { menu = false; DeepEngine.refineStep(s.id, st.id) })
                DropdownMenuItem(text = { Text("上移") }, onClick = { menu = false; DeepEngine.moveStep(s.id, st.id, true) })
                DropdownMenuItem(text = { Text("下移") }, onClick = { menu = false; DeepEngine.moveStep(s.id, st.id, false) })
                HorizontalDivider()
                for (status in DeepStep.ALL_STATUS.filter { it != DeepStep.DOING && it != st.status }) {
                    DropdownMenuItem(text = { Text("标为「${PlanOps.statusLabel(status)}」") }, onClick = { menu = false; DeepEngine.setStepStatus(s.id, st.id, status) })
                }
                HorizontalDivider()
                DropdownMenuItem(text = { Text("删除", color = p.error) }, onClick = { menu = false; DeepEngine.removeStep(s.id, st.id) })
            }
        }
    }
}

@Composable
private fun StepDialog(p: DiaPalette, title: String, initTitle: String, initDetail: String, onDismiss: () -> Unit, onSave: (String, String) -> Unit) {
    var t by remember { mutableStateOf(initTitle) }
    var d by remember { mutableStateOf(initDetail) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                OutlinedTextField(value = t, onValueChange = { t = it }, label = { Text("要做什么") }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(value = d, onValueChange = { d = it }, label = { Text("说明 / 要求（可选）") }, minLines = 2, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = { TextButton(onClick = { if (t.isNotBlank()) onSave(t, d) }) { Text("保存", color = p.cinnabar) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("取消") } },
    )
}

// ───────── 进程 ─────────

@Composable
private fun ProcessTab(p: DiaPalette, s: DeepSession) {
    val events by DeepEngine.events(s.id).collectAsState()
    val list = rememberLazyListState()
    LaunchedEffect(events.size) { if (events.isNotEmpty()) list.animateScrollToItem(events.size - 1) }
    val fmt = remember { SimpleDateFormat("HH:mm:ss", Locale.CHINA) }
    LazyColumn(Modifier.fillMaxSize(), state = list, contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        if (events.isEmpty()) item { Text("还没有记录。", color = p.textTertiary, modifier = Modifier.padding(12.dp)) }
        items(events, key = { it.id }) { e -> EventRow(p, e, fmt.format(Date(e.time))) }
    }
}

@Composable
private fun EventRow(p: DiaPalette, e: DeepEvent, time: String) {
    var open by remember { mutableStateOf(false) }
    val (icon, color) = when (e.kind) {
        "cycle" -> "🔄" to p.gold
        "tool" -> "" to when (e.status) { "error" -> p.error; "done" -> p.bamboo; else -> p.gold }
        "result" -> (if (e.status == "done") "✅" else "⏳") to p.bamboo
        "user" -> "🗣" to p.cinnabar
        "question" -> "🙋" to p.cinnabar
        "plan" -> "🗺" to p.indigo
        "error" -> "⚠️" to p.error
        "confirm" -> "🔖" to p.gold
        else -> "·" to p.textTertiary
    }
    val big = e.kind == "cycle" || e.kind == "result" || e.kind == "user" || e.kind == "question"
    Column(
        Modifier.fillMaxWidth().padding(start = if (e.kind == "tool") 18.dp else 0.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(if (big) p.surface.copy(alpha = p.bubbleAlpha) else p.surfaceAlt.copy(alpha = p.bubbleAlpha * 0.6f))
            .border(0.5.dp, color.copy(alpha = 0.35f), RoundedCornerShape(10.dp))
            .clickable(enabled = e.detail.isNotBlank()) { open = !open }.padding(horizontal = 10.dp, vertical = 6.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            when {
                e.kind == "tool" && e.status == "running" -> CircularProgressIndicator(color = color, strokeWidth = 1.5.dp, modifier = Modifier.size(12.dp))
                e.kind == "tool" -> ToolGlyph(e.toolName, p.text, 15.dp)
                else -> Text(icon, fontSize = 13.sp, color = color)
            }
            Spacer(Modifier.width(6.dp))
            Text(e.title, style = if (big) MaterialTheme.typography.labelLarge else MaterialTheme.typography.labelMedium,
                color = p.text, maxLines = if (open) 6 else 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            if (e.durationMs > 0) Text("%.1fs".format(e.durationMs / 1000f), style = MaterialTheme.typography.labelSmall, color = p.textTertiary)
            Spacer(Modifier.width(4.dp))
            Text(time, style = MaterialTheme.typography.labelSmall, color = p.textTertiary)
        }
        if (e.note.isNotBlank()) Text(e.note, style = MaterialTheme.typography.labelSmall, color = p.textSecondary, maxLines = 2, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(start = 21.dp))
        AnimatedVisibility(open) {
            SelectionContainer {
                Text(e.detail, style = MaterialTheme.typography.bodySmall.copy(fontFamily = if (e.kind == "tool") FontFamily.Monospace else null),
                    color = p.textSecondary, modifier = Modifier.padding(top = 4.dp).heightIn(max = 360.dp).verticalScroll(rememberScrollState()))
            }
        }
    }
}

// ───────── 成果 ─────────

@Composable
private fun ResultTab(p: DiaPalette, s: DeepSession) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val ver by AiFolder.version.collectAsState()
    val files = remember(s.folder, ver, s.cycles) {
        File(s.folder).walkTopDown().maxDepth(3).filter { it.isFile && it.name != "state.json" && it.name != "events.json" }
            .sortedByDescending { it.lastModified() }.take(80).toList()
    }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        item {
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(p.surface.copy(alpha = p.bubbleAlpha)).scrollFrame(p).padding(12.dp)) {
                Text("阶段总结", style = MaterialTheme.typography.titleMedium, color = p.cinnabar, fontFamily = DiaSerif)
                SelectionContainer {
                    Text(s.summary.ifBlank { "（每 3 轮自动更新一次）" }, style = MaterialTheme.typography.bodySmall, color = p.text)
                }
            }
        }
        item {
            Text("产出文件（灵犀AI/${AiFolder.rel(File(s.folder))}）", style = MaterialTheme.typography.labelMedium, color = p.textSecondary,
                modifier = Modifier.padding(top = 6.dp))
        }
        items(files, key = { it.absolutePath }) { f ->
            var menu by remember { mutableStateOf(false) }
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(p.surfaceAlt.copy(alpha = p.bubbleAlpha * 0.8f))
                    .clickable {
                        try { context.startActivity(AiFolder.openIntent(context, f)) } catch (_: Exception) {
                            Toast.makeText(context, "没有能打开它的应用", Toast.LENGTH_SHORT).show()
                        }
                    }.padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("📄", fontSize = 14.sp)
                Spacer(Modifier.width(6.dp))
                Column(Modifier.weight(1f)) {
                    Text(f.relativeTo(File(s.folder)).path, style = MaterialTheme.typography.labelLarge, color = p.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(AiFolder.info(f).substringAfter("  "), style = MaterialTheme.typography.labelSmall, color = p.textTertiary)
                }
                Box {
                    Text("⋮", color = p.textTertiary, fontSize = 18.sp, modifier = Modifier.clickable { menu = true }.padding(horizontal = 6.dp))
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { Text("分享") }, onClick = { menu = false; try { context.startActivity(AiFolder.shareIntent(context, f)) } catch (_: Exception) { } })
                        DropdownMenuItem(text = { Text("发到对话（作为附件）") }, onClick = {
                            menu = false
                            ChatController.addExistingFile(FileManager.attachPath(f.absolutePath))
                            com.dia.app.screen.NavBus.requestChat()
                        })
                        DropdownMenuItem(text = { Text("复制到 下载/Dia") }, onClick = {
                            menu = false
                            scope.launch {
                                val ok = try {
                                    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { FileManager.saveToDownloads(f.name, f.readBytes()) }; true
                                } catch (_: Exception) { false }
                                Toast.makeText(context, if (ok) "已复制到 下载/Dia" else "复制失败", Toast.LENGTH_SHORT).show()
                            }
                        })
                    }
                }
            }
        }
    }
}

// ───────── 底部：随时插话 ─────────

@Composable
private fun NoteInput(p: DiaPalette, s: DeepSession) {
    var text by remember(s.id) { mutableStateOf("") }
    var urgent by remember { mutableStateOf(false) }
    Column(
        Modifier.fillMaxWidth().background(p.surface.copy(alpha = 0.95f)).paperGrain(0.06f)
            .windowInsetsPadding(WindowInsets.navigationBars).windowInsetsPadding(WindowInsets.ime),
    ) {
        CloudDivider(p, Modifier.padding(horizontal = 4.dp))
        Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).background(p.background.copy(alpha = 0.55f))
                    .border(0.8.dp, p.border, RoundedCornerShape(16.dp)).padding(horizontal = 12.dp, vertical = 10.dp),
            ) {
                if (text.isEmpty()) Text("随时补充：新信息、改方向、回答 AI 的提问…", color = p.textTertiary, style = MaterialTheme.typography.bodySmall, maxLines = 1)
                BasicTextField(
                    value = text, onValueChange = { text = it }, maxLines = 5,
                    textStyle = TextStyle(color = p.text, fontSize = 14.sp, lineHeight = 20.sp), cursorBrush = SolidColor(p.cinnabar),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            Spacer(Modifier.width(6.dp))
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Switch(checked = urgent, onCheckedChange = { urgent = it }, colors = SwitchDefaults.colors(checkedTrackColor = p.cinnabar),
                    modifier = Modifier.height(24.dp))
                Text(if (urgent) "立即" else "下一轮", style = MaterialTheme.typography.labelSmall, color = p.textTertiary)
            }
            Spacer(Modifier.width(4.dp))
            IconButton(
                onClick = {
                    if (text.isNotBlank()) {
                        DeepEngine.addNote(s.id, text, urgent)
                        text = ""
                    }
                },
                modifier = Modifier.size(42.dp).clip(CircleShape).background(if (text.isNotBlank()) p.cinnabar else p.surfaceAlt),
            ) { ThemedIcon("deep.send", Icons.AutoMirrored.Rounded.Send, "发送", p.onCinnabar, 20.dp) }
        }
    }
}

// ───────── 新建 ─────────

@Composable
private fun NewDeepDialog(p: DiaPalette, onDismiss: () -> Unit, onStart: (String, String, Boolean, Boolean, Int) -> Unit) {
    var topic by remember { mutableStateOf("") }
    var web by remember { mutableStateOf(DiaSettings.deepWeb.value) }
    var auto by remember { mutableStateOf(DiaSettings.deepAutoApprove.value) }
    var review by remember { mutableStateOf(false) }
    var max by remember { mutableStateOf(0) }
    val presets = listOf(
        "调研国产新能源车三大技术路线，写成带表格的完整报告",
        "为我制定一份 6 个月的 Python 数据分析学习计划，并准备每周的练习",
        "持续跟进人工智能领域的重要新闻，每轮整理成简报",
        "设计一款记账 App：需求、功能、界面草图、技术方案",
    )
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("新建自主长思") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                OutlinedTextField(value = topic, onValueChange = { topic = it }, label = { Text("主题 / 目标（越具体越好）") }, minLines = 3, modifier = Modifier.fillMaxWidth())
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (x in presets) Chip(p, x.take(14) + "…", false) { topic = x }
                }
                Text("联网", style = MaterialTheme.typography.labelMedium, color = p.textSecondary)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    for ((k, label) in listOf("auto" to "AI 自己决定", "on" to "允许联网", "off" to "不联网")) Chip(p, label, web == k) { web = k }
                }
                Spacer(Modifier.height(6.dp))
                Text("运行多久", style = MaterialTheme.typography.labelMedium, color = p.textSecondary)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    for ((k, label) in listOf(0 to "一直到我暂停", 20 to "20 轮", 50 to "50 轮", 100 to "100 轮")) Chip(p, label, max == k) { max = k }
                }
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 6.dp)) {
                    Text("自动批准所有操作", style = MaterialTheme.typography.bodySmall, color = p.text, modifier = Modifier.weight(1f))
                    Switch(checked = auto, onCheckedChange = { auto = it }, colors = SwitchDefaults.colors(checkedTrackColor = p.cinnabar))
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("计划生成后先让我确认", style = MaterialTheme.typography.bodySmall, color = p.text, modifier = Modifier.weight(1f))
                    Switch(checked = review, onCheckedChange = { review = it }, colors = SwitchDefaults.colors(checkedTrackColor = p.cinnabar))
                }
                Text("长思在后台持续运行（通知栏显示进度，可一键暂停）；用本机模型时，你在对话里提问会优先处理。",
                    style = MaterialTheme.typography.labelSmall, color = p.textTertiary)
            }
        },
        confirmButton = { TextButton(onClick = { if (topic.isNotBlank()) onStart(topic.trim(), web, auto, review, max) }) { Text("开始", color = p.cinnabar) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("取消") } },
    )
}

@Composable
private fun Chip(p: DiaPalette, label: String, selected: Boolean, onClick: () -> Unit) {
    Text(
        label, style = MaterialTheme.typography.labelMedium, maxLines = 1,
        color = if (selected) p.onCinnabar else p.textSecondary,
        modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(if (selected) p.cinnabar else p.surfaceAlt)
            .clickable(onClick = onClick).padding(horizontal = 10.dp, vertical = 6.dp),
    )
}
