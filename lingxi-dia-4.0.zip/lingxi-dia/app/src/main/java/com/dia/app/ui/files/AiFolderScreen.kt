package com.dia.app.ui.files

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.dia.app.files.AiFolder
import com.dia.app.files.FileManager
import com.dia.app.screen.NavBus
import com.dia.app.ui.chat.ChatController
import com.dia.app.ui.theme.CloudDivider
import com.dia.app.ui.theme.DiaPal
import com.dia.app.ui.theme.DiaSerif
import com.dia.app.ui.theme.ThemedGlyph
import com.dia.app.ui.theme.inkWashBackground
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** 「AI 文件夹」：浏览灵犀自己生成的一切（作品、图片、长思、转写、笔记、主题）。 */
@Composable
fun AiFolderScreen(onBack: () -> Unit) {
    val p = DiaPal.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val ver by AiFolder.version.collectAsState()
    var dir by remember { mutableStateOf(AiFolder.root()) }
    var refresh by remember { mutableStateOf(0) }
    var toDelete by remember { mutableStateOf<File?>(null) }
    val root = remember(ver, refresh) { AiFolder.root() }
    val items = remember(dir, ver, refresh) {
        dir.listFiles()?.filter { !it.name.startsWith(".") }
            ?.sortedWith(compareBy<File>({ !it.isDirectory }, { -it.lastModified() })).orEmpty()
    }
    val atRoot = dir.canonicalPath == root.canonicalPath
    BackHandler(enabled = !atRoot) { dir = dir.parentFile ?: root }
    val fmt = remember { SimpleDateFormat("M月d日 HH:mm", Locale.CHINA) }

    Column(Modifier.fillMaxSize().inkWashBackground(p).windowInsetsPadding(WindowInsets.statusBars)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { if (atRoot) onBack() else dir = dir.parentFile ?: root }) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, "返回", tint = p.text)
            }
            Column(Modifier.weight(1f)) {
                Text("AI 文件夹", style = MaterialTheme.typography.headlineMedium, color = p.text, fontFamily = DiaSerif)
                Text(AiFolder.locationLabel(), style = MaterialTheme.typography.labelSmall, color = p.textTertiary, maxLines = 2)
            }
        }
        // 面包屑
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            val parts = AiFolder.rel(dir).split('/').filter { it.isNotBlank() && it != "." }
            Text(AiFolder.NAME, color = p.cinnabar, style = MaterialTheme.typography.labelLarge, modifier = Modifier.clickable { dir = root })
            var acc = root
            for (part in parts) {
                acc = File(acc, part)
                val target = acc
                Text(" / ", color = p.textTertiary)
                Text(part, color = p.cinnabar, style = MaterialTheme.typography.labelLarge, modifier = Modifier.clickable { dir = target })
            }
        }
        if (!AiFolder.isPublic() && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Text(
                "开启「所有文件访问」后，这个文件夹会搬到手机存储根目录「灵犀AI」，用任何文件管理器都能看到 → 点此开启",
                style = MaterialTheme.typography.labelSmall, color = p.indigo,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp).clip(RoundedCornerShape(8.dp))
                    .background(p.indigo.copy(alpha = 0.10f)).clickable {
                        try {
                            context.startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${context.packageName}")))
                        } catch (_: Exception) {
                            try { context.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) } catch (_: Exception) { }
                        }
                    }.padding(8.dp),
            )
        }
        CloudDivider(p, Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
        LazyColumn(
            Modifier.fillMaxWidth().weight(1f),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            if (items.isEmpty()) item { Text("（空）", color = p.textTertiary, modifier = Modifier.padding(16.dp)) }
            items(items, key = { it.absolutePath }) { f ->
                var menu by remember { mutableStateOf(false) }
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(p.surface.copy(alpha = p.bubbleAlpha * 0.85f))
                        .clickable {
                            if (f.isDirectory) dir = f else try {
                                context.startActivity(AiFolder.openIntent(context, f))
                            } catch (_: Exception) {
                                Toast.makeText(context, "没有能打开它的应用", Toast.LENGTH_SHORT).show()
                            }
                        }.padding(horizontal = 10.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    ThemedGlyph(if (f.isDirectory) "folder.dir" else "folder.file", if (f.isDirectory) "📁" else "📄", p.text, 24.dp, brush = false)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(f.name, style = MaterialTheme.typography.titleSmall, color = p.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            (if (f.isDirectory) "${f.listFiles()?.size ?: 0} 项" else AiFolder.sizeLabel(f.length())) + " · " + fmt.format(Date(f.lastModified())),
                            style = MaterialTheme.typography.labelSmall, color = p.textTertiary,
                        )
                    }
                    androidx.compose.foundation.layout.Box {
                        Text("⋮", color = p.textTertiary, modifier = Modifier.clickable { menu = true }.padding(horizontal = 8.dp))
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            if (f.isFile) {
                                DropdownMenuItem(text = { Text("分享") }, onClick = {
                                    menu = false
                                    try { context.startActivity(AiFolder.shareIntent(context, f)) } catch (_: Exception) { }
                                })
                                DropdownMenuItem(text = { Text("发到对话（作为附件）") }, onClick = {
                                    menu = false
                                    if (f.extension.lowercase() in setOf("png", "jpg", "jpeg", "webp")) ChatController.addImageUri(Uri.fromFile(f))
                                    else ChatController.addExistingFile(FileManager.attachPath(f.absolutePath))
                                    NavBus.requestChat()
                                })
                                DropdownMenuItem(text = { Text("复制到 下载/Dia") }, onClick = {
                                    menu = false
                                    scope.launch {
                                        val ok = try { withContext(Dispatchers.IO) { FileManager.saveToDownloads(f.name, f.readBytes()) }; true } catch (_: Exception) { false }
                                        Toast.makeText(context, if (ok) "已复制到 下载/Dia" else "复制失败", Toast.LENGTH_SHORT).show()
                                    }
                                })
                                HorizontalDivider()
                            }
                            DropdownMenuItem(text = { Text("删除", color = p.error) }, onClick = { menu = false; toDelete = f })
                        }
                    }
                }
            }
        }
        Text(
            "AI 用 ai_files 工具读写这里；也可以让它「把刚才的内容存到你的笔记」「看看你的文件夹里有什么」。",
            style = MaterialTheme.typography.labelSmall, color = p.textTertiary,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp).windowInsetsPadding(WindowInsets.navigationBars),
        )
    }
    toDelete?.let { f ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("删除「${f.name}」？") },
            text = { Text(if (f.isDirectory) "整个目录都会删除，无法恢复。" else "删除后无法恢复。") },
            confirmButton = {
                TextButton(onClick = {
                    val isTop = f.parentFile?.canonicalPath == root.canonicalPath && f.name in AiFolder.SUBDIRS
                    if (isTop) f.listFiles()?.forEach { it.deleteRecursively() } else f.deleteRecursively()
                    AiFolder.touch(); refresh++; toDelete = null
                }) { Text("删除", color = p.error) }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("取消") } },
        )
    }
}
