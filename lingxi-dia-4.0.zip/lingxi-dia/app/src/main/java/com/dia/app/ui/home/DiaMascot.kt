package com.dia.app.ui.home

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import com.dia.app.ui.theme.DiaAccent
import kotlinx.coroutines.delay
import kotlin.random.Random

/**
 * Dia's mascot — a cute glowing orb with friendly eyes and a smile.
 * Futuristic yet humane. Breathes, blinks, and pulses gently.
 */
@Composable
fun DiaMascot(
    modifier: Modifier = Modifier,
    accentColor: Color = DiaAccent
) {
    val infiniteTransition = rememberInfiniteTransition(label = "mascot")

    // Breathing animation — gentle scale oscillation
    val breathScale by infiniteTransition.animateFloat(
        initialValue = 0.96f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(
            animation = tween(2500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "breath"
    )

    // Glow pulse — synced slightly offset from breathing
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.25f,
        targetValue = 0.55f,
        animationSpec = infiniteRepeatable(
            animation = tween(2500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow"
    )

    // Inner shimmer rotation
    val shimmerAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(8000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shimmer"
    )

    // Eye blink
    var isBlinking by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(Random.nextLong(3000, 5500))
            isBlinking = true
            delay(120)
            isBlinking = false
        }
    }
    val eyeOpenness by animateFloatAsState(
        targetValue = if (isBlinking) 0.1f else 1f,
        animationSpec = tween(80),
        label = "blink"
    )

    Canvas(
        modifier = modifier
            .size(140.dp)
            .graphicsLayer {
                scaleX = breathScale
                scaleY = breathScale
            }
    ) {
        val center = this.center
        val bodyRadius = size.minDimension * 0.32f

        // ── Outer glow aura ──
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    accentColor.copy(alpha = glowAlpha * 0.35f),
                    accentColor.copy(alpha = glowAlpha * 0.15f),
                    accentColor.copy(alpha = glowAlpha * 0.05f),
                    Color.Transparent
                ),
                center = center,
                radius = bodyRadius * 2.2f
            )
        )

        // ── Middle glow ring ──
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    accentColor.copy(alpha = glowAlpha * 0.2f),
                    Color.Transparent
                ),
                center = center,
                radius = bodyRadius * 1.5f
            )
        )

        // ── Main body — dark sphere with gradient ──
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    Color(0xFF1A2A40),
                    Color(0xFF0F1923),
                    Color(0xFF080E15)
                ),
                center = Offset(center.x - bodyRadius * 0.15f, center.y - bodyRadius * 0.2f),
                radius = bodyRadius * 1.2f
            ),
            radius = bodyRadius,
            center = center
        )

        // ── Body edge ring — subtle accent outline ──
        drawCircle(
            color = accentColor.copy(alpha = 0.15f),
            radius = bodyRadius,
            center = center,
            style = Stroke(width = 1.5f)
        )

        // ── Highlight / specular shine ──
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    Color.White.copy(alpha = 0.12f),
                    Color.White.copy(alpha = 0.03f),
                    Color.Transparent
                ),
                center = Offset(center.x - bodyRadius * 0.25f, center.y - bodyRadius * 0.35f),
                radius = bodyRadius * 0.6f
            ),
            radius = bodyRadius * 0.9f,
            center = center
        )

        // ── Eyes ──
        val eyeY = center.y - bodyRadius * 0.08f
        val eyeSpacing = bodyRadius * 0.28f
        val eyeWidth = bodyRadius * 0.1f
        val eyeHeight = bodyRadius * 0.12f * eyeOpenness

        // Left eye
        val leftEyePath = Path().apply {
            addRoundRect(
                RoundRect(
                    left = center.x - eyeSpacing - eyeWidth,
                    top = eyeY - eyeHeight,
                    right = center.x - eyeSpacing + eyeWidth,
                    bottom = eyeY + eyeHeight,
                    cornerRadius = CornerRadius(eyeWidth, eyeHeight)
                )
            )
        }
        drawPath(leftEyePath, color = accentColor)

        // Right eye
        val rightEyePath = Path().apply {
            addRoundRect(
                RoundRect(
                    left = center.x + eyeSpacing - eyeWidth,
                    top = eyeY - eyeHeight,
                    right = center.x + eyeSpacing + eyeWidth,
                    bottom = eyeY + eyeHeight,
                    cornerRadius = CornerRadius(eyeWidth, eyeHeight)
                )
            )
        }
        drawPath(rightEyePath, color = accentColor)

        // ── Eye glow ──
        listOf(center.x - eyeSpacing, center.x + eyeSpacing).forEach { ex ->
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        accentColor.copy(alpha = 0.3f),
                        Color.Transparent
                    ),
                    center = Offset(ex, eyeY),
                    radius = eyeWidth * 3f
                ),
                radius = eyeWidth * 3f,
                center = Offset(ex, eyeY)
            )
        }

        // ── Smile ──
        drawArc(
            color = accentColor.copy(alpha = 0.6f),
            startAngle = 15f,
            sweepAngle = 150f,
            useCenter = false,
            topLeft = Offset(center.x - bodyRadius * 0.18f, eyeY + bodyRadius * 0.12f),
            size = Size(bodyRadius * 0.36f, bodyRadius * 0.18f),
            style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
        )
    }
}
