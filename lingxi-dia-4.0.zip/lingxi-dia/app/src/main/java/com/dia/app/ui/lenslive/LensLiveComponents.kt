package com.dia.app.ui.lenslive

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.util.Log
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Psychology
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dia.app.ui.theme.DiaLensListening
import com.dia.app.ui.theme.DiaTextSecondary
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

private const val TAG = "LensLiveComponents"

/**
 * Aurora flowing edge border animation — Gemini Live style.
 * [tintColor] shifts the palette toward a specific hue.
 */
@Composable
internal fun AuroraBorder(auroraAngle: Float, auroraActual: Float, tintColor: Color) {
    if (auroraActual < 0.01f) return

    // Blend the default aurora palette toward the tint color
    val c1 = lerpColor(Color(0xFF7AD8FF), tintColor, 0.3f)
    val c2 = lerpColor(Color(0xFF8FA8FF), tintColor, 0.2f)
    val c3 = lerpColor(Color(0xFFFF8FD1), tintColor, 0.15f)
    val c4 = lerpColor(Color(0xFF6CF3FF), tintColor, 0.25f)
    val c5 = lerpColor(Color(0xFF9C7BFF), tintColor, 0.2f)

    Canvas(
        modifier = Modifier
            .fillMaxSize()
            .blur(36.dp)
    ) {
        val w = size.width
        val h = size.height
        val borderW = 8.dp.toPx()

        val stops = listOf(
            0.00f to c1.copy(alpha = auroraActual),
            0.20f to c2.copy(alpha = auroraActual * 0.85f),
            0.40f to c3.copy(alpha = auroraActual),
            0.60f to c4.copy(alpha = auroraActual * 0.8f),
            0.80f to c5.copy(alpha = auroraActual * 0.85f),
            1.00f to c1.copy(alpha = auroraActual),
        )

        val topRatio = ((auroraAngle % 360) / 360f)

        // Top edge
        drawRect(
            brush = Brush.horizontalGradient(
                colorStops = stops.map {
                    val shift = (it.first + topRatio) % 1f
                    shift to it.second
                }.sortedBy { it.first }.toTypedArray(),
                startX = 0f, endX = w
            ),
            size = androidx.compose.ui.geometry.Size(w, borderW * 2)
        )
        // Bottom edge
        drawRect(
            brush = Brush.horizontalGradient(
                colorStops = stops.map {
                    val shift = ((it.first + topRatio + 0.5f) % 1f)
                    shift to it.second
                }.sortedBy { it.first }.toTypedArray(),
                startX = 0f, endX = w
            ),
            topLeft = Offset(0f, h - borderW * 2),
            size = androidx.compose.ui.geometry.Size(w, borderW * 2)
        )
        // Left edge
        drawRect(
            brush = Brush.verticalGradient(
                colorStops = stops.map {
                    val shift = ((it.first + topRatio + 0.25f) % 1f)
                    shift to it.second
                }.sortedBy { it.first }.toTypedArray(),
                startY = 0f, endY = h
            ),
            size = androidx.compose.ui.geometry.Size(borderW * 2, h)
        )
        // Right edge
        drawRect(
            brush = Brush.verticalGradient(
                colorStops = stops.map {
                    val shift = ((it.first + topRatio + 0.75f) % 1f)
                    shift to it.second
                }.sortedBy { it.first }.toTypedArray(),
                startY = 0f, endY = h
            ),
            topLeft = Offset(w - borderW * 2, 0f),
            size = androidx.compose.ui.geometry.Size(borderW * 2, h)
        )

        // Bottom wavy glow
        if (auroraActual > 0.1f) {
            val waveH = h * 0.12f
            val waveY = h - waveH
            val offsetX = (w * 2f) * ((auroraAngle % 360) / 360f)
            val waveStops = stops.toTypedArray()

            drawOval(
                brush = Brush.horizontalGradient(
                    colorStops = waveStops,
                    startX = -w * 0.5f + offsetX, endX = w * 1.5f + offsetX
                ),
                topLeft = Offset(-w * 0.2f, waveY),
                size = androidx.compose.ui.geometry.Size(w * 1.4f, waveH * 1.5f),
                alpha = auroraActual * 0.7f
            )
            drawOval(
                brush = Brush.horizontalGradient(
                    colorStops = waveStops,
                    startX = w * 1.5f - offsetX, endX = -w * 0.5f - offsetX
                ),
                topLeft = Offset(w * 0.1f, waveY + 20f),
                size = androidx.compose.ui.geometry.Size(w * 1.2f, waveH * 1.2f),
                alpha = auroraActual
            )
        }
    }
}

/**
 * Caption bubble — premium pill-style text overlay.
 */
@Composable
internal fun CaptionBubble(
    text: String,
    color: Color,
    isUser: Boolean,
    isStreaming: Boolean,
    alpha: Float = 1f,
) {
    val bgColor = if (isUser)
        color.copy(alpha = 0.18f * alpha)
    else
        Color.Black.copy(alpha = 0.52f * alpha)
    val borderColor = if (isUser)
        color.copy(alpha = 0.45f * alpha)
    else
        Color.White.copy(alpha = 0.08f * alpha)
    val shape = if (isUser)
        RoundedCornerShape(topStart = 18.dp, topEnd = 4.dp, bottomStart = 18.dp, bottomEnd = 18.dp)
    else
        RoundedCornerShape(topStart = 4.dp, topEnd = 18.dp, bottomStart = 18.dp, bottomEnd = 18.dp)

    Box(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier
                .align(if (isUser) Alignment.CenterEnd else Alignment.CenterStart)
                .widthIn(max = 300.dp)
                .clip(shape)
                .background(bgColor)
                .border(0.5.dp, borderColor, shape)
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Text(
                text = text,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontWeight = if (isUser) FontWeight.SemiBold else FontWeight.Normal,
                    lineHeight = 22.sp,
                    letterSpacing = 0.15.sp,
                    shadow = androidx.compose.ui.graphics.Shadow(
                        color = Color.Black.copy(alpha = 0.7f),
                        offset = Offset(0f, 1f),
                        blurRadius = 4f
                    )
                ),
                color = if (isUser) color.copy(alpha = alpha) else Color.White.copy(alpha = alpha),
                textAlign = if (isUser) TextAlign.End else TextAlign.Start,
            )
            if (isStreaming) {
                val blink = rememberInfiniteTransition(label = "cursor")
                val cursorAlpha by blink.animateFloat(
                    0f, 1f,
                    infiniteRepeatable(tween(500), RepeatMode.Reverse),
                    label = "cur"
                )
                Text(
                    "▍",
                    style = MaterialTheme.typography.bodyMedium,
                    color = color.copy(alpha = cursorAlpha),
                )
            }
        }
    }
}

/**
 * Thinking indicator with animated dots.
 */
@Composable
internal fun ThinkingIndicator(stateColor: Color, isDeep: Boolean) {
    val transition = rememberInfiniteTransition(label = "think")
    val dotAlpha by transition.animateFloat(
        initialValue = 0.2f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(animation = tween(500), repeatMode = RepeatMode.Reverse),
        label = "thinkDot"
    )
    val shimmerOffset by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(animation = tween(2000, easing = LinearEasing), repeatMode = RepeatMode.Restart),
        label = "shimmer"
    )

    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(
                if (isDeep) Brush.horizontalGradient(
                    colors = listOf(
                        Color(0xFFE040FB).copy(alpha = 0.08f + shimmerOffset * 0.08f),
                        Color(0xFF7C4DFF).copy(alpha = 0.12f),
                        Color(0xFFE040FB).copy(alpha = 0.08f + (1f - shimmerOffset) * 0.08f),
                    )
                )
                else Brush.horizontalGradient(
                    colors = listOf(Color.Black.copy(alpha = 0.35f), Color.Black.copy(alpha = 0.35f))
                )
            )
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Icon(
            if (isDeep) Icons.Rounded.Psychology else Icons.Rounded.Visibility, null,
            tint = stateColor.copy(alpha = dotAlpha),
            modifier = Modifier.size(18.dp)
        )
        Text(
            if (isDeep) "深度思考中…" else "分析中…",
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
            color = stateColor.copy(alpha = 0.6f + dotAlpha * 0.4f)
        )
        Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
            repeat(3) { idx ->
                val a = ((dotAlpha + idx * 0.2f) % 1f).coerceIn(0.3f, 1f)
                Box(
                    modifier = Modifier
                        .size(5.dp)
                        .clip(CircleShape)
                        .background(stateColor.copy(alpha = a))
                )
            }
        }
    }
}

/**
 * Full-screen initializing overlay.
 */
@Composable
internal fun InitializingOverlay() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.85f)),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            CircularProgressIndicator(
                modifier = Modifier.size(48.dp),
                color = DiaLensListening,
                strokeWidth = 3.dp
            )
            Spacer(modifier = Modifier.height(20.dp))
            Text(
                "正在初始化镜头…",
                color = Color.White,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Medium)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                "相机与 AI 正在预热",
                color = DiaTextSecondary,
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

/**
 * Capture a camera frame, scale to 512px max dimension, optionally mirror.
 */
internal suspend fun captureFrameScaled(
    imageCapture: ImageCapture,
    executor: java.util.concurrent.Executor,
    mirror: Boolean,
): Bitmap? = suspendCancellableCoroutine { cont ->
    imageCapture.takePicture(
        executor,
        object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                try {
                    val buffer = image.planes[0].buffer
                    val bytes = ByteArray(buffer.remaining())
                    buffer.get(bytes)
                    val rotation = image.imageInfo.rotationDegrees
                    image.close()

                    val raw = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    if (raw == null) { cont.resume(null); return }

                    val scale = 512f / maxOf(raw.width, raw.height)
                    val scaledW = (raw.width * scale).toInt()
                    val scaledH = (raw.height * scale).toInt()
                    var scaled = Bitmap.createScaledBitmap(raw, scaledW, scaledH, true)

                    if (rotation != 0 || mirror) {
                        val matrix = Matrix().apply {
                            if (rotation != 0) postRotate(rotation.toFloat())
                            if (mirror) postScale(-1f, 1f)
                        }
                        scaled = Bitmap.createBitmap(scaled, 0, 0, scaled.width, scaled.height, matrix, true)
                    }
                    Log.d(TAG, "Frame captured: ${scaled.width}x${scaled.height}")
                    cont.resume(scaled)
                } catch (e: Exception) {
                    Log.e(TAG, "Frame decode error", e)
                    cont.resume(null)
                }
            }

            override fun onError(exception: ImageCaptureException) {
                Log.e(TAG, "takePicture failed: ${exception.message}")
                cont.resume(null)
            }
        }
    )
}

/**
 * Simple color lerp utility.
 */
private fun lerpColor(start: Color, end: Color, fraction: Float): Color {
    val f = fraction.coerceIn(0f, 1f)
    return Color(
        red = start.red + (end.red - start.red) * f,
        green = start.green + (end.green - start.green) * f,
        blue = start.blue + (end.blue - start.blue) * f,
        alpha = start.alpha + (end.alpha - start.alpha) * f,
    )
}
