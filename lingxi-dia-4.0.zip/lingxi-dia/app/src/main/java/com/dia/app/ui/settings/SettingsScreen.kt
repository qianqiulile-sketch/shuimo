package com.dia.app.ui.settings

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.dia.app.files.FileManager
import com.dia.app.imagegen.ImageGen
import com.dia.app.imagegen.LocalImageGen
import com.dia.app.llm.DiaEngine
import com.dia.app.llm.ModelManager
import com.dia.app.prefs.DiaPrefs
import com.dia.app.prefs.DiaSettings
import com.dia.app.prefs.IntPref
import com.dia.app.prefs.StringPref
import com.dia.app.ui.chat.ToggleRow
import com.dia.app.ui.theme.CloudDivider
import com.dia.app.ui.theme.DiaPal
import com.dia.app.ui.theme.DiaPalette
import com.dia.app.ui.theme.DiaSerif
import com.dia.app.ui.theme.inkWashBackground
import com.dia.app.ui.theme.scrollFrame
import com.dia.app.ui.theme.paperGrain
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** 设置（全中文，按功能分组）。 */
@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    onOpenModelSetup: () -> Unit,
    onEditBubble: () -> Unit,
    onReplayOnboarding: () -> Unit = {},
    onOpenTheme: () -> Unit = {},
    onOpenAiFolder: () -> Unit = {},
    onOpenDeep: () -> Unit = {},
) {
    val p = DiaPal.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var confirmUnload by remember { mutableStateOf(false) }
    var confirmDownload by remember { mutableStateOf(false) }
    var imgStatus by remember { mutableStateOf("") }
    val localStatus by LocalImageGen.status.collectAsState()
    val sttStatus by com.dia.app.voice.VoskModels.status.collectAsState()
    val sttVer by com.dia.app.voice.VoskModels.installedVersion.collectAsState()
    var sttMsg by remember { mutableStateOf("") }
    val importStt = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) scope.launch {
            sttMsg = try { "已导入：" + com.dia.app.voice.VoskModels.importZip(context, uri) } catch (e: Exception) { "导入失败：${e.message}" }
        }
    }

    val pickBg = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                val path = withContext(Dispatchers.IO) {
                    try {
                        val dir = java.io.File(context.filesDir, "bg").apply { mkdirs() }
                        val out = java.io.File(dir, "bg_${System.currentTimeMillis()}.img")
                        context.contentResolver.openInputStream(uri)?.use { input -> out.outputStream().use { input.copyTo(it) } }
                        dir.listFiles()?.filter { it.absolutePath != out.absolutePath }?.forEach { it.delete() }
                        out.absolutePath
                    } catch (_: Exception) { null }
                }
                if (path != null) DiaSettings.customBgPath.set(path)
            }
        }
    }

    val importTree = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                imgStatus = try {
                    val n = withContext(Dispatchers.IO) { LocalImageGen.importFromTree(context, uri) }
                    "已导入 $n 个模型文件"
                } catch (e: Exception) { "导入失败：${e.message}" }
            }
        }
    }

    Column(Modifier.fillMaxSize().inkWashBackground(p).windowInsetsPadding(WindowInsets.statusBars)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "返回", tint = p.text) }
            Text("设置 · 江湖规矩", style = MaterialTheme.typography.headlineMedium, color = p.text, fontFamily = DiaSerif)
        }
        CloudDivider(p, Modifier.padding(horizontal = 16.dp))

        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(vertical = 12.dp)) {
            // ── 自主长思（4.0） ──
            item {
                Section(p, "🧠 自主长思") {
                    ActionRow(p, "打开自主长思", "给一个主题，AI 自己拆计划、调用一切工具、一直做到你暂停", onClick = onOpenDeep)
                    val web by DiaSettings.deepWeb.flow.collectAsState()
                    ChoiceRow(p, "新建长思默认联网", listOf("auto" to "AI 自己决定", "on" to "允许联网", "off" to "不联网"), web) { DiaSettings.deepWeb.set(it) }
                    ToggleRow(p, "自动批准所有操作", "长思时改文件、下载、操控手机等不再逐项确认", DiaSettings.deepAutoApprove.flow.collectAsState().value) { DiaSettings.deepAutoApprove.set(it) }
                    val per by DiaSettings.deepToolsPerStep.flow.collectAsState()
                    ChoiceRow(p, "每一步最多调用工具", listOf("12" to "12 次", "24" to "24 次", "48" to "48 次", "0" to "不限"), per.toString()) { DiaSettings.deepToolsPerStep.set(it.toInt()) }
                    ToggleRow(p, "计划做完后继续深挖", "自己复盘、提出新方向，一直运行到你暂停", DiaSettings.deepEndless.flow.collectAsState().value) { DiaSettings.deepEndless.set(it) }
                    ToggleRow(p, "打开灵犀时自动继续", "上次没暂停的长思自动接着跑", DiaSettings.deepResumeOnStart.flow.collectAsState().value) { DiaSettings.deepResumeOnStart.set(it) }
                    val delay by DiaSettings.deepCycleDelay.flow.collectAsState()
                    ChoiceRow(p, "每轮间隔", listOf("0" to "不停", "2" to "2 秒", "10" to "10 秒", "60" to "1 分钟"), delay.toString()) { DiaSettings.deepCycleDelay.set(it.toInt()) }
                    Hint(p, "长思在后台由常驻通知保活，通知上可一键暂停。用本机模型时，你在对话里提问会优先处理；用云端模型时两边同时进行。")
                }
            }
            // ── 工具调用（4.0） ──
            item {
                Section(p, "工具调用") {
                    ToggleRow(p, "调用前说明意图", "每次调用工具前 AI 先说一句要做什么，显示在工具卡片上", DiaSettings.toolReasons.flow.collectAsState().value) { DiaSettings.toolReasons.set(it) }
                    val review by DiaSettings.stepReview.flow.collectAsState()
                    ChoiceRow(p, "分步思考拆完后", listOf("off" to "直接求解", "brief" to "停几秒可修改", "always" to "等我确认"), review) { DiaSettings.stepReview.set(it) }
                    Hint(p, "你也可以亲自调用任何工具：输入框旁的「器」打开工具台，或者写「@工具名 内容」（如「@联网搜索 今日新闻」）。AI 自主调用和你亲自调用可以同时进行。")
                }
            }
            // ── AI 文件夹（4.0） ──
            item {
                Section(p, "🗂 AI 专属文件夹") {
                    Info(p, "位置", com.dia.app.files.AiFolder.locationLabel())
                    ActionRow(p, "打开 AI 文件夹", "作品 / 图片 / 长思 / 转写 / 笔记 / 主题", onClick = onOpenAiFolder)
                    val saveTo by DiaSettings.aiSaveTo.flow.collectAsState()
                    ChoiceRow(p, "AI 新建的文件保存到", listOf("ai" to "灵犀AI/作品", "download" to "下载/Dia"), saveTo) { DiaSettings.aiSaveTo.set(it) }
                    Hint(p, "开启「文件与权限 → 所有文件访问」后，AI 文件夹会放在手机存储根目录「灵犀AI」，任何文件管理器都能看到。")
                }
            }
            // ── 语音转文字（4.0） ──
            item {
                Section(p, "🎙 语音转文字") {
                    val eng by DiaSettings.sttEngine.flow.collectAsState()
                    ChoiceRow(p, "对话里说话用", listOf("auto" to "自动", "vosk" to "离线模型", "system" to "系统识别", "cloud" to "云端", "gemma" to "本机大模型"), eng) { DiaSettings.sttEngine.set(it) }
                    val feng by DiaSettings.sttFileEngine.flow.collectAsState()
                    ChoiceRow(p, "音频文件转文字用", listOf("auto" to "自动", "vosk" to "离线模型", "cloud" to "云端", "gemma" to "本机大模型"), feng) { DiaSettings.sttFileEngine.set(it) }
                    ToggleRow(p, "转写后让 AI 加标点、分段", "离线模型输出没有标点，开启后更好读", DiaSettings.sttPolish.flow.collectAsState().value) { DiaSettings.sttPolish.set(it) }
                    // 离线模型
                    val installedModels = remember(sttVer) { com.dia.app.voice.VoskModels.installed(context) }
                    val currentModel by DiaSettings.sttModel.flow.collectAsState()
                    Info(p, "离线语音模型（Vosk，嵌入 App，完全离线）", if (installedModels.isEmpty()) "还没有安装" else "已安装：" + installedModels.joinToString("、"))
                    val inUseName = remember(sttVer, currentModel) { com.dia.app.voice.VoskModels.current(context)?.name }
                    for (m in com.dia.app.voice.VoskModels.CATALOG) {
                        val has = m.id in installedModels
                        val inUse = has && inUseName == m.id
                        ActionRow(
                            p, (if (has) "✓ " else "下载 ") + m.name + "（${m.size}）",
                            when {
                                inUse -> "正在使用 · 点此删除"
                                has -> "已安装 · 点此改用这个模型"
                                else -> "从 alphacephei.com 下载并安装"
                            },
                            danger = inUse,
                        ) {
                            when {
                                inUse -> com.dia.app.voice.VoskModels.delete(context, m.id)
                                has -> DiaSettings.sttModel.set(m.id)
                                com.dia.app.voice.VoskModels.isBusy -> sttMsg = "正在安装另一个模型…"
                                else -> scope.launch {
                                    sttMsg = try { "已安装：" + com.dia.app.voice.VoskModels.download(context, DiaSettings.sttModelUrl.value.ifBlank { m.url }, m.id) }
                                    catch (e: Exception) { "下载失败：${e.message}（可以用电脑下载 zip 后点下面的「导入」）" }
                                }
                            }
                        }
                    }
                    ActionRow(p, "从手机导入模型 zip", "例如从电脑下载的 vosk-model-small-cn-0.22.zip") { importStt.launch(arrayOf("application/zip", "*/*")) }
                    TextPref(p, "自定义下载地址（可选，国内镜像等）", DiaSettings.sttModelUrl, "https://…/vosk-model-small-cn-0.22.zip")
                    if (sttStatus.isNotBlank()) Hint(p, sttStatus)
                    if (sttMsg.isNotBlank()) Hint(p, sttMsg)
                    // 云端
                    TextPref(p, "云端转写地址（留空沿用云端模型）", DiaSettings.sttCloudBaseUrl, "https://api.siliconflow.cn/v1")
                    TextPref(p, "云端转写 Key（留空沿用云端模型）", DiaSettings.sttCloudApiKey, "sk-…", secret = true)
                    TextPref(p, "云端转写模型", DiaSettings.sttCloudModel, "whisper-1 / FunAudioLLM/SenseVoiceSmall / whisper-large-v3")
                    Hint(p, "AI 可以自己选：用 transcribe_audio 把音频 / 视频转成文字再处理，或用 listen_audio 让本机 Gemma 直接听（能听出语气和背景声）。长按麦克风仍然是录音交给本机模型直接听。")
                }
            }
            // ── 无极模式 ──
            item {
                Section(p, "☯ 无极模式") {
                    ToggleRow(p, "开启无极模式", "调动全部权限、自动批准所有操作、工具不限次数、深度 + 分布式思考，直到任务完成",
                        DiaSettings.wujiMode.flow.collectAsState().value) { com.dia.app.ui.chat.ChatController.setWuji(it) }
                    val workers by DiaSettings.wujiWorkers.flow.collectAsState()
                    ChoiceRow(p, "分身数量（分布式思考的并行数，云端模型生效）", listOf("2" to "二", "3" to "三", "4" to "四", "6" to "六"), workers.toString()) {
                        DiaSettings.wujiWorkers.set(it.toInt())
                    }
                    ToggleRow(p, "完成后自检", "回答完自动验收，没做完就接着做", DiaSettings.wujiSelfCheck.flow.collectAsState().value) { DiaSettings.wujiSelfCheck.set(it) }
                    Hint(p, "也可以在对话顶栏点「☯」，或直接说「开启无极模式」。无极模式下界面会换成墨金配色。")
                }
            }
            // ── 分步思考 ──
            item {
                Section(p, "分步思考") {
                    val mode by DiaSettings.stepThinking.flow.collectAsState()
                    ChoiceRow(p, "何时分步思考", listOf("off" to "关闭", "auto" to "复杂问题自动", "on" to "每个问题"), mode) { DiaSettings.stepThinking.set(it) }
                    ToggleRow(p, "拆解前先联网检索", "先搜一下，问题拆得更准", DiaSettings.stepPreSearch.flow.collectAsState().value) { DiaSettings.stepPreSearch.set(it) }
                    val depth by DiaSettings.stepMaxDepth.flow.collectAsState()
                    ChoiceRow(p, "最多拆几层", listOf("1" to "一层", "2" to "两层", "3" to "三层", "4" to "四层"), depth.toString()) { DiaSettings.stepMaxDepth.set(it.toInt()) }
                    val branch by DiaSettings.stepMaxBranch.flow.collectAsState()
                    ChoiceRow(p, "每层最多几个小问题", listOf("2" to "2", "3" to "3", "4" to "4", "5" to "5", "6" to "6"), branch.toString()) { DiaSettings.stepMaxBranch.set(it.toInt()) }
                    Hint(p, "复杂问题会先拆成小问题，逐个检索求解后再综合作答，回答更深入但更慢。也可以用「/分步 问题」强制分步。")
                }
            }
            // ── 外观 ──
            item {
                Section(p, "外观 · 水墨江湖") {
                    val mode by DiaSettings.themeMode.flow.collectAsState()
                    val installedThemes by com.dia.app.ui.theme.ThemeManager.installed.collectAsState()
                    ChoiceRow(p, "主题", listOf("paper" to "宣纸山水（浅）", "ink" to "江湖夜色（深）") + installedThemes.map { it.id to it.name }, mode) { DiaSettings.themeMode.set(it) }
                    ActionRow(p, "主题与图标", "导入主题包、AI 生成主题、把每一个图标换成图片或文字、改颜色 / 背景 / 头像 / 字体", onClick = onOpenTheme)
                    val strength by DiaSettings.bgStrength.flow.collectAsState()
                    ChoiceRow(p, "背景画浓淡", listOf("35" to "淡", "70" to "适中", "100" to "浓"), strength.toString()) { DiaSettings.bgStrength.set(it.toInt()) }
                    ActionRow(p, "从相册选一张图做背景", "选一张你喜欢的画") { pickBg.launch("image/*") }
                    ActionRow(p, "让灵犀画一张背景", "回到对话，输入「/背景 描述」，例如：/背景 雪夜孤舟") {
                        com.dia.app.ui.chat.ChatController.setDraft("/背景 ")
                        onBack()
                    }
                    if (DiaSettings.customBgPath.flow.collectAsState().value.isNotBlank()) {
                        ActionRow(p, "恢复内置水墨背景", "") { DiaSettings.customBgPath.set("") }
                    }
                    ToggleRow(p, "大字体", "放大全局文字", DiaPrefs.bigText.collectAsState().value) { DiaPrefs.setBigText(it) }
                    ToggleRow(p, "减少动画", "降低动效，更省电", DiaPrefs.reduceMotion.collectAsState().value) { DiaPrefs.setReduceMotion(it) }
                }
            }
            // ── 模型 ──
            item {
                Section(p, "本地模型") {
                    Info(p, "当前模型", DiaEngine.currentModelPath?.substringAfterLast('/') ?: "未加载")
                    ToggleRow(p, "启动时自动加载", "打开灵犀时自动载入上次使用的模型", DiaPrefs.autoLoadModel.collectAsState().value) { DiaPrefs.setAutoLoadModel(it) }
                    val ctx by DiaSettings.contextTokens.flow.collectAsState()
                    ChoiceRow(p, "上下文长度（重新加载模型后生效）", listOf("4096" to "4K（省内存）", "8192" to "8K（推荐）", "16384" to "16K"), ctx.toString()) {
                        DiaSettings.contextTokens.set(it.toInt())
                    }
                    ActionRow(p, "导入 / 管理模型文件", "从手机中选择 .litertlm 模型", onClick = onOpenModelSetup)
                    ActionRow(p, "重新加载模型", "应用新的上下文长度") { scope.launch { ModelManager.reload(context) } }
                    ActionRow(p, "卸载模型", "释放内存", danger = true) { confirmUnload = true }
                }
            }
            // ── 对话 ──
            item {
                Section(p, "对话") {
                    ToggleRow(p, "AI 自主调用工具", "让灵犀自行决定搜索、读改文件、画图、读屏幕、操控手机等", DiaSettings.agentTools.flow.collectAsState().value) { DiaSettings.agentTools.set(it) }
                    val steps by DiaSettings.maxToolSteps.flow.collectAsState()
                    ChoiceRow(p, "每轮工具次数", listOf("0" to "不限（做完为止）", "8" to "8", "16" to "16", "32" to "32"), steps.toString()) { DiaSettings.maxToolSteps.set(it.toInt()) }
                    ToggleRow(p, "自动批准操作", "改文件、下载、发消息、操控手机等不再弹确认（改文件前仍会自动备份）", DiaSettings.autoApprove.flow.collectAsState().value) { DiaSettings.autoApprove.set(it) }
                    ToggleRow(p, "默认开启深度思考", "新对话默认展示推理过程（Gemma 4）", DiaPrefs.thinkingDefault.collectAsState().value) { DiaPrefs.setThinkingDefault(it) }
                    ToggleRow(p, "自动朗读回复", "用中文语音读出每条回复", DiaPrefs.autoSpeak.collectAsState().value) { DiaPrefs.setAutoSpeak(it) }
                    TextPref(p, "回复语言", DiaSettings.replyLanguage, "简体中文")
                    TextPref(p, "翻译默认目标语言", DiaSettings.translateTarget, "简体中文")
                }
            }
            // ── 语音 ──
            item {
                Section(p, "语音") {
                    ToggleRow(p, "说完自动发送", "语音转成文字后直接发出", DiaSettings.voiceAutoSend.flow.collectAsState().value) { DiaSettings.voiceAutoSend.set(it) }
                    ToggleRow(p, "语音对话", "回复以文字显示并朗读，读完自动继续听你说", DiaSettings.voiceConversation.flow.collectAsState().value) { DiaSettings.voiceConversation.set(it) }
                    ToggleRow(p, "语音对话时朗读回复", "关掉则只显示文字", DiaSettings.voiceSpeakReply.flow.collectAsState().value) { DiaSettings.voiceSpeakReply.set(it) }
                    val lang by DiaSettings.voiceLanguage.flow.collectAsState()
                    ChoiceRow(p, "识别语言", listOf("zh-CN" to "普通话", "yue-Hant-HK" to "粤语", "en-US" to "英语", "ja-JP" to "日语"), lang) { DiaSettings.voiceLanguage.set(it) }
                    Hint(p, "点麦克风：系统语音识别转文字（本地 / 云端模型都能用）；长按麦克风：录音交给本机 Gemma 直接听。")
                }
            }
            // ── 记忆 ──
            item {
                Section(p, "记忆") {
                    ToggleRow(p, "启用记忆", "回答时参考关于你的记忆", DiaSettings.memoryEnabled.flow.collectAsState().value) { DiaSettings.memoryEnabled.set(it) }
                    ToggleRow(p, "自动记忆", "自动从对话中提取关键信息", DiaSettings.autoMemory.flow.collectAsState().value) { DiaSettings.autoMemory.set(it) }
                    Hint(p, "在对话页右上角菜单 →「记忆管理」查看、编辑、手写记忆。")
                }
            }
            // ── 联网 ──
            item {
                Section(p, "联网") {
                    ToggleRow(p, "允许联网", "允许 AI 联网搜索、读取网页、下载文件", DiaSettings.webEnabled.flow.collectAsState().value) { DiaSettings.webEnabled.set(it) }
                    val engine by DiaSettings.searchEngine.flow.collectAsState()
                    ChoiceRow(p, "搜索引擎", listOf("bing" to "必应（国内可用）", "duckduckgo" to "DuckDuckGo", "searxng" to "SearXNG 自建"), engine) { DiaSettings.searchEngine.set(it) }
                    if (engine == "searxng") TextPref(p, "SearXNG 地址", DiaSettings.searxngUrl, "https://searx.example.com")
                    ToggleRow(p, "深度搜索", "自动阅读前两个网页正文，回答更准（更慢）", DiaSettings.deepSearch.flow.collectAsState().value) { DiaSettings.deepSearch.set(it) }
                    Hint(p, "下载的文件保存在「下载/Dia」。无极模式 / 自动批准下不再逐次确认。")
                }
            }
            // ── 生图 ──
            item {
                Section(p, "生图 AI") {
                    val provider by DiaSettings.imageProvider.flow.collectAsState()
                    ChoiceRow(p, "生图方式", ImageGen.PROVIDERS, provider) { DiaSettings.imageProvider.set(it) }
                    when (provider) {
                        "openai" -> {
                            TextPref(p, "接口地址", DiaSettings.imageBaseUrl, "https://api.siliconflow.cn/v1")
                            TextPref(p, "API Key", DiaSettings.imageApiKey, "sk-…", secret = true)
                            TextPref(p, "模型", DiaSettings.imageModel, "Kwai-Kolors/Kolors 或 dall-e-3")
                        }
                        "sdwebui" -> {
                            TextPref(p, "SD WebUI 地址", DiaSettings.imageBaseUrl, "http://192.168.1.10:7860（启动时加 --api --listen）")
                            IntTextPref(p, "采样步数", DiaSettings.localImageSteps)
                        }
                        "local" -> {
                            Info(p, "本机模型状态", LocalImageGen.describe(context))
                            IntTextPref(p, "迭代步数（越多越清晰，越慢）", DiaSettings.localImageSteps)
                            ActionRow(p, "从文件夹导入模型", "选择包含 MediaPipe 生图模型 bins 的文件夹") { importTree.launch(null) }
                            TextPref(p, "模型下载地址（zip）", DiaSettings.localImageModelUrl, "https://…/sd15_mediapipe_bins.zip")
                            ActionRow(p, "下载模型", "体积约 1~2GB，建议在 Wi-Fi 下进行") {
                                if (DiaSettings.localImageModelUrl.value.isBlank()) imgStatus = "请先填写下载地址" else confirmDownload = true
                            }
                            if (localStatus.isNotBlank()) Hint(p, localStatus)
                        }
                        else -> {
                            TextPref(p, "模型（可选）", DiaSettings.imageModel, "flux / turbo")
                            TextPref(p, "令牌（可选）", DiaSettings.imageApiKey, "Pollinations token", secret = true)
                        }
                    }
                    val sizeV by DiaSettings.imageSize.flow.collectAsState()
                    ChoiceRow(p, "尺寸", listOf("1024x1024" to "方图", "768x1024" to "竖图", "1024x768" to "横图", "512x512" to "小图（快）"), sizeV) { DiaSettings.imageSize.set(it) }
                    ToggleRow(p, "中文提示词自动转英文", "用对话模型把描述润色成英文提示词，出图更准", DiaSettings.imagePromptTranslate.flow.collectAsState().value) { DiaSettings.imagePromptTranslate.set(it) }
                    if (imgStatus.isNotBlank()) Hint(p, imgStatus)
                }
            }
            // ── 云端模型 ──
            item {
                Section(p, "云端模型（可选）") {
                    ToggleRow(p, "使用云端模型", "开启后对话改用下面配置的在线大模型", DiaPrefs.cloudEnabled.collectAsState().value) { DiaPrefs.setCloudEnabled(it) }
                    FieldRow(p, "接口地址", DiaPrefs.cloudBaseUrl.collectAsState().value, "https://api.deepseek.com/v1") { DiaPrefs.setCloudBaseUrl(it) }
                    FieldRow(p, "模型名", DiaPrefs.cloudModel.collectAsState().value, "deepseek-chat / qwen-plus / glm-4") { DiaPrefs.setCloudModel(it) }
                    FieldRow(p, "API Key", DiaPrefs.cloudApiKey.collectAsState().value, "sk-…", secret = true) { DiaPrefs.setCloudApiKey(it) }
                    Hint(p, "支持任意 OpenAI 兼容接口：DeepSeek、通义千问(dashscope 兼容模式)、Kimi、智谱、硅基流动、Ollama 等。")
                }
            }
            // ── 悬浮气泡 ──
            item {
                Section(p, "悬浮气泡") {
                    ActionRow(p, "编辑气泡菜单与外观", "开关、改名、自定义提示词、排序", onClick = onEditBubble)
                }
            }
            // ── 文件与权限 ──
            item {
                Section(p, "文件与权限") {
                    ActionRow(
                        p, "所有文件访问",
                        if (FileManager.hasAllFilesAccess()) "已开启：灵犀可以浏览手机目录" else "开启后 AI 可以浏览下载等目录（可选）",
                    ) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                            try {
                                context.startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${context.packageName}")))
                            } catch (_: Exception) {
                                context.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                            }
                        }
                    }
                    ActionRow(p, "无障碍服务", "操控手机、屏幕引导、悬浮气泡框选需要") {
                        context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    }
                    ActionRow(p, "悬浮窗权限", "显示悬浮气泡和屏幕引导需要") {
                        context.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}")))
                    }
                    ActionRow(p, "通知读取", "让灵犀可以读取通知") {
                        context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                    }
                    ActionRow(p, "重新查看权限引导", "", onClick = onReplayOnboarding)
                }
            }
            // ── 智能家居 ──
            item {
                Section(p, "智能家居（Home Assistant）") {
                    FieldRow(p, "HA 地址", DiaPrefs.haBaseUrl.collectAsState().value, "http://192.168.1.100:8123") { DiaPrefs.setHaBaseUrl(it) }
                    FieldRow(p, "长期访问令牌", DiaPrefs.haToken.collectAsState().value, "HA → 个人资料 → 长期访问令牌", secret = true) { DiaPrefs.setHaToken(it) }
                }
            }
            item {
                Section(p, "关于") {
                    Info(p, "灵犀 Dia", "版本 4.0 · 活的 AI：自主长思 · 工具台 · 离线语音转文字 · 主题包与图标自定义 · AI 专属文件夹")
                    Info(p, "字体与素材", "标题字体：马善政毛笔楷书（SIL OFL 1.1）；背景、头像、图标为程序绘制的水墨画")
                }
            }
            item { Spacer(Modifier.height(40.dp)) }
        }
    }

    if (confirmUnload) {
        AlertDialog(
            onDismissRequest = { confirmUnload = false },
            title = { Text("卸载模型？") },
            text = { Text("将释放内存，之后需要重新选择模型。") },
            confirmButton = { TextButton(onClick = { confirmUnload = false; scope.launch { ModelManager.unload() } }) { Text("卸载", color = p.error) } },
            dismissButton = { TextButton(onClick = { confirmUnload = false }) { Text("取消") } },
        )
    }
    if (confirmDownload) {
        AlertDialog(
            onDismissRequest = { confirmDownload = false },
            title = { Text("下载本机生图模型？") },
            text = { Text("将从以下地址下载并解压到应用内：\n${DiaSettings.localImageModelUrl.value}\n\n文件较大，请确认网络环境。") },
            confirmButton = {
                TextButton(onClick = {
                    confirmDownload = false
                    scope.launch {
                        imgStatus = try {
                            val n = withContext(Dispatchers.IO) { LocalImageGen.downloadZip(context, DiaSettings.localImageModelUrl.value) }
                            "下载完成：$n 个文件"
                        } catch (e: Exception) { "下载失败：${e.message}" }
                    }
                }) { Text("下载", color = p.cinnabar) }
            },
            dismissButton = { TextButton(onClick = { confirmDownload = false }) { Text("取消") } },
        )
    }
}

@Composable
private fun Section(p: DiaPalette, title: String, content: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp)) {
        Text(title, style = MaterialTheme.typography.titleLarge, color = p.cinnabar, fontFamily = DiaSerif,
            modifier = Modifier.padding(start = 6.dp, bottom = 4.dp))
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(p.surface.copy(alpha = p.bubbleAlpha))
                .paperGrain(if (p.isDark) 0.05f else 0.09f)
                .scrollFrame(p).padding(vertical = 6.dp),
        ) { content() }
    }
}

@Composable
private fun Info(p: DiaPalette, title: String, value: String) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp)) {
        Text(title, color = p.text, style = MaterialTheme.typography.titleSmall)
        Text(value, color = p.textTertiary, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun Hint(p: DiaPalette, text: String) {
    Text(text, color = p.textTertiary, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp))
}

@Composable
private fun ActionRow(p: DiaPalette, title: String, subtitle: String, danger: Boolean = false, onClick: () -> Unit) {
    Column(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 10.dp)) {
        Text(title, color = if (danger) p.error else p.text, style = MaterialTheme.typography.titleSmall)
        if (subtitle.isNotBlank()) Text(subtitle, color = p.textTertiary, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun ChoiceRow(p: DiaPalette, title: String, options: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp)) {
        Text(title, color = p.text, style = MaterialTheme.typography.titleSmall)
        Spacer(Modifier.height(6.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for ((id, label) in options) {
                val sel = id == selected
                Text(
                    label, style = MaterialTheme.typography.labelMedium,
                    color = if (sel) p.onCinnabar else p.textSecondary,
                    modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(if (sel) p.cinnabar else p.surfaceAlt)
                        .clickable { onSelect(id) }.padding(horizontal = 10.dp, vertical = 6.dp),
                )
            }
        }
    }
}

@Composable
private fun FieldRow(p: DiaPalette, label: String, value: String, placeholder: String, secret: Boolean = false, onChange: (String) -> Unit) {
    var local by remember { mutableStateOf(value) }
    OutlinedTextField(
        value = local,
        onValueChange = { local = it; onChange(it) },
        label = { Text(label) },
        placeholder = { Text(placeholder, color = p.textTertiary) },
        singleLine = true,
        visualTransformation = if (secret) PasswordVisualTransformation() else VisualTransformation.None,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
    )
}

@Composable
private fun TextPref(p: DiaPalette, label: String, pref: StringPref, placeholder: String, secret: Boolean = false) {
    val v by pref.flow.collectAsState()
    FieldRow(p, label, v, placeholder, secret) { pref.set(it.trim()) }
}

@Composable
private fun IntTextPref(p: DiaPalette, label: String, pref: IntPref) {
    val v by pref.flow.collectAsState()
    FieldRow(p, label, v.toString(), "") { s -> s.filter { it.isDigit() }.take(3).toIntOrNull()?.let { pref.set(it) } }
}
