package com.dia.app.ui.theme

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import com.dia.app.R

/**
 * 水墨江湖配色。三套：
 *  - 宣纸山水 [PaperPalette]（默认，浅色）：宣纸底、浓墨字、朱砂印、远山松影
 *  - 江湖夜色 [InkPalette]（深色）：墨夜、明月、竹影、崖上侠客
 *  - 无极墨金 [WujiPalette]（无极模式专用）：玄墨底、金色太极与八卦
 */
@Immutable
data class DiaPalette(
    val id: String,
    val isDark: Boolean,
    /** 页面底色 */
    val background: Color,
    /** 底色渐变的第二色（做出水墨晕染感） */
    val backgroundAlt: Color,
    /** 卡片 / 气泡 */
    val surface: Color,
    val surfaceAlt: Color,
    /** 朱砂（主色） */
    val cinnabar: Color,
    /** 主色上的文字 */
    val onCinnabar: Color,
    /** 古金（描边 / 次要强调） */
    val gold: Color,
    /** 黛青（第三色） */
    val indigo: Color,
    /** 竹青（成功） */
    val bamboo: Color,
    val text: Color,
    val textSecondary: Color,
    val textTertiary: Color,
    val border: Color,
    val error: Color,
    /** 用户气泡底色 */
    val userBubble: Color,
    val onUserBubble: Color,
    /** 水墨远山 / 笔触的颜色 */
    val mountain: Color,
    /** 墨线（气泡描边、笔触） */
    val ink: Color,
    /** 整页背景画 */
    val bgRes: Int,
    /** 气泡不透明度（背景画越花，气泡越实） */
    val bubbleAlpha: Float,
)

val PaperPalette = DiaPalette(
    id = "paper",
    isDark = false,
    background = Color(0xFFF4EEDF),
    backgroundAlt = Color(0xFFEAE0CA),
    surface = Color(0xFFFBF7EC),
    surfaceAlt = Color(0xFFF0E7D2),
    cinnabar = Color(0xFFB5372B),
    onCinnabar = Color(0xFFFFF8EE),
    gold = Color(0xFF9A7B3C),
    indigo = Color(0xFF3E6E64),
    bamboo = Color(0xFF5B8A3E),
    text = Color(0xFF231E1A),
    textSecondary = Color(0xFF574B40),
    textTertiary = Color(0xFF8C7E6C),
    border = Color(0x4D6B5B45),
    error = Color(0xFFB3261E),
    userBubble = Color(0xFF2E2722),
    onUserBubble = Color(0xFFF6EFE0),
    mountain = Color(0xFF2B2520),
    ink = Color(0xFF2B2520),
    bgRes = R.drawable.bg_paper,
    bubbleAlpha = 0.90f,
)

val InkPalette = DiaPalette(
    id = "ink",
    isDark = true,
    background = Color(0xFF141210),
    backgroundAlt = Color(0xFF1E1A17),
    surface = Color(0xFF1F1B18),
    surfaceAlt = Color(0xFF2A2420),
    cinnabar = Color(0xFFD9503C),
    onCinnabar = Color(0xFFFFF6EA),
    gold = Color(0xFFCFA660),
    indigo = Color(0xFF6FA89A),
    bamboo = Color(0xFF86B26E),
    text = Color(0xFFEDE5D3),
    textSecondary = Color(0xFFB3A78F),
    textTertiary = Color(0xFF7E7362),
    border = Color(0x40CFA660),
    error = Color(0xFFE5534B),
    userBubble = Color(0xFF6E2A20),
    onUserBubble = Color(0xFFFFF1E2),
    mountain = Color(0xFFEDE5D3),
    ink = Color(0xFFD8CDB6),
    bgRes = R.drawable.bg_night,
    bubbleAlpha = 0.88f,
)

val WujiPalette = DiaPalette(
    id = "wuji",
    isDark = true,
    background = Color(0xFF0E0C0B),
    backgroundAlt = Color(0xFF1A1612),
    surface = Color(0xFF1A1714),
    surfaceAlt = Color(0xFF262019),
    cinnabar = Color(0xFFD4A85A),
    onCinnabar = Color(0xFF1A140C),
    gold = Color(0xFFE8C77E),
    indigo = Color(0xFFB48F4F),
    bamboo = Color(0xFFC9B26A),
    text = Color(0xFFF1E6CC),
    textSecondary = Color(0xFFC2B08A),
    textTertiary = Color(0xFF8A7A5C),
    border = Color(0x55D4A85A),
    error = Color(0xFFE5654B),
    userBubble = Color(0xFF4A3920),
    onUserBubble = Color(0xFFFFF0D2),
    mountain = Color(0xFFE8C77E),
    ink = Color(0xFFD4A85A),
    bgRes = R.drawable.bg_wuji,
    bubbleAlpha = 0.86f,
)

fun paletteFor(mode: String): DiaPalette = when (mode) {
    "ink" -> InkPalette
    "wuji" -> WujiPalette
    "paper" -> PaperPalette
    else -> if (ThemeManager.isReady) ThemeManager.resolve(mode).palette else PaperPalette
}

/** 主题的中文名。 */
fun themeLabel(mode: String): String = when (mode) {
    "ink" -> "江湖夜色"
    "wuji" -> "无极墨金"
    "paper" -> "宣纸山水"
    else -> if (ThemeManager.isReady) ThemeManager.find(mode)?.name ?: mode else mode
}

val LocalDiaPalette = staticCompositionLocalOf { PaperPalette }

/** 在 Composable 中取当前配色：`val p = DiaPal.current` */
object DiaPal {
    val current: DiaPalette
        @Composable
        @ReadOnlyComposable
        get() = LocalDiaPalette.current
}
