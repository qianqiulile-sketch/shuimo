package com.dia.app.ui.theme

import android.content.Context
import android.graphics.Typeface
import android.net.Uri
import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import com.dia.app.R
import com.dia.app.agent.ToolHost
import com.dia.app.agent.ToolOutcome
import com.dia.app.files.AiFolder
import com.dia.app.files.FileManager
import com.dia.app.llm.LlmGateway
import com.dia.app.prefs.DiaSettings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** 标题 / 书法字体（随主题切换；所有用 DiaBrush 的地方自动跟着变）。 */
object ThemeFonts {
    val default: FontFamily = FontFamily(Font(R.font.mashanzheng, FontWeight.Normal))
    var brush: FontFamily by mutableStateOf(default)
}

/**
 * 主题管理：内置主题 + 导入的主题包 + 每个主题上的个人修改（换图标、换颜色、换图片、换字体）。
 *
 * - 主题包（.lxtheme / .zip）：theme.json + images/ + icons/ + fonts/，导入后解压到 filesDir/themes/<id>/
 * - 个人修改存在 filesDir/themes/_user/<主题id>/（overrides.json + 用到的图片），可以一键恢复，也可以「另存为新主题」导出分享
 * - App 自带「水墨太极」主题包（assets/themes/taiji.lxtheme），首次启动自动安装
 */
object ThemeManager {

    private const val TAG = "ThemeManager"

    private lateinit var appCtx: Context
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private val _installed = MutableStateFlow<List<ThemePack>>(emptyList())
    /** 导入的主题包（不含内置）。 */
    val installed: StateFlow<List<ThemePack>> = _installed.asStateFlow()

    data class Overrides(
        val colors: Map<String, String> = emptyMap(),
        val icons: Map<String, IconSpec> = emptyMap(),
        val images: Map<String, String> = emptyMap(),
        val font: String? = null,
    ) {
        val isEmpty: Boolean get() = colors.isEmpty() && icons.isEmpty() && images.isEmpty() && font == null
        val count: Int get() = colors.size + icons.size + images.size + (if (font != null) 1 else 0)
    }

    private val _overrides = MutableStateFlow<Map<String, Overrides>>(emptyMap())
    val overrides: StateFlow<Map<String, Overrides>> = _overrides.asStateFlow()

    private val _current = MutableStateFlow(BuiltinThemes.PAPER)
    /** 当前生效的主题（已叠加个人修改）。 */
    val current: StateFlow<ThemePack> = _current.asStateFlow()

    val isReady: Boolean get() = ::appCtx.isInitialized

    private fun themesDir(): File = File(appCtx.filesDir, "themes").apply { mkdirs() }
    private fun userDir(themeId: String): File = File(File(themesDir(), "_user"), themeId).apply { mkdirs() }

    fun init(context: Context) {
        if (::appCtx.isInitialized) return
        appCtx = context.applicationContext
        reload()
        // 自带主题包（水墨太极）在后台安装 / 升级，装好后刷新列表
        scope.launch(Dispatchers.IO) {
            val changed = try { installBundled() } catch (e: Exception) { Log.w(TAG, "bundled: ${e.message}"); false }
            if (changed) withContext(Dispatchers.Main) { reload() }
        }
        scope.launch {
            combine(DiaSettings.themeMode.flow, DiaSettings.wujiMode.flow, DiaSettings.wujiTheme.flow, _installed, _overrides) { mode, wuji, wujiTheme, _, _ ->
                resolve(if (wuji) wujiTheme else mode)
            }.collect { pack ->
                _current.value = pack
                ThemeFonts.brush = fontFor(pack)
            }
        }
    }

    /** 所有可选的主题（内置 + 已导入）。 */
    fun all(): List<ThemePack> = BuiltinThemes.ALL + _installed.value

    fun find(id: String): ThemePack? = all().firstOrNull { it.id == id }

    fun label(id: String): String = find(id)?.name ?: themeLabel(id)

    /** 主题 + 个人修改。找不到时退回宣纸山水。 */
    fun resolve(id: String): ThemePack {
        val base = find(id) ?: BuiltinThemes.PAPER
        val o = _overrides.value[base.id] ?: return base
        var pal = base.palette
        for ((k, v) in o.colors) ThemeJson.parseColor(v)?.let { pal = ThemeJson.withColor(pal, k, it) }
        return base.copy(
            palette = pal,
            icons = base.icons + o.icons,
            images = base.images + o.images,
            fontPath = o.font ?: base.fontPath,
        )
    }

    private val fontCache = HashMap<String, FontFamily>()

    private fun fontFor(pack: ThemePack): FontFamily {
        val p = pack.fontPath ?: return ThemeFonts.default
        fontCache[p]?.let { return it }
        return try {
            FontFamily(Typeface.createFromFile(p)).also { fontCache[p] = it }
        } catch (e: Exception) {
            Log.w(TAG, "font: ${e.message}")
            ThemeFonts.default
        }
    }

    fun apply(id: String) {
        if (find(id) == null) return
        if (DiaSettings.wujiMode.value) DiaSettings.wujiTheme.set(id) else DiaSettings.themeMode.set(id)
    }

    /** 当前正在编辑的主题 id（无极模式下是无极主题）。 */
    fun currentId(): String = if (DiaSettings.wujiMode.value) DiaSettings.wujiTheme.value else DiaSettings.themeMode.value

    // ───────── 读取 / 安装 ─────────

    fun reload() {
        val list = ArrayList<ThemePack>()
        for (d in themesDir().listFiles().orEmpty()) {
            if (!d.isDirectory || d.name.startsWith("_") || d.name.startsWith(".")) continue
            ThemeJson.load(d)?.let { list.add(it) }
        }
        _installed.value = list.sortedBy { it.name }
        val ov = HashMap<String, Overrides>()
        File(themesDir(), "_user").listFiles().orEmpty().forEach { d ->
            readOverrides(d)?.let { if (!it.isEmpty) ov[d.name] = it }
        }
        _overrides.value = ov
    }

    /** 安装 App 自带的主题包（assets/themes 里的 .lxtheme），已安装的旧版本会被更新。返回是否有变化。 */
    private fun installBundled(): Boolean {
        val names = appCtx.assets.list("themes").orEmpty().filter { it.endsWith(".lxtheme") || it.endsWith(".zip") }
        var changed = false
        for (n in names) {
            try {
                val probe = appCtx.assets.open("themes/$n").use { readThemeJson(it) }
                val id = probe?.optString("id").orEmpty()
                val ver = probe?.optInt("version", 1) ?: 1
                if (id.isBlank()) continue
                val existing = File(themesDir(), id)
                val oldVer = ThemeJson.load(existing)?.version ?: -1
                if (oldVer < ver) {
                    existing.deleteRecursively()
                    appCtx.assets.open("themes/$n").use { unzipTheme(it, id) }
                    changed = true
                }
            } catch (e: Exception) {
                Log.w(TAG, "install $n: ${e.message}")
            }
        }
        return changed
    }

    private fun readThemeJson(input: java.io.InputStream): JSONObject? {
        ZipInputStream(input.buffered()).use { zis ->
            while (true) {
                val e = zis.nextEntry ?: break
                if (e.name.substringAfterLast('/') == "theme.json") {
                    return try { JSONObject(zis.readBytes().toString(Charsets.UTF_8)) } catch (_: Exception) { null }
                }
                zis.closeEntry()
            }
        }
        return null
    }

    private fun readThemeJsonFromZip(f: File): JSONObject? = f.inputStream().use { readThemeJson(it) }

    /** 解压主题包到 themes/<id>/。zip 里可以有一层顶层目录。 */
    private fun unzipTheme(input: java.io.InputStream, id: String): File {
        val dst = File(themesDir(), id)
        val staging = File(themesDir(), ".staging").apply { deleteRecursively(); mkdirs() }
        ZipInputStream(input.buffered()).use { zis ->
            while (true) {
                val e = zis.nextEntry ?: break
                val out = File(staging, e.name.replace('\\', '/').trimStart('/')).canonicalFile
                if (!out.path.startsWith(staging.canonicalPath)) { zis.closeEntry(); continue }
                if (e.isDirectory) out.mkdirs() else {
                    out.parentFile?.mkdirs()
                    FileOutputStream(out).use { zis.copyTo(it) }
                }
                zis.closeEntry()
            }
        }
        val root = staging.walkTopDown().firstOrNull { it.isFile && it.name == "theme.json" }?.parentFile
            ?: run { staging.deleteRecursively(); throw IllegalArgumentException("压缩包里没有 theme.json，不是灵犀主题包") }
        dst.deleteRecursively()
        if (!root.renameTo(dst)) root.copyRecursively(dst, overwrite = true)
        staging.deleteRecursively()
        // 统一 id
        val tj = File(dst, "theme.json")
        try {
            val o = JSONObject(tj.readText())
            if (o.optString("id") != id) tj.writeText(o.put("id", id).toString(2))
        } catch (_: Exception) { }
        return dst
    }

    /** 导入主题包（.lxtheme / .zip）。返回导入后的主题。 */
    suspend fun importZip(uri: Uri): ThemePack = withContext(Dispatchers.IO) {
        val tmp = File(appCtx.cacheDir, "import_theme.zip")
        appCtx.contentResolver.openInputStream(uri)?.use { input -> FileOutputStream(tmp).use { input.copyTo(it) } }
            ?: throw IllegalStateException("无法打开文件")
        try {
            val probe = readThemeJsonFromZip(tmp) ?: throw IllegalArgumentException("压缩包里没有 theme.json，不是灵犀主题包")
            var id = probe.optString("id").ifBlank { "theme_${System.currentTimeMillis() / 1000}" }
                .replace(Regex("[^A-Za-z0-9_-]"), "_").lowercase()
            if (BuiltinThemes.ALL.any { it.id == id }) id += "_x"
            val dir = unzipTheme(tmp.inputStream(), id)
            val pack = ThemeJson.load(dir) ?: throw IllegalArgumentException("theme.json 格式不对")
            withContext(Dispatchers.Main) { reload() }
            pack
        } finally {
            tmp.delete()
        }
    }

    fun delete(id: String) {
        if (BuiltinThemes.ALL.any { it.id == id }) return
        File(themesDir(), id).deleteRecursively()
        File(File(themesDir(), "_user"), id).deleteRecursively()
        if (DiaSettings.themeMode.value == id) DiaSettings.themeMode.set("paper")
        if (DiaSettings.wujiTheme.value == id) DiaSettings.wujiTheme.set("wuji")
        reload()
    }

    // ───────── 个人修改（图标 / 颜色 / 图片 / 字体） ─────────

    private fun readOverrides(d: File): Overrides? {
        val f = File(d, "overrides.json")
        if (!f.isFile) return null
        return try {
            val o = JSONObject(f.readText())
            val colors = HashMap<String, String>()
            o.optJSONObject("colors")?.let { c -> c.keys().forEach { k -> colors[k] = c.optString(k) } }
            val icons = HashMap<String, IconSpec>()
            o.optJSONObject("icons")?.let { c -> c.keys().forEach { k -> ThemeJson.parseIcon(c.opt(k), d)?.let { icons[k] = it } } }
            val images = HashMap<String, String>()
            o.optJSONObject("images")?.let { c -> c.keys().forEach { k -> File(c.optString(k)).takeIf { it.isFile }?.let { images[k] = it.absolutePath } } }
            Overrides(colors, icons, images, o.optString("font").takeIf { it.isNotBlank() && File(it).isFile })
        } catch (_: Exception) {
            null
        }
    }

    private fun writeOverrides(themeId: String, o: Overrides) {
        val d = userDir(themeId)
        val j = JSONObject()
        j.put("colors", JSONObject().also { c -> o.colors.forEach { (k, v) -> c.put(k, v) } })
        j.put("icons", JSONObject().also { c -> o.icons.forEach { (k, v) -> c.put(k, ThemeJson.iconToJson(v)) } })
        j.put("images", JSONObject().also { c -> o.images.forEach { (k, v) -> c.put(k, v) } })
        o.font?.let { j.put("font", it) }
        File(d, "overrides.json").writeText(j.toString(2))
        _overrides.value = _overrides.value + (themeId to o)
    }

    private fun ov(themeId: String) = _overrides.value[themeId] ?: Overrides()

    /** 把 uri 指向的文件复制进个人修改目录，返回路径。 */
    private fun copyIn(themeId: String, uri: Uri, name: String): String {
        val d = userDir(themeId)
        val ext = (FileManager.guessMime(uri.lastPathSegment ?: "").substringAfter('/', "png")).let { if (it.length in 2..5) it else "png" }
        val f = File(d, "${name}_${System.currentTimeMillis()}.$ext")
        appCtx.contentResolver.openInputStream(uri)?.use { input -> FileOutputStream(f).use { input.copyTo(it) } }
            ?: throw IllegalStateException("无法读取所选文件")
        return f.absolutePath
    }

    private fun copyFileIn(themeId: String, src: File, name: String): String {
        val f = File(userDir(themeId), "${name}_${System.currentTimeMillis()}.${src.extension.ifBlank { "png" }}")
        src.copyTo(f, overwrite = true)
        return f.absolutePath
    }

    fun setIconText(themeId: String, slot: String, text: String, color: Color? = null) {
        val t = text.trim()
        if (t.isEmpty()) { resetIcon(themeId, slot); return }
        val cur = ov(themeId)
        writeOverrides(themeId, cur.copy(icons = cur.icons + (slot to IconSpec.Txt(t.take(4), color, brush = t.any { it.code in 0x3400..0x9fff }))))
    }

    suspend fun setIconImage(themeId: String, slot: String, uri: Uri, tint: Boolean = false) = withContext(Dispatchers.IO) {
        val path = copyIn(themeId, uri, "icon_" + slot.replace('.', '_'))
        withContext(Dispatchers.Main) {
            val cur = ov(themeId)
            writeOverrides(themeId, cur.copy(icons = cur.icons + (slot to IconSpec.Img(path, tint))))
        }
    }

    fun resetIcon(themeId: String, slot: String) {
        val cur = ov(themeId)
        writeOverrides(themeId, cur.copy(icons = cur.icons - slot))
    }

    fun setColor(themeId: String, key: String, hex: String?) {
        val cur = ov(themeId)
        val c = hex?.let { ThemeJson.parseColor(it) }
        writeOverrides(themeId, cur.copy(colors = if (c == null) cur.colors - key else cur.colors + (key to ThemeJson.hex(c))))
    }

    suspend fun setImage(themeId: String, key: String, uri: Uri?) = withContext(Dispatchers.IO) {
        val path = uri?.let { copyIn(themeId, it, "img_$key") }
        withContext(Dispatchers.Main) {
            val cur = ov(themeId)
            writeOverrides(themeId, cur.copy(images = if (path == null) cur.images - key else cur.images + (key to path)))
        }
    }

    suspend fun setFont(themeId: String, uri: Uri?) = withContext(Dispatchers.IO) {
        val path = uri?.let {
            val f = File(userDir(themeId), "font_${System.currentTimeMillis()}.ttf")
            appCtx.contentResolver.openInputStream(it)?.use { input -> FileOutputStream(f).use { o -> input.copyTo(o) } }
            // 验证能不能用
            try { Typeface.createFromFile(f) } catch (e: Exception) { f.delete(); throw IllegalArgumentException("字体文件无法使用") }
            f.absolutePath
        }
        withContext(Dispatchers.Main) {
            val cur = ov(themeId)
            writeOverrides(themeId, cur.copy(font = path))
        }
    }

    fun resetAll(themeId: String) {
        File(File(themesDir(), "_user"), themeId).deleteRecursively()
        _overrides.value = _overrides.value - themeId
    }

    // ───────── 导出 / 另存 ─────────

    /** 把主题（含个人修改）写成一个独立的主题包目录。 */
    private fun materialize(pack: ThemePack, dst: File, newId: String, newName: String) {
        dst.deleteRecursively()
        File(dst, "images").mkdirs()
        File(dst, "icons").mkdirs()
        val j = JSONObject()
        j.put("format", "lingxi-theme").put("version", 1).put("id", newId).put("name", newName)
            .put("author", pack.author).put("description", pack.description).put("dark", pack.palette.isDark)
            .put("bubbleAlpha", pack.palette.bubbleAlpha.toDouble()).put("heroTint", pack.heroTint).put("dividerTint", pack.dividerTint)
        j.put("colors", JSONObject().also { c -> ThemeJson.COLOR_KEYS.forEach { k -> c.put(k, ThemeJson.hex(ThemeJson.colorOf(pack.palette, k))) } })
        val im = JSONObject()
        for ((k, path) in pack.images) {
            val src = File(path)
            if (!src.isFile) continue
            val name = "images/$k.${src.extension.ifBlank { "png" }}"
            src.copyTo(File(dst, name), overwrite = true)
            im.put(k, name)
        }
        j.put("images", im)
        val ic = JSONObject()
        for ((slot, spec) in pack.icons) {
            when (spec) {
                is IconSpec.Img -> {
                    val src = File(spec.path)
                    if (!src.isFile) continue
                    val name = "icons/${slot.replace('.', '_')}.${src.extension.ifBlank { "png" }}"
                    src.copyTo(File(dst, name), overwrite = true)
                    ic.put(slot, ThemeJson.iconToJson(spec, name))
                }
                is IconSpec.Txt -> ic.put(slot, ThemeJson.iconToJson(spec))
            }
        }
        j.put("icons", ic)
        pack.fontPath?.let { fp ->
            val src = File(fp)
            if (src.isFile) {
                File(dst, "fonts").mkdirs()
                src.copyTo(File(dst, "fonts/title.${src.extension.ifBlank { "ttf" }}"), overwrite = true)
                j.put("font", "fonts/title.${src.extension.ifBlank { "ttf" }}")
            }
        }
        File(dst, "theme.json").writeText(j.toString(2))
    }

    /** 把当前主题（含修改）另存为一个新主题包，并切换过去。 */
    suspend fun saveAs(themeId: String, name: String): ThemePack = withContext(Dispatchers.IO) {
        val pack = resolve(themeId)
        val id = "my_" + java.lang.Long.toString(System.currentTimeMillis(), 36)
        val dir = File(themesDir(), id)
        materialize(pack, dir, id, name.ifBlank { pack.name + "（我的）" })
        withContext(Dispatchers.Main) {
            reload()
            apply(id)
        }
        ThemeJson.load(dir) ?: pack
    }

    /** 导出为 .lxtheme 文件（放在 灵犀AI/主题/），返回文件，可分享给别人导入。 */
    suspend fun export(themeId: String): File = withContext(Dispatchers.IO) {
        val pack = resolve(themeId)
        val tmp = File(appCtx.cacheDir, "export_theme").apply { deleteRecursively() }
        val id = if (pack.builtIn) pack.id + "_copy" else pack.id
        materialize(pack, tmp, id, pack.name)
        val out = AiFolder.unique(AiFolder.dir("主题"), pack.name.replace(Regex("[\\\\/:*?\"<>|]"), "_") + ".lxtheme")
        ZipOutputStream(FileOutputStream(out)).use { zos ->
            tmp.walkTopDown().filter { it.isFile }.forEach { f ->
                zos.putNextEntry(ZipEntry(f.relativeTo(tmp).path.replace('\\', '/')))
                f.inputStream().use { it.copyTo(zos) }
                zos.closeEntry()
            }
        }
        tmp.deleteRecursively()
        AiFolder.touch()
        out
    }

    // ───────── AI 生成主题 ─────────

    /** 按描述让 AI 生成一个主题（配色 + 可选的背景画），安装并切换。 */
    suspend fun generate(prompt: String, host: ToolHost?, withImage: Boolean = true): ThemePack {
        host?.progress("AI 正在调配色…")
        val out = LlmGateway.complete(
            system = "你是资深 UI 配色师，擅长中国传统色。只输出 JSON。",
            prompt = "为一个中文 AI 助手 App 设计主题：「$prompt」。\n" +
                "输出 JSON：{\"name\":\"主题名（4 字以内）\",\"dark\":false,\"description\":\"一句话\",\"colors\":{" +
                ThemeJson.COLOR_KEYS.joinToString(",") { "\"$it\":\"#RRGGBB\"" } + "},\"background_prompt\":\"背景画面描述\"}\n" +
                "要求：文字与底色对比清楚；cinnabar 是主色（按钮、强调），onCinnabar 是主色上的文字；userBubble 是用户气泡底色；ink 是描边墨线颜色。只输出 JSON。",
            temperature = 0.7,
            timeoutMs = 120_000,
        )
        val json = com.dia.app.agent.ToolCallParser.firstJsonObject(out) ?: throw IllegalStateException("AI 没有给出配色")
        val o = JSONObject(json)
        val name = o.optString("name").ifBlank { prompt.take(6) }
        val id = "ai_" + java.lang.Long.toString(System.currentTimeMillis(), 36)
        val dir = File(themesDir(), id).apply { mkdirs() }
        val theme = JSONObject()
            .put("format", "lingxi-theme").put("version", 1).put("id", id).put("name", name)
            .put("author", "灵犀 AI").put("description", o.optString("description").ifBlank { prompt })
            .put("dark", o.optBoolean("dark", false))
            .put("colors", o.optJSONObject("colors") ?: JSONObject())
        if (withImage) {
            try {
                host?.progress("AI 正在画背景…")
                val bgPrompt = o.optString("background_prompt").ifBlank { prompt } + "，中国水墨画风格，留白，竖版手机壁纸，无文字"
                val r = withContext(Dispatchers.IO) { com.dia.app.imagegen.ImageGen.generate(bgPrompt, "720x1280") }
                File(dir, "images").mkdirs()
                File(r.path).copyTo(File(dir, "images/background.png"), overwrite = true)
                theme.put("images", JSONObject().put("background", "images/background.png"))
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.w(TAG, "theme bg: ${e.message}")
            }
        }
        withContext(Dispatchers.IO) { File(dir, "theme.json").writeText(theme.toString(2)) }
        reload()
        apply(id)
        return find(id) ?: BuiltinThemes.PAPER
    }

    // ───────── 给 AI 用的 theme 工具 ─────────

    private fun matchTheme(key: String): ThemePack? {
        val k = key.trim().lowercase()
        if (k.isEmpty()) return null
        all().firstOrNull { it.id.lowercase() == k || it.name == key.trim() }?.let { return it }
        return when {
            k.contains("太极") || k.contains("taiji") -> find("taiji")
            k.contains("无极") || k.contains("金") || k.contains("wuji") -> find("wuji")
            k.contains("夜") || k.contains("江湖") || k.contains("深") || k.contains("dark") || k.contains("ink") -> find("ink")
            k.contains("宣纸") || k.contains("浅") || k.contains("山水") || k.contains("paper") || k.contains("light") -> find("paper")
            else -> all().firstOrNull { it.name.contains(key.trim()) || key.contains(it.name) }
        }
    }

    suspend fun toolAction(args: JSONObject, host: ToolHost): ToolOutcome {
        if (!isReady) init(host.context)
        val action = args.optString("action").trim().lowercase().ifBlank {
            when {
                args.has("slot") -> "icon"
                args.has("prompt") -> "create"
                else -> "list"
            }
        }
        val themeId = currentId()
        return when (action) {
            "list" -> ToolOutcome(
                "可用主题：\n" + all().joinToString("\n") { "- ${it.id}：${it.name}${if (it.id == themeId) "（当前）" else ""} —— ${it.description}" } +
                    "\n\n可换图标的位置（slot）：" + IconSlots.ALL.take(60).joinToString("、") { "${it.key}(${it.label})" },
            )
            "apply", "switch", "use" -> {
                val key = args.optString("id").ifBlank { args.optString("name") }.ifBlank { args.optString("value") }
                val p = matchTheme(key) ?: return ToolOutcome("没有主题「$key」。可用：${all().joinToString("、") { "${it.id}(${it.name})" }}", ok = false)
                apply(p.id)
                ToolOutcome("已切换为「${p.name}」主题。", shownToUser = true)
            }
            "create", "generate" -> {
                val prompt = args.optString("prompt").ifBlank { args.optString("value") }.ifBlank { return ToolOutcome("缺少主题描述 prompt", ok = false) }
                val p = generate(prompt, host, withImage = args.optBoolean("image", true))
                ToolOutcome("已生成并切换到新主题「${p.name}」（${p.description}）。可以在「主题与图标」页继续修改或导出。", shownToUser = true)
            }
            "icon", "set_icon" -> {
                val slot = args.optString("slot").trim()
                val value = args.optString("value").ifBlank { args.optString("text") }.trim()
                if (IconSlots.find(slot) == null) return ToolOutcome("没有图标位「$slot」。可用：" + IconSlots.ALL.joinToString("、") { it.key }, ok = false)
                if (value.isBlank() || value == "reset" || value == "默认") {
                    resetIcon(themeId, slot); return ToolOutcome("已把「${IconSlots.find(slot)?.label}」恢复默认图标。")
                }
                val ref = FileManager.find(value)
                if (ref != null && ref.mime.startsWith("image/")) {
                    val src = File(Uri.parse(ref.uri).path ?: "")
                    val path = withContext(Dispatchers.IO) {
                        if (src.isFile) copyFileIn(themeId, src, "icon_" + slot.replace('.', '_'))
                        else copyIn(themeId, Uri.parse(ref.uri), "icon_" + slot.replace('.', '_'))
                    }
                    val cur = ov(themeId)
                    writeOverrides(themeId, cur.copy(icons = cur.icons + (slot to IconSpec.Img(path, args.optBoolean("tint", false)))))
                    ToolOutcome("已把「${IconSlots.find(slot)?.label}」换成图片《${ref.name}》。")
                } else {
                    setIconText(themeId, slot, value, ThemeJson.parseColor(args.optString("color")))
                    ToolOutcome("已把「${IconSlots.find(slot)?.label}」换成「${value.take(4)}」。")
                }
            }
            "color", "set_color" -> {
                val key = args.optString("key").ifBlank { args.optString("slot") }.trim()
                if (key !in ThemeJson.COLOR_KEYS) return ToolOutcome("颜色名不对。可用：" + ThemeJson.COLOR_KEYS.joinToString("、") { "$it(${ThemeJson.COLOR_LABELS[it]})" }, ok = false)
                val v = args.optString("value").trim()
                if (v.isBlank() || v == "reset") { setColor(themeId, key, null); return ToolOutcome("已恢复「${ThemeJson.COLOR_LABELS[key]}」默认颜色。") }
                ThemeJson.parseColor(v) ?: return ToolOutcome("颜色格式不对，用 #RRGGBB", ok = false)
                setColor(themeId, key, v)
                ToolOutcome("已把「${ThemeJson.COLOR_LABELS[key]}」改成 $v。")
            }
            "image", "set_image" -> {
                val key = args.optString("key").ifBlank { args.optString("slot") }.ifBlank { "background" }
                if (key !in ThemeJson.IMAGE_KEYS) return ToolOutcome("图片位不对。可用：" + ThemeJson.IMAGE_KEYS.joinToString("、"), ok = false)
                val v = args.optString("value").trim()
                if (v.isBlank() || v == "reset") { setImage(themeId, key, null); return ToolOutcome("已恢复「${ThemeJson.IMAGE_LABELS[key]}」。") }
                val ref = FileManager.find(v) ?: return ToolOutcome("找不到图片「$v」（先让用户发一张图片或用 generate_image 生成）", ok = false)
                setImage(themeId, key, Uri.parse(ref.uri))
                ToolOutcome("已把「${ThemeJson.IMAGE_LABELS[key]}」换成《${ref.name}》。")
            }
            "export", "share" -> {
                val f = export(themeId)
                ToolOutcome("已导出主题包：灵犀AI/${AiFolder.rel(f)}。别人在「主题与图标 → 导入」里选这个文件即可使用。")
            }
            "reset" -> { resetAll(themeId); ToolOutcome("已清除当前主题上的所有个人修改。") }
            else -> ToolOutcome("不支持的操作「$action」。可用：list / apply / create / icon / color / image / export / reset", ok = false)
        }
    }

    /** 给工具卡片 / 设置用：当前主题的说明。 */
    fun describeCurrent(): String {
        val p = _current.value
        val n = _overrides.value[p.id]?.count ?: 0
        return "${p.name}${if (n > 0) "（$n 处个人修改）" else ""}"
    }
}
