package com.dia.app.ui.theme

import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import org.json.JSONObject
import java.io.File
import java.util.Locale

/**
 * 一个图标位的样式：图片，或者文字 / emoji（用毛笔字体写出来）。
 */
sealed class IconSpec {
    /** @param tint true 时按当前配色着色（适合单色墨稿图标） */
    data class Img(val path: String, val tint: Boolean = false) : IconSpec()
    /** @param color null 时用界面默认颜色 */
    data class Txt(val text: String, val color: Color? = null, val brush: Boolean = true) : IconSpec()
}

/**
 * 主题包：配色 + 图片（背景、头像、插画、笔触、纹理）+ 图标 + 标题字体。
 *
 * 内置主题（宣纸山水 / 江湖夜色 / 无极墨金）由代码定义，素材在 res 里；
 * 导入的主题包（.lxtheme，其实就是 zip）解压在 `filesDir/themes/<id>/`，格式见 `themes/主题包格式.md`。
 */
data class ThemePack(
    val id: String,
    val name: String,
    val author: String = "",
    val description: String = "",
    val version: Int = 1,
    val builtIn: Boolean = false,
    /** 主题包目录（导入的主题） */
    val dir: String? = null,
    val palette: DiaPalette,
    /** background / page / avatar / hero / divider / grain → 图片绝对路径 */
    val images: Map<String, String> = emptyMap(),
    /** 图标位 → 样式（见 [IconSlots]） */
    val icons: Map<String, IconSpec> = emptyMap(),
    /** 标题 / 书法字体（ttf / otf）路径 */
    val fontPath: String? = null,
    /** hero、divider 图片是否按配色着色（单色墨稿） */
    val heroTint: Boolean = true,
    val dividerTint: Boolean = true,
)

val LocalThemePack = staticCompositionLocalOf { BuiltinThemes.PAPER }

object BuiltinThemes {
    val PAPER = ThemePack("paper", "宣纸山水", "灵犀", "浅色 · 宣纸底、浓墨字、朱砂印、远山松影", builtIn = true, palette = PaperPalette)
    val INK = ThemePack("ink", "江湖夜色", "灵犀", "深色 · 墨夜、明月、竹影、崖上侠客", builtIn = true, palette = InkPalette)
    val WUJI = ThemePack("wuji", "无极墨金", "灵犀", "无极模式 · 玄墨底、金色太极与八卦", builtIn = true, palette = WujiPalette)
    val ALL = listOf(PAPER, INK, WUJI)
}

/** 主题包 JSON 的读写。 */
object ThemeJson {

    /** 配色字段（JSON 里的键名与 [DiaPalette] 属性同名）。 */
    val COLOR_KEYS = listOf(
        "background", "backgroundAlt", "surface", "surfaceAlt", "cinnabar", "onCinnabar", "gold", "indigo", "bamboo",
        "text", "textSecondary", "textTertiary", "border", "error", "userBubble", "onUserBubble", "mountain", "ink",
    )

    val COLOR_LABELS = mapOf(
        "background" to "页面底色", "backgroundAlt" to "底色（晕染）", "surface" to "气泡 / 卡片", "surfaceAlt" to "次级卡片",
        "cinnabar" to "主色（朱砂）", "onCinnabar" to "主色上的字", "gold" to "强调色（古金）", "indigo" to "第三色（黛青）",
        "bamboo" to "成功色（竹青）", "text" to "正文", "textSecondary" to "次要文字", "textTertiary" to "提示文字",
        "border" to "边框", "error" to "错误", "userBubble" to "我的气泡", "onUserBubble" to "我的气泡文字",
        "mountain" to "远山", "ink" to "墨线 / 描边",
    )

    val IMAGE_KEYS = listOf("background", "page", "avatar", "hero", "divider", "grain")
    val IMAGE_LABELS = mapOf(
        "background" to "对话背景", "page" to "功能页背景", "avatar" to "灵犀头像",
        "hero" to "首页插画", "divider" to "分隔笔触", "grain" to "纸张纹理",
    )

    fun parseColor(s: String?): Color? {
        if (s.isNullOrBlank()) return null
        val t = s.trim().let { if (it.startsWith("#")) it else "#$it" }
        return try { Color(android.graphics.Color.parseColor(t)) } catch (_: Exception) { null }
    }

    fun hex(c: Color): String = String.format(Locale.US, "#%08X", c.toArgb())

    fun colorOf(p: DiaPalette, key: String): Color = when (key) {
        "background" -> p.background; "backgroundAlt" -> p.backgroundAlt; "surface" -> p.surface; "surfaceAlt" -> p.surfaceAlt
        "cinnabar" -> p.cinnabar; "onCinnabar" -> p.onCinnabar; "gold" -> p.gold; "indigo" -> p.indigo; "bamboo" -> p.bamboo
        "text" -> p.text; "textSecondary" -> p.textSecondary; "textTertiary" -> p.textTertiary; "border" -> p.border
        "error" -> p.error; "userBubble" -> p.userBubble; "onUserBubble" -> p.onUserBubble; "mountain" -> p.mountain
        else -> p.ink
    }

    fun withColor(p: DiaPalette, key: String, c: Color): DiaPalette = when (key) {
        "background" -> p.copy(background = c); "backgroundAlt" -> p.copy(backgroundAlt = c); "surface" -> p.copy(surface = c)
        "surfaceAlt" -> p.copy(surfaceAlt = c); "cinnabar" -> p.copy(cinnabar = c); "onCinnabar" -> p.copy(onCinnabar = c)
        "gold" -> p.copy(gold = c); "indigo" -> p.copy(indigo = c); "bamboo" -> p.copy(bamboo = c); "text" -> p.copy(text = c)
        "textSecondary" -> p.copy(textSecondary = c); "textTertiary" -> p.copy(textTertiary = c); "border" -> p.copy(border = c)
        "error" -> p.copy(error = c); "userBubble" -> p.copy(userBubble = c); "onUserBubble" -> p.copy(onUserBubble = c)
        "mountain" -> p.copy(mountain = c); "ink" -> p.copy(ink = c)
        else -> p
    }

    /** 解析一个图标位的写法："icons/send.png"、"text:发"、{"image":"…","tint":true}、{"text":"发","color":"#…"}。 */
    fun parseIcon(v: Any?, base: File?): IconSpec? {
        fun file(rel: String): String? {
            if (rel.isBlank()) return null
            val f = if (rel.startsWith("/")) File(rel) else if (base != null) File(base, rel) else return null
            return if (f.isFile) f.absolutePath else null
        }
        return when (v) {
            is String -> when {
                v.startsWith("text:") -> IconSpec.Txt(v.removePrefix("text:"))
                v.startsWith("emoji:") -> IconSpec.Txt(v.removePrefix("emoji:"), brush = false)
                else -> file(v)?.let { IconSpec.Img(it) }
            }
            is JSONObject -> when {
                v.has("image") -> file(v.optString("image"))?.let { IconSpec.Img(it, v.optBoolean("tint", false)) }
                v.has("text") -> IconSpec.Txt(v.optString("text"), parseColor(v.optString("color")), v.optBoolean("brush", true))
                else -> null
            }
            else -> null
        }
    }

    fun iconToJson(spec: IconSpec, relPath: String? = null): Any = when (spec) {
        is IconSpec.Img -> JSONObject().put("image", relPath ?: spec.path).put("tint", spec.tint)
        is IconSpec.Txt -> JSONObject().put("text", spec.text).put("brush", spec.brush).also { o -> spec.color?.let { o.put("color", hex(it)) } }
    }

    /** 读取主题包目录（里面有 theme.json）。 */
    fun load(dir: File): ThemePack? {
        val f = File(dir, "theme.json")
        if (!f.isFile) return null
        val o = try { JSONObject(f.readText()) } catch (_: Exception) { return null }
        val id = o.optString("id").ifBlank { dir.name }
        val dark = o.optBoolean("dark", false)
        var pal = (if (dark) InkPalette else PaperPalette).copy(id = id, isDark = dark)
        o.optJSONObject("colors")?.let { c ->
            for (k in COLOR_KEYS) parseColor(c.optString(k))?.let { pal = withColor(pal, k, it) }
        }
        if (o.has("bubbleAlpha")) pal = pal.copy(bubbleAlpha = o.optDouble("bubbleAlpha", pal.bubbleAlpha.toDouble()).toFloat().coerceIn(0.3f, 1f))
        val images = HashMap<String, String>()
        o.optJSONObject("images")?.let { im ->
            for (k in IMAGE_KEYS) {
                val rel = im.optString(k)
                if (rel.isNotBlank()) File(dir, rel).takeIf { it.isFile }?.let { images[k] = it.absolutePath }
            }
        }
        val icons = HashMap<String, IconSpec>()
        o.optJSONObject("icons")?.let { ic ->
            val keys = ic.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                parseIcon(ic.opt(k), dir)?.let { icons[k] = it }
            }
        }
        val font = o.optString("font").takeIf { it.isNotBlank() }?.let { File(dir, it) }?.takeIf { it.isFile }?.absolutePath
        return ThemePack(
            id = id,
            name = o.optString("name").ifBlank { id },
            author = o.optString("author"),
            description = o.optString("description"),
            version = o.optInt("version", 1),
            builtIn = false,
            dir = dir.absolutePath,
            palette = pal,
            images = images,
            icons = icons,
            fontPath = font,
            heroTint = o.optBoolean("heroTint", true),
            dividerTint = o.optBoolean("dividerTint", true),
        )
    }
}
