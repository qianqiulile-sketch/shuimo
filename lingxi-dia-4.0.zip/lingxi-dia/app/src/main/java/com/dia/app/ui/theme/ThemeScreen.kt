package com.dia.app.ui.theme

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dia.app.files.AiFolder
import com.dia.app.llm.LlmGateway
import com.dia.app.prefs.DiaSettings
import kotlinx.coroutines.launch

/** 传统色，改颜色时可以直接点。 */
private val TRADITIONAL = listOf(
    "朱砂" to "#B5372B", "胭脂" to "#9D2933", "赭石" to "#845A33", "缃色" to "#F0C239", "藤黄" to "#FFB61E",
    "竹青" to "#789262", "松绿" to "#3C6E47", "黛青" to "#3E6E64", "石青" to "#1685A9", "靛蓝" to "#065279",
    "墨" to "#231E1A", "玄青" to "#3D3B4F", "月白" to "#D6ECF0", "宣纸" to "#F4EEDF", "象牙" to "#FFFBF0",
    "古金" to "#9A7B3C", "金" to "#E8C77E", "玄墨" to "#0E0C0B", "鸦青" to "#424C50", "藕荷" to "#E4C6D0",
)

/**
 * 「主题与图标」：
 *  - 选主题（内置 / 导入的主题包 / AI 生成），导入 .lxtheme，导出分享
 *  - 每一个图标位都能换成图片或文字；每一种颜色、每一张图片（背景、头像、插画…）、标题字体都能改
 *  - 改动只叠加在当前主题上，随时一键恢复；也可以「另存为我的主题」
 */
@Composable
fun ThemeScreen(onBack: () -> Unit) {
    val p = DiaPal.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val current by ThemeManager.current.collectAsState()
    val installed by ThemeManager.installed.collectAsState()
    val overrides by ThemeManager.overrides.collectAsState()
    val wujiTheme by DiaSettings.wujiTheme.flow.collectAsState()
    val editId = current.id
    val ov = overrides[editId]

    var iconSlot by remember { mutableStateOf<IconSlot?>(null) }
    var colorKey by remember { mutableStateOf<String?>(null) }
    var pendingIcon by remember { mutableStateOf<Pair<String, Boolean>?>(null) }
    var pendingImage by remember { mutableStateOf<String?>(null) }
    var showGen by remember { mutableStateOf(false) }
    var showSaveAs by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf("") }

    fun toast(t: String) = Toast.makeText(context, t, Toast.LENGTH_SHORT).show()

    val importPack = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) scope.launch {
            busy = "正在导入…"
            try {
                val pack = ThemeManager.importZip(uri)
                ThemeManager.apply(pack.id)
                toast("已导入并切换到「${pack.name}」")
            } catch (e: Exception) { toast("导入失败：${e.message}") }
            busy = ""
        }
    }
    val pickIcon = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        val target = pendingIcon
        pendingIcon = null
        if (uri != null && target != null) scope.launch {
            try { ThemeManager.setIconImage(editId, target.first, uri, target.second) } catch (e: Exception) { toast("失败：${e.message}") }
        }
    }
    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        val key = pendingImage
        pendingImage = null
        if (uri != null && key != null) scope.launch {
            try { ThemeManager.setImage(editId, key, uri) } catch (e: Exception) { toast("失败：${e.message}") }
        }
    }
    val pickFont = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) scope.launch {
            try { ThemeManager.setFont(editId, uri); toast("标题字体已更换") } catch (e: Exception) { toast("失败：${e.message}") }
        }
    }

    Column(Modifier.fillMaxSize().inkWashBackground(p).windowInsetsPadding(WindowInsets.statusBars)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "返回", tint = p.text) }
            Column(Modifier.weight(1f)) {
                Text("主题与图标", style = MaterialTheme.typography.headlineMedium, color = p.text, fontFamily = DiaSerif)
                Text("当前：${ThemeManager.describeCurrent()}" + if (busy.isNotBlank()) " · $busy" else "", style = MaterialTheme.typography.labelSmall, color = p.textTertiary)
            }
        }
        CloudDivider(p, Modifier.padding(horizontal = 16.dp))
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(vertical = 10.dp)) {
            // ── 主题 ──
            item {
                Section(p, "主题") {
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        for (t in BuiltinThemes.ALL + installed) ThemeCard(p, t, t.id == current.id, onApply = { ThemeManager.apply(t.id) },
                            onExport = {
                                scope.launch {
                                    try {
                                        ThemeManager.apply(t.id)
                                        val f = ThemeManager.export(t.id)
                                        toast("已导出：灵犀AI/${AiFolder.rel(f)}")
                                        try { context.startActivity(AiFolder.shareIntent(context, f)) } catch (_: Exception) { }
                                    } catch (e: Exception) { toast("导出失败：${e.message}") }
                                }
                            },
                            onDelete = if (t.builtIn) null else ({ ThemeManager.delete(t.id) }))
                    }
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Btn(p, "导入主题包") { importPack.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) }
                        Btn(p, "AI 生成主题") { if (LlmGateway.isAvailable()) showGen = true else toast("需要先加载模型") }
                        Btn(p, "另存为我的主题") { showSaveAs = true }
                        Btn(p, "导出当前") {
                            scope.launch {
                                try {
                                    val f = ThemeManager.export(editId)
                                    toast("已导出：灵犀AI/${AiFolder.rel(f)}")
                                    try { context.startActivity(AiFolder.shareIntent(context, f)) } catch (_: Exception) { }
                                } catch (e: Exception) { toast("导出失败：${e.message}") }
                            }
                        }
                    }
                    Text("主题包是 .lxtheme（zip）：theme.json + 图片 + 图标 + 字体，格式见项目里的 themes/主题包格式.md。",
                        style = MaterialTheme.typography.labelSmall, color = p.textTertiary, modifier = Modifier.padding(horizontal = 18.dp, vertical = 4.dp))
                }
            }
            item {
                Section(p, "无极模式用哪个主题") {
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        for (t in BuiltinThemes.ALL + installed) Chip(p, t.name, wujiTheme == t.id) { DiaSettings.wujiTheme.set(t.id) }
                    }
                }
            }
            // ── 图标 ──
            item {
                Section(p, "图标（${current.name}）") {
                    Text("点任意图标换成图片或文字（emoji / 汉字都行）。改动只作用在当前主题上。",
                        style = MaterialTheme.typography.labelSmall, color = p.textTertiary, modifier = Modifier.padding(horizontal = 18.dp))
                    for (g in IconSlots.GROUPS) {
                        Text(g, color = p.cinnabar, fontFamily = DiaSerif, fontSize = 16.sp, modifier = Modifier.padding(start = 18.dp, top = 8.dp))
                        val slots = IconSlots.ALL.filter { it.group == g }
                        for (row in slots.chunked(5)) {
                            Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp)) {
                                for (sl in row) {
                                    val changed = ov?.icons?.containsKey(sl.key) == true
                                    Column(
                                        Modifier.weight(1f).padding(3.dp).clip(RoundedCornerShape(10.dp))
                                            .background(if (changed) p.cinnabar.copy(alpha = 0.08f) else p.surfaceAlt.copy(alpha = 0.5f))
                                            .clickable { iconSlot = sl }.padding(vertical = 8.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                    ) {
                                        SlotPreview(sl, p.text, 28.dp)
                                        Text(sl.label, style = MaterialTheme.typography.labelSmall, color = p.textSecondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    }
                                }
                                repeat(5 - row.size) { Spacer(Modifier.weight(1f)) }
                            }
                        }
                    }
                }
            }
            // ── 颜色 ──
            item {
                Section(p, "颜色") {
                    for (k in ThemeJson.COLOR_KEYS) {
                        val c = ThemeJson.colorOf(current.palette, k)
                        Row(
                            Modifier.fillMaxWidth().clickable { colorKey = k }.padding(horizontal = 18.dp, vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Box(Modifier.size(24.dp).clip(CircleShape).background(c).border(0.8.dp, p.border, CircleShape))
                            Spacer(Modifier.width(10.dp))
                            Text(ThemeJson.COLOR_LABELS[k] ?: k, color = p.text, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                            if (ov?.colors?.containsKey(k) == true) Text("已改 ", color = p.cinnabar, style = MaterialTheme.typography.labelSmall)
                            Text(ThemeJson.hex(c).replace("#FF", "#"), color = p.textTertiary, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
            // ── 图片 / 字体 ──
            item {
                Section(p, "图片与字体") {
                    for (k in ThemeJson.IMAGE_KEYS) {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            val path = current.images[k]
                            val bmp = rememberThemeBitmap(path, 128)
                            Box(Modifier.size(40.dp).clip(RoundedCornerShape(6.dp)).background(p.surfaceAlt), contentAlignment = Alignment.Center) {
                                if (bmp != null) Image(bmp, null, Modifier.size(40.dp), contentScale = ContentScale.Crop)
                                else if (k == "background") Image(ImageBitmap.imageResource(current.palette.bgRes), null,
                                    Modifier.size(40.dp), contentScale = ContentScale.Crop)
                                else Text("默", color = p.textTertiary, fontFamily = DiaBrush)
                            }
                            Spacer(Modifier.width(10.dp))
                            Text(ThemeJson.IMAGE_LABELS[k] ?: k, color = p.text, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                            Text("换", color = p.cinnabar, modifier = Modifier.clickable { pendingImage = k; pickImage.launch("image/*") }.padding(8.dp))
                            if (ov?.images?.containsKey(k) == true) {
                                Text("还原", color = p.textSecondary, modifier = Modifier.clickable { scope.launch { ThemeManager.setImage(editId, k, null) } }.padding(8.dp))
                            }
                        }
                    }
                    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("书", fontFamily = DiaBrush, fontSize = 26.sp, color = p.text)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("标题字体", color = p.text, style = MaterialTheme.typography.bodyMedium)
                            Text("导入 .ttf / .otf（如书法字体），所有标题、印章、按钮字都会换", color = p.textTertiary, style = MaterialTheme.typography.labelSmall)
                        }
                        Text("换", color = p.cinnabar, modifier = Modifier.clickable { pickFont.launch(arrayOf("font/*", "application/octet-stream", "*/*")) }.padding(8.dp))
                        if (ov?.font != null) Text("还原", color = p.textSecondary, modifier = Modifier.clickable { scope.launch { ThemeManager.setFont(editId, null) } }.padding(8.dp))
                    }
                    Text("对话背景也可以在 设置 → 外观 里从相册选，或说「/背景 雪夜孤舟」让 AI 画一张（会覆盖主题背景）。",
                        style = MaterialTheme.typography.labelSmall, color = p.textTertiary, modifier = Modifier.padding(horizontal = 18.dp, vertical = 4.dp))
                }
            }
            item {
                Section(p, "恢复") {
                    Text(
                        if (ov == null || ov.isEmpty) "当前主题没有个人修改。" else "清除当前主题上的 ${ov.count} 处个人修改",
                        color = if (ov == null || ov.isEmpty) p.textTertiary else p.error, style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.fillMaxWidth().clickable(enabled = ov != null && !ov.isEmpty) { ThemeManager.resetAll(editId) }
                            .padding(horizontal = 18.dp, vertical = 10.dp),
                    )
                }
            }
            item { Spacer(Modifier.height(40.dp)) }
        }
    }

    iconSlot?.let { sl ->
        IconDialog(
            p, sl, changed = ov?.icons?.containsKey(sl.key) == true,
            onDismiss = { iconSlot = null },
            onPickImage = { tint -> iconSlot = null; pendingIcon = sl.key to tint; pickIcon.launch("image/*") },
            onText = { t -> iconSlot = null; ThemeManager.setIconText(editId, sl.key, t) },
            onReset = { iconSlot = null; ThemeManager.resetIcon(editId, sl.key) },
        )
    }
    colorKey?.let { k ->
        ColorDialog(p, ThemeJson.COLOR_LABELS[k] ?: k, ThemeJson.hex(ThemeJson.colorOf(current.palette, k)).replace("#FF", "#"),
            onDismiss = { colorKey = null },
            onSave = { hex -> colorKey = null; ThemeManager.setColor(editId, k, hex) },
            onReset = { colorKey = null; ThemeManager.setColor(editId, k, null) })
    }
    if (showGen) {
        var prompt by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showGen = false },
            title = { Text("AI 生成主题") },
            text = {
                Column {
                    OutlinedTextField(value = prompt, onValueChange = { prompt = it }, label = { Text("描述想要的风格") }, minLines = 2, modifier = Modifier.fillMaxWidth())
                    Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        for (x in listOf("青绿山水，清新淡雅", "敦煌壁画，土黄与石青", "雪夜寒梅，冷白与胭脂", "竹林听雨，墨绿")) Chip(p, x, false) { prompt = x }
                    }
                    Text("AI 会配色并画一张背景（用当前的生图方式）。", style = MaterialTheme.typography.labelSmall, color = p.textTertiary)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (prompt.isBlank()) return@TextButton
                    showGen = false
                    scope.launch {
                        busy = "AI 正在设计主题…"
                        try {
                            val pk = ThemeManager.generate(prompt, null)
                            toast("已生成「${pk.name}」")
                        } catch (e: Exception) { toast("生成失败：${e.message}") }
                        busy = ""
                    }
                }) { Text("生成", color = p.cinnabar) }
            },
            dismissButton = { TextButton(onClick = { showGen = false }) { Text("取消") } },
        )
    }
    if (showSaveAs) {
        var name by remember { mutableStateOf(current.name + "·改") }
        AlertDialog(
            onDismissRequest = { showSaveAs = false },
            title = { Text("另存为我的主题") },
            text = { OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("主题名") }, singleLine = true) },
            confirmButton = {
                TextButton(onClick = {
                    showSaveAs = false
                    scope.launch {
                        try { ThemeManager.saveAs(editId, name); toast("已另存并切换") } catch (e: Exception) { toast("失败：${e.message}") }
                    }
                }) { Text("保存", color = p.cinnabar) }
            },
            dismissButton = { TextButton(onClick = { showSaveAs = false }) { Text("取消") } },
        )
    }
}

@Composable
private fun Section(p: DiaPalette, title: String, content: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)) {
        Text(title, style = MaterialTheme.typography.titleLarge, color = p.cinnabar, fontFamily = DiaSerif, modifier = Modifier.padding(start = 6.dp, bottom = 4.dp))
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(p.surface.copy(alpha = p.bubbleAlpha))
                .paperGrain(if (p.isDark) 0.05f else 0.09f).scrollFrame(p).padding(vertical = 6.dp),
        ) { content() }
    }
}

@Composable
private fun ThemeCard(p: DiaPalette, t: ThemePack, selected: Boolean, onApply: () -> Unit, onExport: () -> Unit, onDelete: (() -> Unit)?) {
    var menu by remember { mutableStateOf(false) }
    val bmp = rememberThemeBitmap(t.images["background"], 256)
    Column(
        Modifier.width(118.dp).clip(RoundedCornerShape(12.dp))
            .border(if (selected) 2.dp else 0.8.dp, if (selected) p.cinnabar else p.border, RoundedCornerShape(12.dp))
            .clickable(onClick = onApply),
    ) {
        Box(Modifier.fillMaxWidth().height(150.dp).background(t.palette.background)) {
            if (bmp != null) Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            else Image(ImageBitmap.imageResource(t.palette.bgRes), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            Row(Modifier.align(Alignment.BottomStart).padding(6.dp), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                for (c in listOf(t.palette.cinnabar, t.palette.gold, t.palette.indigo, t.palette.text)) {
                    Box(Modifier.size(12.dp).clip(CircleShape).background(c).border(0.5.dp, Color.White.copy(alpha = 0.6f), CircleShape))
                }
            }
            Box(Modifier.align(Alignment.TopEnd)) {
                Text("⋮", color = t.palette.text, modifier = Modifier.clickable { menu = true }.padding(6.dp))
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("使用") }, onClick = { menu = false; onApply() })
                    DropdownMenuItem(text = { Text("导出分享") }, onClick = { menu = false; onExport() })
                    if (onDelete != null) DropdownMenuItem(text = { Text("删除", color = p.error) }, onClick = { menu = false; onDelete() })
                }
            }
        }
        Column(Modifier.fillMaxWidth().background(p.surface).padding(6.dp)) {
            Text(t.name + if (selected) " ✓" else "", style = MaterialTheme.typography.labelLarge, color = p.text, maxLines = 1)
            Text(t.description.ifBlank { t.author }, style = MaterialTheme.typography.labelSmall, color = p.textTertiary, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun IconDialog(
    p: DiaPalette,
    slot: IconSlot,
    changed: Boolean,
    onDismiss: () -> Unit,
    onPickImage: (tint: Boolean) -> Unit,
    onText: (String) -> Unit,
    onReset: () -> Unit,
) {
    var text by remember { mutableStateOf("") }
    var tint by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("图标：${slot.label}") },
        text = {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    SlotPreview(slot, p.text, 44.dp)
                    Spacer(Modifier.width(10.dp))
                    Text("位置 ${slot.key}", style = MaterialTheme.typography.labelSmall, color = p.textTertiary)
                }
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(value = text, onValueChange = { text = it.take(4) }, label = { Text("换成文字 / emoji（最多 4 个字）") }, singleLine = true)
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (x in listOf("发", "听", "囊", "网", "器", "☯", "🗡", "🪶", "🍵", "🏮", "⛩", "🐉")) Chip(p, x, text == x) { text = x }
                }
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("图片按主题颜色着色（适合单色线稿）", style = MaterialTheme.typography.bodySmall, color = p.text, modifier = Modifier.weight(1f))
                    Switch(checked = tint, onCheckedChange = { tint = it }, colors = SwitchDefaults.colors(checkedTrackColor = p.cinnabar))
                }
                Btn(p, "从相册选一张图片") { onPickImage(tint) }
            }
        },
        confirmButton = { TextButton(onClick = { if (text.isNotBlank()) onText(text) else onDismiss() }) { Text("用这几个字", color = p.cinnabar) } },
        dismissButton = {
            Row {
                if (changed) TextButton(onClick = onReset) { Text("恢复默认") }
                TextButton(onClick = onDismiss) { Text("取消") }
            }
        },
    )
}

@Composable
private fun ColorDialog(p: DiaPalette, label: String, initial: String, onDismiss: () -> Unit, onSave: (String) -> Unit, onReset: () -> Unit) {
    var hex by remember { mutableStateOf(initial) }
    val parsed = ThemeJson.parseColor(hex)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("颜色：$label") },
        text = {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(36.dp).clip(CircleShape).background(parsed ?: Color.Transparent).border(1.dp, p.border, CircleShape))
                    Spacer(Modifier.width(10.dp))
                    OutlinedTextField(value = hex, onValueChange = { hex = it.trim() }, label = { Text("#RRGGBB") }, singleLine = true, isError = parsed == null)
                }
                Spacer(Modifier.height(8.dp))
                Text("中国传统色", style = MaterialTheme.typography.labelMedium, color = p.textSecondary)
                for (row in TRADITIONAL.chunked(5)) {
                    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                        for ((n, h) in row) {
                            Column(Modifier.weight(1f).clickable { hex = h }, horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(Modifier.size(26.dp).clip(CircleShape).background(ThemeJson.parseColor(h) ?: Color.Gray)
                                    .border(if (hex.equals(h, true)) 2.dp else 0.5.dp, if (hex.equals(h, true)) p.cinnabar else p.border, CircleShape))
                                Text(n, style = MaterialTheme.typography.labelSmall, color = p.textTertiary)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { if (parsed != null) onSave(hex) }) { Text("确定", color = p.cinnabar) } },
        dismissButton = {
            Row {
                TextButton(onClick = onReset) { Text("恢复默认") }
                TextButton(onClick = onDismiss) { Text("取消") }
            }
        },
    )
}

@Composable
private fun Btn(p: DiaPalette, label: String, onClick: () -> Unit) {
    Text(
        label, style = MaterialTheme.typography.labelLarge, color = p.cinnabar,
        modifier = Modifier.clip(RoundedCornerShape(10.dp)).border(1.dp, p.cinnabar.copy(alpha = 0.6f), RoundedCornerShape(10.dp))
            .clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 8.dp),
    )
}

@Composable
private fun Chip(p: DiaPalette, label: String, selected: Boolean, onClick: () -> Unit) {
    Text(
        label, style = MaterialTheme.typography.labelMedium, maxLines = 1,
        color = if (selected) p.onCinnabar else p.textSecondary,
        modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(if (selected) p.cinnabar else p.surfaceAlt)
            .clickable(onClick = onClick).padding(horizontal = 10.dp, vertical = 6.dp),
    )
}
