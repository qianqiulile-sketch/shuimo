package com.dia.app.ui.tools

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.dia.app.agent.AgentTools
import com.dia.app.agent.ToolCatalog
import com.dia.app.agent.ToolSpec
import com.dia.app.files.FileManager
import com.dia.app.llm.LlmGateway
import com.dia.app.ui.theme.DiaPalette
import com.dia.app.ui.theme.DiaSerif
import com.dia.app.ui.theme.ToolGlyph
import org.json.JSONObject

/**
 * 工具台：灵犀的全部工具一览。AI 能用的，你也能直接用。
 *  - 选一个工具 → 看说明、说法示例 → 填参数
 *  - 「立即执行」：马上执行（AI 正在回复时也能并行），结果作为卡片进入对话
 *  - 「执行后交给 AI」：先执行，再让 AI 根据结果接着处理（AI 还可以自主再调其它工具）
 */
@Composable
fun ToolPanelSheet(
    p: DiaPalette,
    initialTool: String? = null,
    onRun: (name: String, args: JSONObject, thenAi: Boolean) -> Unit,
    onSay: (String) -> Unit,
) {
    var selected by remember { mutableStateOf<ToolSpec?>(initialTool?.let { AgentTools.spec(it) }) }
    val s = selected
    if (s == null) {
        ToolList(p, onPick = { selected = it })
    } else {
        ToolForm(p, s, onBack = { selected = null }, onRun = onRun, onSay = onSay)
    }
}

@Composable
private fun ToolList(p: DiaPalette, onPick: (ToolSpec) -> Unit) {
    var query by remember { mutableStateOf("") }
    var group by remember { mutableStateOf("all") }
    val tools = AgentTools.ALL.filter { t ->
        (group == "all" || t.group == group) &&
            (query.isBlank() || t.name.contains(query, true) || t.title.contains(query) || t.desc.contains(query))
    }
    Column(Modifier.fillMaxWidth().padding(bottom = 16.dp)) {
        Column(Modifier.padding(horizontal = 20.dp)) {
            Text("工具台 · 兵器谱", style = MaterialTheme.typography.headlineMedium, color = p.text, fontFamily = DiaSerif)
            Text(
                "AI 自主调用和你亲自调用用的是同一套工具。也可以在输入框写「@工具名 内容」，例如「@联网搜索 今日新闻」。",
                style = MaterialTheme.typography.bodySmall, color = p.textTertiary,
            )
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = query, onValueChange = { query = it }, singleLine = true,
                placeholder = { Text("搜工具：搜索、文件、PPT、手机…") }, modifier = Modifier.fillMaxWidth(),
            )
        }
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Chip(p, "全部", group == "all") { group = "all" }
            for ((g, label) in ToolCatalog.GROUP_LABELS) Chip(p, label, group == g) { group = g }
        }
        LazyColumn(Modifier.fillMaxWidth().heightIn(max = 520.dp)) {
            items(tools, key = { it.name }) { t ->
                Row(
                    Modifier.fillMaxWidth().clickable { onPick(t) }.padding(horizontal = 20.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(
                        Modifier.size(38.dp).clip(RoundedCornerShape(9.dp)).background(p.surfaceAlt).border(0.6.dp, p.border, RoundedCornerShape(9.dp)),
                        contentAlignment = Alignment.Center,
                    ) { ToolGlyph(t.name, p.text, 24.dp) }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(t.title, style = MaterialTheme.typography.titleSmall, color = p.text)
                            Spacer(Modifier.width(6.dp))
                            Text(t.name, style = MaterialTheme.typography.labelSmall, color = p.textTertiary, fontFamily = FontFamily.Monospace)
                            if (t.needsConfirm) {
                                Spacer(Modifier.width(6.dp))
                                Text("需确认", style = MaterialTheme.typography.labelSmall, color = p.cinnabar)
                            }
                        }
                        Text(t.desc, style = MaterialTheme.typography.labelSmall, color = p.textSecondary, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
    }
}

@Composable
private fun ToolForm(
    p: DiaPalette,
    spec: ToolSpec,
    onBack: () -> Unit,
    onRun: (String, JSONObject, Boolean) -> Unit,
    onSay: (String) -> Unit,
) {
    val params = remember(spec.name) { ToolCatalog.params(spec) }
    val values = remember(spec.name) { mutableStateMapOf<String, String>() }
    val files by FileManager.files.collectAsState()
    var rawJson by remember(spec.name) { mutableStateOf(false) }
    var jsonText by remember(spec.name) { mutableStateOf("{}") }
    Column(Modifier.fillMaxWidth().padding(bottom = 20.dp).heightIn(max = 640.dp)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "返回", tint = p.text) }
            ToolGlyph(spec.name, p.text, 26.dp)
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f)) {
                Text(spec.title, style = MaterialTheme.typography.titleLarge, color = p.text, fontFamily = DiaSerif)
                Text(spec.name, style = MaterialTheme.typography.labelSmall, color = p.textTertiary, fontFamily = FontFamily.Monospace)
            }
        }
        LazyColumn(Modifier.fillMaxWidth().weight(1f, fill = false)) {
            item {
                Text(spec.desc, style = MaterialTheme.typography.bodySmall, color = p.textSecondary, modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp))
                val ex = ToolCatalog.EXAMPLES[spec.name].orEmpty()
                if (ex.isNotEmpty()) {
                    Text("这样跟灵犀说也会调用它（点一下放进输入框）：", style = MaterialTheme.typography.labelSmall, color = p.textTertiary,
                        modifier = Modifier.padding(start = 20.dp, top = 6.dp))
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        for (e in ex) Chip(p, e, false) { onSay(e) }
                    }
                }
                Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("直接写 JSON 参数", style = MaterialTheme.typography.labelMedium, color = p.textSecondary, modifier = Modifier.weight(1f))
                    Switch(checked = rawJson, onCheckedChange = {
                        rawJson = it
                        if (it) jsonText = ToolCatalog.buildArgs(spec, values).toString(2)
                    }, colors = SwitchDefaults.colors(checkedTrackColor = p.cinnabar))
                }
            }
            if (rawJson) {
                item {
                    OutlinedTextField(
                        value = jsonText, onValueChange = { jsonText = it }, minLines = 4,
                        label = { Text("参数 JSON（模板：${spec.args.take(80)}）") },
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    )
                }
            } else {
                items(params, key = { it.key }) { prm ->
                    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)) {
                        when {
                            prm.choices.isNotEmpty() -> {
                                Text(prm.key, style = MaterialTheme.typography.labelMedium, color = p.textSecondary)
                                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    for (c in prm.choices) Chip(p, c, values[prm.key] == c) { values[prm.key] = if (values[prm.key] == c) "" else c }
                                }
                            }
                            prm.kind == "bool" -> Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(prm.key, style = MaterialTheme.typography.labelMedium, color = p.textSecondary, modifier = Modifier.weight(1f))
                                Switch(checked = values[prm.key] == "true", onCheckedChange = { values[prm.key] = it.toString() },
                                    colors = SwitchDefaults.colors(checkedTrackColor = p.cinnabar))
                            }
                            else -> {
                                OutlinedTextField(
                                    value = values[prm.key].orEmpty(), onValueChange = { values[prm.key] = it },
                                    label = { Text(prm.key) },
                                    placeholder = { Text(prm.example.take(60), color = p.textTertiary) },
                                    singleLine = prm.kind !in setOf("long", "json", "list"),
                                    minLines = if (prm.kind == "long") 3 else 1,
                                    modifier = Modifier.fillMaxWidth(),
                                )
                                if ((prm.kind == "file" || prm.kind == "files") && files.isNotEmpty()) {
                                    Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        for (f in files.take(12)) {
                                            Chip(p, "${f.id} ${f.name.take(14)}", values[prm.key]?.split(Regex("[，,]"))?.map { it.trim() }?.contains(f.id) == true) {
                                                values[prm.key] = if (prm.kind == "files") {
                                                    val cur = values[prm.key].orEmpty().split(Regex("[，,]")).map { it.trim() }.filter { it.isNotEmpty() }
                                                    (if (f.id in cur) cur - f.id else cur + f.id).joinToString(",")
                                                } else f.id
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        var error by remember { mutableStateOf("") }
        if (error.isNotBlank()) Text(error, color = p.error, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(horizontal = 20.dp))
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            fun args(): JSONObject? = if (rawJson) {
                try { JSONObject(jsonText) } catch (e: Exception) { error = "JSON 格式不对：${e.message}"; null }
            } else ToolCatalog.buildArgs(spec, values)
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).background(p.cinnabar)
                    .clickable { args()?.let { onRun(spec.name, it, false) } }.padding(vertical = 12.dp),
                contentAlignment = Alignment.Center,
            ) { Text("立即执行", color = p.onCinnabar, style = MaterialTheme.typography.labelLarge) }
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).border(1.dp, p.cinnabar, RoundedCornerShape(10.dp))
                    .clickable(enabled = LlmGateway.isAvailable()) { args()?.let { onRun(spec.name, it, true) } }.padding(vertical = 12.dp),
                contentAlignment = Alignment.Center,
            ) { Text(if (LlmGateway.isAvailable()) "执行后交给 AI" else "（未加载模型）", color = p.cinnabar, style = MaterialTheme.typography.labelLarge) }
        }
    }
}

@Composable
private fun Chip(p: DiaPalette, label: String, selected: Boolean, onClick: () -> Unit) {
    Text(
        label, style = MaterialTheme.typography.labelMedium,
        color = if (selected) p.onCinnabar else p.textSecondary, maxLines = 1,
        modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(if (selected) p.cinnabar else p.surfaceAlt)
            .clickable(onClick = onClick).padding(horizontal = 10.dp, vertical = 6.dp),
    )
}

/** 输入框里打了「@」时，在上方给出匹配的工具。 */
@Composable
fun MentionSuggestions(p: DiaPalette, input: String, onPick: (ToolSpec) -> Unit) {
    if (!input.startsWith("@") || input.contains(' ') || input.contains('\n')) return
    val q = input.removePrefix("@")
    val list = AgentTools.ALL.filter { it.group != "deep" && (q.isEmpty() || it.title.contains(q) || it.name.contains(q, true)) }.take(12)
    if (list.isEmpty()) return
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 10.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        for (t in list) {
            Row(
                Modifier.clip(RoundedCornerShape(12.dp)).background(p.surfaceAlt).border(0.6.dp, p.border, RoundedCornerShape(12.dp))
                    .clickable { onPick(t) }.padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                ToolGlyph(t.name, p.text, 16.dp)
                Spacer(Modifier.width(4.dp))
                Text(t.title, style = MaterialTheme.typography.labelMedium, color = p.text)
            }
        }
    }
}
