package com.dia.app.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

/**
 * Lazy app-wide text-to-speech wrapper. One TTS engine is shared across
 * features so we don't spin up a new TextToSpeech every time the user taps
 * a speaker button.
 *
 * Exposes a flow of the currently-playing utterance id so the UI can show
 * which message is being read.
 */
object DiaTts {

    private const val TAG = "DiaTts"

    @Volatile
    private var engine: TextToSpeech? = null
    @Volatile
    private var ready: Boolean = false

    private val _speakingId = MutableStateFlow<String?>(null)
    val speakingId: StateFlow<String?> = _speakingId.asStateFlow()

    /** Build the engine lazily on first use. */
    private fun ensure(context: Context, onReady: (() -> Unit)? = null) {
        if (engine != null) {
            if (ready) onReady?.invoke()
            return
        }
        val app = context.applicationContext
        engine = TextToSpeech(app) { status ->
            ready = status == TextToSpeech.SUCCESS
            if (ready) {
                // 优先使用中文语音；设备没有中文语音包时退回系统默认
                val zh = Locale.SIMPLIFIED_CHINESE
                val avail = try { engine?.isLanguageAvailable(zh) ?: TextToSpeech.LANG_NOT_SUPPORTED } catch (_: Exception) { TextToSpeech.LANG_NOT_SUPPORTED }
                engine?.language = if (avail >= TextToSpeech.LANG_AVAILABLE) zh else Locale.getDefault()
                engine?.setSpeechRate(1.05f)
                engine?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        _speakingId.value = utteranceId
                    }
                    override fun onDone(utteranceId: String?) {
                        if (_speakingId.value == utteranceId) _speakingId.value = null
                    }
                    @Deprecated("Deprecated in API")
                    override fun onError(utteranceId: String?) {
                        if (_speakingId.value == utteranceId) _speakingId.value = null
                    }
                    override fun onError(utteranceId: String?, errorCode: Int) {
                        if (_speakingId.value == utteranceId) _speakingId.value = null
                    }
                })
                onReady?.invoke()
            } else {
                Log.w(TAG, "TextToSpeech init failed: $status")
            }
        }
    }

    /** Speak [text] tagged with [id]. Cancels any ongoing utterance. */
    fun speak(context: Context, id: String, text: String) {
        if (text.isBlank()) return
        val cleaned = stripForSpeech(text)
        if (cleaned.isBlank()) return
        ensure(context) {
            val tts = engine ?: return@ensure
            tts.stop()
            _speakingId.value = id
            tts.speak(cleaned, TextToSpeech.QUEUE_FLUSH, null, id)
        }
    }

    /** Stop current speech, if any. */
    fun stop() {
        engine?.stop()
        _speakingId.value = null
    }

    /** Toggle: if [id] is already speaking, stop. Otherwise speak it. */
    fun toggle(context: Context, id: String, text: String) {
        if (_speakingId.value == id) stop() else speak(context, id, text)
    }

    fun shutdown() {
        try { engine?.stop() } catch (_: Exception) {}
        try { engine?.shutdown() } catch (_: Exception) {}
        engine = null
        ready = false
        _speakingId.value = null
    }

    /**
     * Strip markdown / latex / code fences so the utterance sounds natural.
     * Mirrors the cleanup the chat UI already does, but kept simple.
     */
    private fun stripForSpeech(text: String): String {
        var t = text
        // Remove fenced code blocks
        t = t.replace(Regex("```[\\s\\S]*?```"), " 代码块 ")
        // Remove inline code
        t = t.replace(Regex("`([^`]+)`"), "$1")
        // Remove markdown bold/italic markers
        t = t.replace(Regex("[*_]{1,3}([^*_\\n]+?)[*_]{1,3}"), "$1")
        // Remove markdown headers
        t = t.replace(Regex("(?m)^#{1,6}\\s*"), "")
        // Remove links: [text](url) → text
        t = t.replace(Regex("\\[([^]]+)]\\(([^)]+)\\)"), "$1")
        // Remove blockquote markers
        t = t.replace(Regex("(?m)^>\\s?"), "")
        // Collapse repeating whitespace
        t = t.replace(Regex("\\s+"), " ").trim()
        return t
    }
}
