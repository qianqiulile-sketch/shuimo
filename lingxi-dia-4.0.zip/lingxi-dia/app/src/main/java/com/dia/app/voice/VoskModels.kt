package com.dia.app.voice

import android.content.Context
import android.net.Uri
import android.util.Log
import com.dia.app.prefs.DiaSettings
import com.dia.app.web.Http
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.vosk.LibVosk
import org.vosk.LogLevel
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/**
 * 嵌入式离线语音识别模型（Vosk / Kaldi）。
 *
 * - 模型放在 `filesDir/stt/<模型名>/`，可在设置里一键下载（中文小模型约 42MB），或从手机里导入 zip
 * - 完全离线、免费、不需要系统语音服务，也不需要大模型；对话里说话、音频文件转文字都能用
 * - 识别出的中文会去掉字与字之间的空格；没有标点时，转写文件可让 AI 加标点分段
 */
object VoskModels {

    private const val TAG = "VoskModels"

    data class Entry(val id: String, val name: String, val size: String, val url: String, val lang: String)

    val CATALOG = listOf(
        Entry("vosk-model-small-cn-0.22", "中文（普通话）· 小模型", "42MB", "https://alphacephei.com/vosk/models/vosk-model-small-cn-0.22.zip", "zh"),
        Entry("vosk-model-cn-0.22", "中文（普通话）· 大模型（更准，较慢）", "1.3GB", "https://alphacephei.com/vosk/models/vosk-model-cn-0.22.zip", "zh"),
        Entry("vosk-model-small-en-us-0.15", "英语 · 小模型", "40MB", "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip", "en"),
        Entry("vosk-model-small-ja-0.22", "日语 · 小模型", "48MB", "https://alphacephei.com/vosk/models/vosk-model-small-ja-0.22.zip", "ja"),
    )

    private val _status = MutableStateFlow("")
    val status: StateFlow<String> = _status.asStateFlow()

    /** 已安装模型列表变化时 +1。 */
    private val _installedVersion = MutableStateFlow(0)
    val installedVersion: StateFlow<Int> = _installedVersion.asStateFlow()

    @Volatile private var busy = false
    val isBusy: Boolean get() = busy

    fun dir(ctx: Context): File = File(ctx.filesDir, "stt").apply { mkdirs() }

    private fun looksLikeModel(d: File): Boolean =
        d.isDirectory && (File(d, "am").isDirectory || File(d, "conf").isDirectory || File(d, "final.mdl").exists())

    fun installed(ctx: Context): List<String> =
        dir(ctx).listFiles()?.filter { looksLikeModel(it) }?.map { it.name }?.sorted().orEmpty()

    /** 当前使用的模型目录（设置里选的，没有就用第一个已安装的）。 */
    fun current(ctx: Context): File? {
        val list = installed(ctx)
        if (list.isEmpty()) return null
        val want = DiaSettings.sttModel.value
        val name = if (want in list) want else list.firstOrNull { it.contains("cn") } ?: list.first()
        return File(dir(ctx), name)
    }

    fun isReady(ctx: Context): Boolean = current(ctx) != null

    fun sizeOf(ctx: Context, id: String): Long =
        File(dir(ctx), id).walkTopDown().filter { it.isFile }.sumOf { it.length() }

    // ───────── 加载（缓存） ─────────

    private var cachedPath: String? = null
    private var cached: Model? = null
    @Volatile private var nativeOk: Boolean? = null

    private fun ensureNative(): Boolean {
        nativeOk?.let { return it }
        val ok = try {
            LibVosk.setLogLevel(LogLevel.WARNINGS)
            true
        } catch (t: Throwable) {
            Log.w(TAG, "vosk native load failed: ${t.message}")
            false
        }
        nativeOk = ok
        return ok
    }

    /** 加载（或复用）当前模型。首次加载小模型约 1~3 秒。 */
    @Synchronized
    fun model(ctx: Context): Model {
        val d = current(ctx) ?: throw IllegalStateException("还没有离线语音模型：设置 → 语音转文字 → 下载中文小模型（约 42MB）")
        if (!ensureNative()) throw IllegalStateException("这台手机加载不了离线语音引擎（缺少本机库），请改用系统识别或云端转写")
        if (cachedPath == d.absolutePath) cached?.let { return it }
        try { cached?.close() } catch (_: Throwable) { }
        cached = null
        val m = Model(d.absolutePath)
        cached = m
        cachedPath = d.absolutePath
        return m
    }

    @Synchronized
    fun release() {
        try { cached?.close() } catch (_: Throwable) { }
        cached = null
        cachedPath = null
    }

    /** 新建一个 16kHz 识别器（带词级时间戳）。 */
    fun recognizer(ctx: Context, sampleRate: Float = 16000f): Recognizer {
        val r = Recognizer(model(ctx), sampleRate)
        try { r.setWords(true) } catch (_: Throwable) { }
        return r
    }

    // ───────── 结果解析 ─────────

    /** 一句识别结果：文字 + 开始时间（秒，可能为 -1）。 */
    data class Piece(val text: String, val start: Double)

    fun parse(json: String?, key: String = "text"): Piece {
        if (json.isNullOrBlank()) return Piece("", -1.0)
        return try {
            val o = JSONObject(json)
            val t = cleanup(o.optString(key))
            val words = o.optJSONArray("result")
            val start = if (words != null && words.length() > 0) words.optJSONObject(0)?.optDouble("start", -1.0) ?: -1.0 else -1.0
            Piece(t, start)
        } catch (_: Exception) {
            Piece("", -1.0)
        }
    }

    private val cjkSpace = Regex("(?<=[\\u3400-\\u9fff])\\s+(?=[\\u3400-\\u9fff])")

    /** 去掉汉字之间的空格（Vosk 中文模型按字输出）。 */
    fun cleanup(s: String): String = s.replace(cjkSpace, "").trim()

    // ───────── 下载 / 导入 / 删除 ─────────

    /** 从网址下载 zip 并解压安装。返回模型目录名。 */
    suspend fun download(ctx: Context, url: String, id: String? = null): String = withContext(Dispatchers.IO) {
        if (busy) throw IllegalStateException("正在安装另一个模型，请稍候")
        busy = true
        val tmp = File(ctx.cacheDir, "stt_download.zip")
        try {
            _status.value = "正在连接…"
            var current = url
            var conn: HttpURLConnection
            var redirects = 0
            while (true) {
                conn = (URL(current).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 20_000
                    readTimeout = 60_000
                    instanceFollowRedirects = false
                    setRequestProperty("User-Agent", Http.UA)
                }
                val code = conn.responseCode
                if (code in 300..399 && redirects < 6) {
                    val loc = conn.getHeaderField("Location")
                    conn.disconnect()
                    if (loc.isNullOrBlank()) throw IllegalStateException("下载地址重定向失败")
                    current = URL(URL(current), loc).toString()
                    redirects++
                    continue
                }
                if (code !in 200..299) {
                    conn.disconnect()
                    throw IllegalStateException("下载失败（HTTP $code）。可以换个地址，或用电脑下载 zip 后在设置里「导入」")
                }
                break
            }
            val total = conn.contentLengthLong
            try {
                conn.inputStream.use { input ->
                    FileOutputStream(tmp).use { out ->
                        val buf = ByteArray(64 * 1024)
                        var read = 0L
                        var lastPct = -1L
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            read += n
                            if (total > 0) {
                                val pct = read * 100 / total
                                if (pct != lastPct) { lastPct = pct; _status.value = "下载中 $pct%（${read / 1024 / 1024}/${total / 1024 / 1024}MB）" }
                            } else if (read % (1024 * 1024) < n) {
                                _status.value = "已下载 ${read / 1024 / 1024}MB"
                            }
                        }
                    }
                }
            } finally {
                conn.disconnect()
            }
            _status.value = "正在解压…"
            val name = tmp.inputStream().use { unzipModel(ctx, it, id ?: url.substringAfterLast('/').removeSuffix(".zip")) }
            DiaSettings.sttModel.set(name)
            _installedVersion.value++
            _status.value = "已安装：$name"
            name
        } catch (e: Exception) {
            _status.value = "安装失败：${e.message}"
            throw e
        } finally {
            tmp.delete()
            busy = false
        }
    }

    /** 从手机里选的 zip 导入。 */
    suspend fun importZip(ctx: Context, uri: Uri): String = withContext(Dispatchers.IO) {
        if (busy) throw IllegalStateException("正在安装另一个模型，请稍候")
        busy = true
        try {
            _status.value = "正在导入…"
            val fallback = "vosk-model-imported-${System.currentTimeMillis() / 1000}"
            val input = ctx.contentResolver.openInputStream(uri) ?: throw IllegalStateException("无法打开文件")
            val name = input.use { unzipModel(ctx, it, fallback) }
            DiaSettings.sttModel.set(name)
            _installedVersion.value++
            _status.value = "已导入：$name"
            name
        } catch (e: Exception) {
            _status.value = "导入失败：${e.message}"
            throw e
        } finally {
            busy = false
        }
    }

    /**
     * 解压模型 zip。zip 里通常有一层顶层目录（如 vosk-model-small-cn-0.22/），用它做模型名并去掉这一层。
     */
    private fun unzipModel(ctx: Context, input: InputStream, fallbackName: String): String {
        val staging = File(dir(ctx), ".staging").apply { deleteRecursively(); mkdirs() }
        var top: String? = null
        var allUnderTop = true
        var files = 0
        ZipInputStream(input.buffered()).use { zis ->
            while (true) {
                val e = zis.nextEntry ?: break
                val name = e.name.replace('\\', '/').trimStart('/')
                val first = name.substringBefore('/', "")
                if (top == null) top = if (name.contains('/')) first else ""
                if (top.isNullOrEmpty() || !name.startsWith("$top/")) allUnderTop = false
                val out = File(staging, name).canonicalFile
                if (!out.path.startsWith(staging.canonicalPath)) { zis.closeEntry(); continue }
                if (e.isDirectory) out.mkdirs() else {
                    out.parentFile?.mkdirs()
                    FileOutputStream(out).use { zis.copyTo(it) }
                    files++
                }
                zis.closeEntry()
            }
        }
        if (files == 0) throw IllegalStateException("压缩包是空的")
        val src = if (allUnderTop && !top.isNullOrEmpty()) File(staging, top!!) else staging
        if (!looksLikeModel(src)) {
            staging.deleteRecursively()
            throw IllegalStateException("这不是 Vosk 语音模型（缺少 am / conf 目录）")
        }
        val modelName = (if (allUnderTop && !top.isNullOrEmpty()) top!! else fallbackName).replace(Regex("[^A-Za-z0-9._-]"), "_")
        val dst = File(dir(ctx), modelName)
        release()
        dst.deleteRecursively()
        if (!src.renameTo(dst)) {
            src.copyRecursively(dst, overwrite = true)
        }
        staging.deleteRecursively()
        return modelName
    }

    fun delete(ctx: Context, id: String) {
        release()
        File(dir(ctx), id).deleteRecursively()
        if (DiaSettings.sttModel.value == id) DiaSettings.sttModel.set("")
        _installedVersion.value++
    }

    fun entryFor(id: String): Entry? = CATALOG.firstOrNull { it.id == id }
}
