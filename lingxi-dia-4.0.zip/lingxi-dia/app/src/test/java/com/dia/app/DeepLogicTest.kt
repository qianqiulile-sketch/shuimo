package com.dia.app

import com.dia.app.agent.StepThinker
import com.dia.app.deep.DeepEngine
import com.dia.app.deep.DeepStep
import com.dia.app.deep.PlanOps
import com.dia.app.voice.AudioDecoder
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** 4.0 新增的纯逻辑：长思计划树、分步思考的可编辑小问题、重采样、本步结论解析。 */
class DeepLogicTest {

    private fun samplePlan(): List<DeepStep> {
        val items = PlanOps.parseOutline(
            """
            1. 明确问题：界定范围
              1.1 收集定义
              1.2 找数据
            2. 分析：比较方案
            - 写报告
            """.trimIndent(),
        )
        return PlanOps.build(items, 1).first
    }

    @Test fun parseAndBuildPlan() {
        val plan = samplePlan()
        assertEquals(3, plan.size)
        assertEquals("明确问题", plan[0].title)
        assertEquals("界定范围", plan[0].detail)
        assertEquals(2, plan[0].children.size)
        assertEquals("s2", plan[0].children[0].id)
        assertEquals(4, PlanOps.counts(plan).second)
        assertEquals("1.2", PlanOps.labelOf(plan, "s3"))
        assertEquals("s3", PlanOps.resolveId(plan, "1.2"))
    }

    @Test fun nextTodoSkipsDoneAndSkipped() {
        var plan = samplePlan()
        assertEquals("s2", PlanOps.nextTodo(plan)?.id)
        plan = PlanOps.update(plan, "s2") { it.copy(status = DeepStep.DONE) }
        assertEquals("s3", PlanOps.nextTodo(plan)?.id)
        plan = PlanOps.update(plan, "s1") { it.copy(status = DeepStep.SKIP) }
        assertEquals("s4", PlanOps.nextTodo(plan)?.id)
        plan = PlanOps.update(plan, "s4") { it.copy(status = DeepStep.DONE) }
        plan = PlanOps.update(plan, "s5") { it.copy(status = DeepStep.FAILED) }
        assertNull(PlanOps.nextTodo(plan))
    }

    @Test fun editPlan() {
        var plan = samplePlan()
        plan = PlanOps.insert(plan, DeepStep("s9", "用户加的", by = "user"), parentId = "s1", afterId = "s2")
        assertEquals(listOf("s2", "s9", "s3"), PlanOps.find(plan, "s1")!!.children.map { it.id })
        plan = PlanOps.move(plan, "s9", up = true)
        assertEquals(listOf("s9", "s2", "s3"), PlanOps.find(plan, "s1")!!.children.map { it.id })
        plan = PlanOps.remove(plan, "s3")
        assertNull(PlanOps.find(plan, "s3"))
        // 插到深层步骤后面时，落在同一层
        plan = PlanOps.insert(plan, DeepStep("s10", "兄弟"), afterId = "s2")
        assertEquals(listOf("s9", "s2", "s10"), PlanOps.find(plan, "s1")!!.children.map { it.id })
        assertTrue(PlanOps.render(plan, "s10").contains("← 当前"))
        assertTrue(PlanOps.markdown("主题", plan).contains("（用户）") || PlanOps.markdown("主题", plan).contains("*(用户)*"))
    }

    @Test fun resetDoing() {
        val plan = PlanOps.update(samplePlan(), "s2") { it.copy(status = DeepStep.DOING) }
        assertEquals(DeepStep.TODO, PlanOps.find(PlanOps.resetDoing(plan), "s2")!!.status)
    }

    @Test fun stepOutcome() {
        val (c1, ok1, _) = DeepEngine.parseOutcome("做了很多事\n【本步结论】\n- 找到了 3 篇资料\n- 写入 资料/a.md\n【状态】完成")
        assertTrue(ok1)
        assertTrue(c1.contains("3 篇资料"))
        val (_, ok2, why) = DeepEngine.parseOutcome("【本步结论】没找到\n【状态】未完成：网站打不开")
        assertFalse(ok2)
        assertEquals("网站打不开", why)
    }

    @Test fun stepThinkerReviewRoundTrip() {
        val root = StepThinker.Node("总问题", 0, "总")
        StepThinker.rebuild(
            root,
            listOf(
                StepThinker.StepItem(1, "第一", true),
                StepThinker.StepItem(2, "第一的子问题"),
                StepThinker.StepItem(3, "跳太深会被收回到下一层"),
                StepThinker.StepItem(1, "第二"),
                StepThinker.StepItem(1, "  "),
            ),
            web = true,
        )
        assertEquals(2, root.children.size)
        assertEquals("1.1", root.children[0].children[0].label)
        assertEquals("1.1.1", root.children[0].children[0].children[0].label)
        assertTrue(root.children[0].needSearch)
        val flat = StepThinker.flatten(root)
        assertEquals(4, flat.size)
        assertEquals(3, flat[2].depth)
    }

    @Test fun resampler() {
        val r = AudioDecoder.Resampler(48_000, 16_000)
        val input = FloatArray(4800) { (it % 100).toFloat() }
        var total = 0
        repeat(10) { total += r.process(input, input.size) }
        // 10 × 4800 个 48k 样本 ≈ 16000 个 16k 样本
        assertTrue(total in 15990..16010)
        val same = AudioDecoder.Resampler(16_000, 16_000)
        assertEquals(100, same.process(FloatArray(100), 100))
    }
}
