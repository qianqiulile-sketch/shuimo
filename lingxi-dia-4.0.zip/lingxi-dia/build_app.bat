@echo off
echo ==========================================
echo    Dia AI App 构建脚本 (Windows)
echo ==========================================
echo.

echo [1/3] 检查环境...
java -version 2>NUL
if %ERRORLEVEL% NEQ 0 (
    echo ❌ 未找到 Java，请安装 JDK 17
    pause
    exit /b 1
)

echo [2/3] 构建 Debug APK...
call gradlew.bat assembleDebug
if %ERRORLEVEL% NEQ 0 (
    echo ❌ 构建失败
    pause
    exit /b 1
)

echo [3/3] 完成！
echo.
echo APK 路径: app\build\outputs\apk\debug\app-debug.apk
echo.
echo 安装到手机:
echo   adb install -r app\build\outputs\apk\debug\app-debug.apk
echo.
pause
