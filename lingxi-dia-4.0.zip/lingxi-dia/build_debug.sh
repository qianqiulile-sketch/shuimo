#!/bin/bash
export JAVA_HOME="/Applications/Android Studio.app/Contents/jbr/Contents/Home"
/Users/lakshya/Documents/Workspace/dia/gradlew -p /Users/lakshya/Documents/Workspace/dia :app:assembleDebug 2>&1
