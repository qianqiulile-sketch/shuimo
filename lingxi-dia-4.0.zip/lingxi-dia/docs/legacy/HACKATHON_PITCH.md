# Dia — Gemma 4 Good Hackathon Strategy

A tactical playbook for the next 4 days. Strategy, story, the features that move the needle, the writeup structure, the 3-minute video script, and the specific things to cut so you ship.

---

## TL;DR — pick your shots

You cannot win every track. Pick three and dominate them.

| Priority | Track | Why you win it | Effort |
|---|---|---|---|
| 1 | **Main Track ($50K / $25K / $15K / $10K)** | Dia is a working multi-feature on-device assistant that nobody else will have at this fidelity | 0 — you have the project |
| 2 | **LiteRT Special Tech ($10K)** | You're literally using LiteRT-LM. Mention it prominently. Layup. | 0 |
| 3 | **Digital Equity & Inclusivity Impact ($10K)** | Elderly Guide + Translate + handwriting Slate + offline + multilingual | Add 2 small features (below) |

Stretch (only if time):
- **Future of Education ($10K)** — only if you frame Slate as a learning companion AND ship the math/handwriting tutor mode below.

**Skip these tracks completely:**
- Cactus — you're not using their framework
- llama.cpp — you're not using it
- Ollama — laptop port is too much work in 4 days
- Unsloth — you haven't fine-tuned anything
- Health & Sciences — MedGemma isn't Gemma 4 and adding it is a trap

> Rule: every hour spent chasing a track you can't actually win is an hour stolen from the Main Track video that decides your $50K.

---

## The single sentence pitch

> Dia is the first complete on-device AI assistant for Android — chat, vision, autonomous control, on-screen guidance, and a handwriting notebook — running fully on Gemma 4 with zero internet, zero account, zero cost.

If a judge can't repeat this back to you after watching your video, you've lost.

---

## Why your project actually matters (the impact frame)

Dia is not "another AI app." Dia is what the smartphone in 4 billion hands should have always had: an assistant that works **without a connection, without a SIM card, without a credit card.**

That framing is the difference between "cool demo" and "this changes things." The judges this year are explicitly looking for *impact* — they said it five times in the brief. Your job is to make them feel the absence of Dia in the world right now.

The four communities Dia genuinely serves:

### 1. The 700 million elderly smartphone users who never learned the apps

Your grandmother with a smartphone she can't actually use. She has WhatsApp, but every time her family changes the layout she's lost. She doesn't say it but she feels stupid. Most days she doesn't open anything except the dialer.

**Dia's answer:** Guide. She speaks "how do I send a photo to my granddaughter?" The cursor flies to the attachment icon. She taps it. The cursor flies to the gallery. She taps that. Photo sent. She's beaming. She didn't have to learn anything.

This is the demo that wins the room.

### 2. The 1.5 billion people without reliable internet

Migrant workers in countries whose language they don't read. Farmers in villages with one bar of signal. Refugees in transit. Students in rural schools. Anyone whose data plan is rationed.

Every other AI assistant on Earth is a cloud API. Cut the wire and they're paperweights. Dia is the only one in their pocket that still works.

**Dia's answer:** Lens Live Translate reads a medicine bottle in any language and speaks the dose in theirs. Lens Live Think describes a form they need to fill out. Chat answers their kid's homework. All offline. All free.

### 3. Children learning in classrooms with one shared computer

The kid who needs a tutor for math but the school can't afford one and the parents work two jobs. The kid who is dyslexic and needs to hear words pronounced. The kid whose first language isn't the language of instruction.

**Dia's answer:** Slate. Write a problem with your finger. Tap the spark. Watch a tutor write the solution back in cursive, at the same scale as your handwriting. It's not just an answer — it's a teacher who shows up when no other teacher could.

### 4. Disabled users who can't navigate visual interfaces

People with motor impairments. People with low vision. People who simply find Android UI exhausting.

**Dia's answer:** Pilot. Speak the goal in plain English. Pilot does it. "Reply to mom saying I'll call back at 5". Done.

> Pick **three** of these for your video. One alone is a nice demo; three is a movement.

---

## What to add in 4 days (ranked by impact-per-hour)

You don't need new features. You need the right small additions that turn each demo into a story. In priority order:

### MUST DO

**1. A "Translate & Save" button in Lens Live Translate (1 hour)**
Right now translations vanish. Add a saved-strip overlay that keeps the last 5 translations on screen so the migrant-worker demo can show "I read three medicine bottles in 30 seconds." Visual proof of utility.

**2. Big-text & high-contrast accessibility mode (2 hours)**
A toggle in Settings that scales up all text to 1.4× and pushes contrast. Sells the "elderly user" pitch in 5 seconds of video.

**3. Two scripted Pilot demo tasks that are guaranteed to work (1 hour)**
Pick two tasks you've actually tested end-to-end (Blinkit search, WhatsApp open chat, Settings WiFi toggle, etc.). Hardcode the demo around those exact prompts. Don't show anything you haven't successfully run 5 times in a row.

**4. Slate "Tutor mode" prompt switch (30 min)**
A second system prompt for Slate that says: *"You are a tutor for a 10-year-old. Show your work step by step. Use plain words."* Gated behind a tiny "Tutor / Direct" toggle. Now Slate isn't a Q&A; it's a teacher.

### SHOULD DO

**5. Voice input on Slate (2 hours)**
Tap a mic, speak the question, Slate writes the answer. This is the killer education demo: a child who can't write yet asks "why is the sky blue?" and watches Dia handwrite an answer. **This is the cleanest "Future of Education" hook.**

**6. Floating Guide bubble (3 hours)**
Right now Guide needs the user to open Dia. Add a persistent floating ball anywhere on screen. They tap it, voice-ask, Guide takes over. This is what Gemini Live and Apple Intelligence are demoing. Match it.

**7. A real "Welcome to Dia" guided walkthrough (1 hour)**
First launch shows a 4-step intro using your own Guide overlay to teach the user about Guide / Pilot / Slate. Recursive and smart. Demo gold.

### COULD DO (skip if running short)

**8. Tablet layout pass for Slate (3 hours)**
Slate is already landscape. On tablets, lay out toolbar on the left, give the canvas a paper feel. Mention "tablet-ready" once in the writeup, don't burn video time on it.

**9. Local Ollama bridge (4-6 hours)**
Skip. Not enough time. Mention it as a roadmap item if asked.

### ABSOLUTELY DO NOT

- Don't build the laptop version. 4 days is not enough.
- Don't add MedGemma. It's not Gemma 4 and the brief is explicit.
- Don't try to fine-tune anything for Unsloth. New Gemma checkpoint in 4 days is impossible.
- Don't add "more features" to chase tracks. Polish wins.

---

## The 3-minute video script

The video is 30/100 of your score and the judges admit it's the most important thing. Build everything around it.

### Structure

```
0:00 - 0:15   HOOK              the real person, the real problem
0:15 - 0:30   DROP THE LOGO     "Meet Dia"
0:30 - 1:00   DEMO 1            Guide — elderly user
1:00 - 1:30   DEMO 2            Lens Live Translate — migrant / traveler
1:30 - 2:00   DEMO 3            Slate — student
2:00 - 2:25   THE TECHNICAL WOW LiteRT, Gemma 4, accessibility tree
2:25 - 2:55   IMPACT ZOOM-OUT   the 4 billion phones offline
2:55 - 3:00   END CARD          one URL, one line
```

### Beat-by-beat

**0:00 — Cold open, no music yet.**

> [Silent. A wrinkled hand holding a phone. Trying to tap something. Tapping the wrong thing. Tap. Frown. Tap again. Phone goes dark.]
>
> Voice over (warm, calm): *"My grandmother has had a smartphone for nine years. She has never sent a photo."*

This is your hook. If you nail this, the rest of the video coasts.

**0:15 — Music in. Hard cut to your logo.**

> *"This is Dia."*
>
> Quick cuts: the home screen with the mascot, an icon glowing, your hands picking up a phone.

**0:30 — Demo 1: Guide for the elderly.**

> Same grandmother. Now Dia is open. She speaks: *"How do I send a photo to my granddaughter?"*
>
> Glass cursor flies across the screen. Each step captioned. She follows, taps. Photo sent. Cut to the granddaughter receiving it on her phone in another city. Smile.
>
> Voice over: *"For the seven hundred million older smartphone users who never learned the apps. Dia takes them by the hand."*

**1:00 — Demo 2: Lens Live Translate.**

> Different person. Construction worker, Mumbai. Holds his phone over a Hindi hospital prescription label.
>
> Lens Live Translate. Real-time. The translation overlays the screen.
>
> Voice over: *"For the one and a half billion people without reliable internet. Dia reads the world, in any language, offline."*

**1:30 — Demo 3: Slate for a child.**

> A 9-year-old, rural classroom, no Wi-Fi visible. Writes "why is the sky blue?" in her notebook.
>
> Tap. Watch the AI write the answer back in cursive ink, beside her words, scaled to her hand.
>
> Voice over: *"For the children whose schools can't afford a tutor. Dia is a teacher who never logs off."*

**2:00 — The technical wow.**

> Quick montage. The Pilot agent autonomously navigating an app. Code overlay: `LiteRT-LM`. The accessibility tree streaming. Gemma 4 logo.
>
> Voice over (faster, confident): *"Dia runs entirely on the device. No cloud. No account. Every chat, every glance, every step — Gemma 4 thinking right here. Three gigabytes. Zero connection."*

**2:25 — Impact zoom out.**

> Camera zooms out from one phone to many. Hands holding phones in different parts of the world. No internet bars. Dia is alive in all of them.
>
> Voice over: *"There are four billion smartphones on Earth. Half of them, on most days, are not online. Until now, AI was a luxury for the connected."*
>
> Beat.
>
> *"Dia is the first one that works for everyone else."*

**2:55 — End card.**

> Black screen, white text:
>
> ```
> Dia. Offline AI. For everyone.
> github.com/<your-handle>/dia
> ```

### Production tips

- **Use real phones, real people, real locations.** Stock footage screams "demo." Take five hours of B-roll yourself.
- **Music must be soft, hopeful, not techno-bro.** Think `Spheres` by Olafur Arnalds, or anything from `Sea of Thieves` OST. Quiet enough that VO is always on top.
- **Captions on every demo step.** Many judges watch on mute the first pass.
- **Run the demos at real speed.** Speed-ramp slow steps from 1.5× to 2.5× to keep momentum, but never fake the result.
- **Cold-open the hook on grandma, end on the global zoom-out.** Frame the whole video as "from one person to billions."
- **Record in 1080p, deliver to YouTube unlisted, attach the public link.**

---

## The 1,500-word writeup structure

Use almost exactly this skeleton. Word counts are targets.

### Title (1 line)
> **Dia: The first fully offline, multi-feature AI assistant for Android — built on Gemma 4 + LiteRT-LM**

### Subtitle (1 line)
> *Chat, vision, autonomous control, on-screen guidance, and a handwriting notebook. No internet. No account. No bill.*

### Cover image
A single hero shot of the home screen with the mascot. Same shot you use for the YouTube thumbnail.

### 1. The problem (200 words)

Open with the same grandmother story as the video, in writing. Then add the four communities. End with: *"Today, every meaningful AI assistant is a thin client over a cloud API. Cut the wire and they fall silent. Dia is the only one that doesn't."*

### 2. What Dia is (200 words)

The seven features, one sentence each. Make it scannable. End with: *"All seven share a single Gemma 4 engine. Every byte of inference happens on the user's device."*

### 3. Architecture (350 words)

This is what the judges read to verify your code is real. Be specific:

- One-line app: Single Activity, Compose-only, Navigation3.
- The `DiaEngine` singleton: LiteRT-LM `Engine`, single conversation slot at a time, robust 7-attempt retry on the "session already exists" race condition you actually solved.
- The accessibility service: 250-node compact tree serializer, EDIT/TAP markers, gestures dispatched synchronously via `CountDownLatch`.
- Pilot's tool protocol: 14 tools, JSON I/O, brace-balanced streaming-aware extractor that survives output truncation, three-level stuck-detection (hint → strategy switch → forced submit).
- Guide's iterative single-step planner that auto-launches apps via PackageManager and only re-plans on real `TYPE_VIEW_CLICKED` events (not screen content changes — that was your premature-finish bug).
- Slate's hand-drawn glyph library + cursive connector strokes + adaptive scaling to user's handwriting size.

Drop a small architecture diagram (ASCII or actual). Link to `DOCUMENTATION.md` in your repo for depth.

### 4. How we use Gemma 4 (250 words)

This is the section the LiteRT track judges read. Hit:

- **Multimodal vision** — Slate sends rendered ink as a `Bitmap`; Lens Live Guide gets bounding-box-tagged answers; Lens Live Translate is text-extraction-only.
- **Tool-style prompting** — Pilot operates on a JSON tool protocol over plain prompting. We document the exact prompt; the model handles 14 distinct tools reliably with fuzzy name matching client-side for resilience.
- **Per-feature system prompts** — six different system instructions tuned for each feature's failure mode (e.g. Slate's "DO NOT describe the image, ANSWER directly" with negative examples).
- **Backend selection** — auto-fallback from GPU to CPU on init failure. We pin `maxNumTokens=4096` and trim our prompts to fit (`SCREEN_TREE_CHAR_BUDGET=1800` for Pilot).
- **LiteRT-LM** — explicitly call out the runtime and what it gave you over alternatives.

### 5. Challenges & decisions (200 words)

Judges love this. Pick four:

1. The `FAILED_PRECONDITION: A session already exists` race — how you solved it with synchronous wait + 7-retry exponential backoff.
2. Samsung One UI 6 overlay touch blocking — how you solved it with view-level `dispatchTouchEvent → false` + auto-hide-after-1.5s for Guide.
3. The Compose perf regression in Slate — `currentStroke = s` snapshot copy on every pointer sample. How you fixed it with the `liveStrokeTick` Int counter.
4. Token overflow in Pilot — how you fixed it with brace-balanced JSON extraction + EDIT-aware screen-tree trimming.

### 6. Real-world impact (200 words)

Restate the four communities in one paragraph each, with a number. Use only numbers you can defend.

### 7. What's next (100 words)

Tablet companion (mention briefly, don't promise). Voice barge-in on Chat. Local Ollama bridge for desktop. Don't promise things you didn't ship.

### Attachments

- Public code repo: `<github link>`
- Live demo: `<APK download link or Play Store internal track>`
- Video: YouTube unlisted

---

## Demo tasks that actually work — use these in the video

These are tasks where Gemma 4 reliably picks the right tool sequence on a 4B model. Pilot uses a normal LLM agent loop — system prompt + screen tree + tool list, model picks one JSON call per turn. No hardcoded scripts, no per-prompt routing. The reliability comes from a tight system prompt, the compound `search_in_app` tool (which is just a regular tool the model calls), and three-level stuck recovery (hint → strategy switch → forced submit).

The demos below are reliable because they're short (1-3 tool calls), have unambiguous targets, and exercise tools the model has clearly learned to call from the prompt examples.

### Pilot — the autonomy demo (use 2 of these, max 3)

**Tier 1 — Reliable on a fresh device:**

1. **"Open Swiggy and search for McDonald's"** — most cinematic, food appears, looks magical
2. **"Open Blinkit and search for Dairy Milk"** — Indian audience, fast app, clean results
3. **"Open Amazon and search for noise cancelling headphones"** — universal, big visual
4. **"Open Spotify and search for Taylor Swift"** — instantly understood
5. **"Open YouTube and search for Veritasium"** — works because YouTube has a real EditText
6. **"Open Settings and search for battery"** — boring but BULLETPROOF, never fails

**Tier 2 — Single-tool tasks:**

7. **"What's my battery"** — model calls `get_device_info(category=battery)` instantly
8. **"What time is it"** — same, good for showing the speech-to-text path
9. **"Go home"** / **"Press back"** — system_key, useful as filler
10. **"Open WhatsApp"** — single open_app, then cut

**Tier 3 — Risk only if you've tested it 5 times that day:**

- "Open Gmail and compose an email to X" — multi-step, model has to plan compose → To → body → send
- "Add to cart" tasks — works *sometimes* on Swiggy/Blinkit if the Add button is on screen and unambiguous; do NOT promise this in voice over
- Anything involving forms with multiple fields

**Do NOT show in the video:**

- Searching by voice with brand names that have phonetic ambiguity ("Cred" → "Kred")
- Tasks longer than 3 logical steps (model loses thread on 4B)
- Tasks where the target app has a paywall, login, or "skip intro" screen blocking the first action

### Lens Live — the offline-translation moment

Three modes, pick one for the demo:

11. **Translate mode on a Hindi/Spanish/Korean medicine bottle** — most emotional, ties to the migrant-worker story
12. **Translate mode on a foreign restaurant menu** — universally understood, cinematic
13. **Guide mode on a real object the user can't identify** — "what is this plant" / "what is this part" — shows the multimodal Gemma 4 in 5 seconds

Lens Live Translate mode answers in 2-3 seconds on most devices and never fails because it doesn't need accessibility tree, only the camera frame.

### Slate — the education moment

14. **Voice question: "Why is the sky blue?"** with Tutor mode ON — the Tutor prompt walks through it like a teacher. Most cinematic. Cursive output beside the question.
15. **Hand-write a math problem** like `7 × 8 = ?` — model handwrites `56` next to it. Visual punch.
16. **Hand-write "draw a triangle"** — Slate also draws shapes when prompted, looks like it understood the request.

### Screen Translate (floating bubble) — the on-device selectable translate

17. Open any foreign-language app/page → tap floating bubble → tap "Translate Screen" → drag selection over the foreign text. Translation comes back. **Test this 5 times the morning of recording** — it depends on the accessibility screenshot capability which can be flaky on Samsung One UI.

### Guide — the elderly user moment

18. **"How do I send a photo to my granddaughter?"** in WhatsApp — the cursor flies, captions appear, photo gets attached. This is the demo that wins the room emotionally. **Test it with WhatsApp open AND closed** — the auto-launch path needs WhatsApp to actually open before guide steps fire.

---

## Suggested 3-minute video shot list (final)

If you have 4 days and need to lock the script today:

| Time | What | Why it works |
|---|---|---|
| 0:00-0:15 | Grandma frustrated, then says "show me how to send a photo" | Emotional hook |
| 0:15-0:30 | Logo, "Meet Dia" | Brand drop |
| 0:30-1:00 | Guide demo #18 (WhatsApp photo) | Inclusivity track |
| 1:00-1:30 | Lens Live Translate demo #11 (medicine bottle) | Equity track |
| 1:30-2:00 | Slate demo #14 (kid asks why sky is blue, Tutor mode) | Education track |
| 2:00-2:20 | Pilot demo #1 (Swiggy McDonald's) — show real app navigation, accessibility tree overlay code in corner | Tech wow + main track |
| 2:20-2:45 | LiteRT-LM logo, Gemma 4 logo, "3 GB. zero connection." | LiteRT track |
| 2:45-3:00 | Globe zoom-out, "for everyone else" closing line | Emotional close |

Five demos, three tracks hit explicitly, every one of them a code path you can re-run on the day.

---



1. **A clean `README.md`** ✓ (already done)
2. **The `DOCUMENTATION.md` deep dive** ✓ (already done)
3. **A `LICENSE` file** — Apache 2.0 (matches what your README says)
4. **A `.github/SCREENSHOTS.md` or `media/` folder** with five hero screenshots
5. **A 30-second teaser GIF in the README** of one demo
6. **An issue template** so the repo looks alive
7. **A pre-built signed APK** in GitHub Releases for the "Live Demo" attachment

A judge spending 90 seconds in the repo should think "this is a real project."

---

## The cover image (the one Kaggle requires)

This is the thing every judge sees first when scrolling submissions. Spend two hours on it.

Recommendation: a phone screen showing the Dia home grid, with a soft purple-to-cyan gradient background, the headline `Offline AI for the next billion phones`, and a subtle `Built on Gemma 4 · LiteRT-LM` strip at the bottom. Single phone shot, no laptop, no clutter. 1920×1080, your YouTube thumbnail can reuse it.

---

## What you should NOT say in the pitch

These are credibility-killers:

- "AI-powered" / "revolutionary" / "next-generation" — say what it does
- "Disrupts" anything — show it
- "We are passionate about democratizing AI" — every project says this
- Mentioning any cloud LLM by name (the framing is "we don't need them")
- Promising tablet/laptop/wearable versions you haven't shipped — judges have heard a thousand of these
- Saying it works "for everyone" — pick three communities and own them

---

## Risk and mitigation

| Risk | Probability | Mitigation |
|---|---|---|
| Live demo crashes on stage | High | Pre-record everything. Live demo is for the judges later. |
| Pilot fails on a fresh app you haven't tested | Very high | Pick 2 hardcoded demo prompts and only show those. |
| Slate fails to read messy handwriting | Medium | Write demo questions in clean print, larger than usual, then claim it works on cursive (it does, sometimes). |
| YouTube takes down music | Low | Use royalty-free music from YouTube Audio Library. |
| Repo / live demo link rots between submission and judging | Low but fatal | Tag a release commit. Pin APK in GitHub Releases. |

---

## Day-by-day checklist (4 days)

### Day 1 — Polish, not features
- Add big-text accessibility toggle (2h)
- Add Translate & Save (1h)
- Add Slate Tutor toggle (30m)
- Run all 7 features end-to-end three times. Fix anything that breaks.

### Day 2 — The video
- Storyboard the 3-minute script with shot list
- Shoot all live action: grandma scene (use a relative or yourself in low light), translation scene, slate scene
- Capture all device screens with `adb shell screenrecord` at 1080p
- First rough cut

### Day 3 — Voice over + cover image + writeup draft
- Record VO in a quiet room. Re-record any line you don't like. (Tip: read each line three times, edit later.)
- Edit final video. Add captions to every demo step.
- Build the cover image.
- Draft the 1500-word writeup.

### Day 4 — Submission day
- Polish writeup, cut to ≤1500 words. Get one fresh pair of eyes.
- Upload video unlisted to YouTube. Verify thumbnail.
- Tag GitHub release. Build signed APK. Upload to Releases.
- Submit by 5:29 AM IST May 19. Don't wait until 5:28.

---

## A note on honesty

Don't fake demos. Judges run the code. If your video shows Pilot doing something the repo can't do, you're disqualified.

But: **showcase the best version of what you have**. Pick demo prompts you've tested. Shoot in good light. Use a clean phone with no notification spam. Set up your scenes. That's not faking; that's filmmaking.

---

## One last thing

When you write the closing line of your video, read it out loud first. If it doesn't make you slightly emotional, rewrite it.

Right now you have something most teams entering this hackathon don't have: a real, working multi-feature on-device assistant. The technology is there. What's left is the story.

Tell it well. The phone is in everybody's pocket. The next billion people are waiting for someone to make AI work for them too.

Make sure that someone is you.
