<div align="center">

# Dia

**Offline AI for everyone.**

A complete on-device AI companion for Android, powered by **Google's Gemma 4** running through **LiteRT-LM**. Eight AI experiences — chat, vision, automation, on-screen guidance, handwriting, voice, smart-home control, and a floating bubble — all sharing one local model. No cloud. No account. No bill.

```
Other apps:  Phone → Internet → Cloud API → Internet → Phone
Dia:         Phone → Gemma 4 → Phone
```

*Submitted to the Gemma 4 Good Hackathon · May 2026*

</div>

---

## Why Dia exists

Two and a half billion people are not online today. Networks fail. Disasters cut wires. Outages happen everywhere. Even in this age of AI, remote areas still have no signal.

Some people can't use a phone at all. A grandmother who can't find the camera button. A migrant worker who can't read the language on a medicine bottle. A child whose school can't afford a tutor.

Every meaningful AI assistant on Earth today is a thin client over a cloud API. Cut the wire and they fall silent.

Dia is the first one that doesn't.

---

## What Dia does

Dia is a single Android app hosting eight distinct AI experiences. Every experience shares one **on-device Gemma 4** engine — multimodal text, vision, audio, and tool-calling all from the same loaded model.

| Mode | What it does |
|------|--------------|
| **Chat** | Streaming chat with reasoning, audio dictation, image input, persistent history, model switching, and markdown rendering. |
| **Lens** | Pick any photo, ask anything. Vision-grounded answers, fully offline. |
| **Lens Live** | Real-time camera with **Think** (3 modes), **Translate**, and **Guide** sub-modes. Auto-triggers via accelerometer when you hold the phone still. |
| **Guide** | On-screen step-by-step tutor. Speak the goal, Dia overlays a glass cursor and walks you through any app. |
| **Pilot** | Autonomous phone automation. Describe a goal, Dia drives the apps. Orchestrated locally, with optional cloud Gemma for harder tasks. |
| **Slate** | Handwriting **Notebook** with multi-page local-saved books, plus a **Quiz** mode where Gemma grades scribbled answers visually. |
| **Home** | Voice-first assistant with TTS, STT, soft wake-word, and Home Assistant integration controlling any smart device. |
| **Bubble** | A draggable floating bubble over every app. Translate, summarise, answer, solve, or ask about any region of any screen. |

---

## A 2-billion-parameter model in your pocket

Dia is built around **Gemma 4 E2B** — the smallest multimodal Gemma 4. Not E4B. Not the 26B. Not the 31B. The 2B.

That's not a compromise. That's the whole point.

The 2B is the model that **actually runs on the phone in your pocket right now**. ~4 GB on disk after quantisation, ~3 GB resident in RAM during inference. It does not require a flagship phone. An 8 GB Samsung mid-range from three years ago is enough. That is the device most of the world owns.

If we had targeted a bigger model, this whole project would only have helped people who already had high-end phones — which is the opposite of why we built it.

Cloud is **opt-in**, hidden behind a Settings toggle, off by default. You can route to a 31B Gemma via **Ollama** (self-hosted), **OpenAI**, **OpenRouter**, **Gemini**, or **LM Studio** if you want to push a long-horizon Pilot task to a bigger brain. Most users won't need to. The 2B does the work.

This is the entire thesis of the project: **a 2-billion-parameter model, used well, beats a 31B model that needs a network for 95% of what people actually want a phone assistant to do.**

---

## Foundation: Gemma 4 + LiteRT-LM

Dia is built around a single **`DiaEngine`** singleton wrapping the LiteRT-LM `Engine` API. The engine is loaded once, lives at application scope, and is shared by every feature.

### LiteRT-LM as the inference runtime

We use `com.google.ai.edge.litertlm` directly. The engine wraps Gemma 4 `.litertlm` / `.task` weights and gives us:

- **Backend selection** — GPU first with automatic CPU fallback. Vision pinned to GPU where it pays off most; audio backend on CPU for stability.
- **Conversation state** — separate `Conversation` slots for Chat and Pilot so a long Pilot run never pollutes Chat history.
- **Streaming generation** — token-by-token callbacks so Chat renders markdown live and Pilot/Guide can cancel mid-thought.
- **Cancellation** — every feature can `cancelLensQuery()` / `cancelPilotSession()` cleanly without tearing down the engine.

Models are loaded from device storage. Drop a Gemma 4 `.litertlm` file in **Downloads** (or any folder) and the Model Setup screen lets you pick it. Validated against Gemma 4 E2B (multimodal, ~4 GB on disk).

### Multi-Token Prediction (MTP)

We turn on **`ExperimentalFlags.enableSpeculativeDecoding = true`** before every engine init and reset it right after. Per Google's LiteRT-LM Gemma 4 guidance, MTP gives a meaningful decode speedup on both GPU and CPU with no quality loss. Lens Live and Pilot's tool-call loops feel noticeably more "live" with MTP on.

```kotlin
ExperimentalFlags.enableSpeculativeDecoding = true
try { newEngine.initialize() } finally {
    ExperimentalFlags.enableSpeculativeDecoding = false
}
```

### GPU acceleration

Lens, all four Lens Live sub-modes, and Slate run vision through the **GPU backend** by default. On devices without OpenCL we fall back to CPU automatically without restarting the app.

### Process safety

Concurrent inits crashed JNI early in development. We solved it with one `ModelManager` singleton serializing every load/unload behind a `Mutex`, plus a 7-attempt exponential-backoff retry on the `FAILED_PRECONDITION: A session already exists` race that LiteRT-LM throws when two coroutines hit the engine at once.

---

## How we use Gemma 4's capabilities

### Reasoning (Thinking mode)

Chat exposes a **Thinking** toggle (configurable as default in Settings) that surfaces Gemma 4's reasoning trace alongside the final answer. Internally we pass `thinking = true` to the engine, capture both the thought and the response in separate streaming callbacks, and render the thought collapsibly above the answer with a different colour.

Lens Live Think also has its own Thinking button at the top — by default it returns terse direct answers, and Thinking-on switches to Gemma's deeper reasoning + a longer explanation.

### Function calling / tool calling

**Pilot is a full tool-calling agent.** We define 14 tools — `open_app`, `tap_node`, `find_and_tap`, `input_text`, `system_key`, `search_in_app`, `get_screen_info`, `get_device_info`, `take_screenshot`, `swipe`, `scroll`, `wait`, `open_url`, `finish` — register them in `ToolRegistry`, and prompt Gemma 4 with a JSON tool-call protocol. The model emits one JSON object per turn:

```json
{"tool": "search_in_app", "params": {"app": "Spotify", "query": "Taylor Swift"}}
```

A brace-balanced streaming-aware extractor parses the JSON even when output is truncated. Three-level stuck detection keeps the agent moving: hint nudge → strategy switch (force a different tool) → forced submit. The accessibility tree is trimmed to a 1,800-character budget so the prompt fits in 4,096 tokens.

The **Home** mode uses the same tool-calling pattern with HA-specific tools — `ha_call_service`, `ha_get_state`, `ha_list_entities`, `respond` — so Gemma 4 can decide whether to flip a switch, query state, list devices, or just answer.

### Multimodal image understanding

Five features push images directly into Gemma 4 as `Bitmap`s — no OCR, no preprocessing pipeline. Lens, all four Lens Live sub-modes, Slate, and Bubble + Screen Translate all use Gemma 4's native vision encoder. Slate renders user ink to a 1024-px crop and asks Gemma to read the handwriting; Bubble's region-select-then-ask flow captures any region of any app.

### Audio Scribe

Chat has an **Audio Scribe** mode — Gemma 4's official audio understanding capability. Hold the mic, speak, release. We capture 16 kHz / 16-bit mono PCM via `AudioRecord`, wrap it as a WAV with a 44-byte header (LiteRT-LM's miniaudio decoder needs the WAV container), and pass it as `Content.AudioBytes` directly to Gemma 4 — **no separate STT model in the pipeline.** Gemma 4 transcribes-and-responds in one shot, which means accents, slang, and cross-language speech all stay in the model's context. The result is blazing-fast voice chat that feels native to the model.

### Bounding-box grounding (Lens Live Guide)

Lens Live's Guide sub-mode asks Gemma 4 a question like *"where is the power button?"* over a camera frame. The system prompt is tuned to return both an answer **and** a normalised box:

```
The plug is in the bottom-right corner.
[BOX:0.62,0.71,0.94,0.96]
```

We parse the box, freeze the camera frame, and draw the spotlight overlay at the exact normalized coordinates. This is grounding without any custom detection model — pure Gemma 4.

### Per-feature system prompts

Every feature has its own tightly-scoped system prompt with negative examples — Lens Live Question's prompt forbids "the image shows" preambles; Slate insists on direct answers, not descriptions; Pilot enforces single-JSON output. Iterated against real device runs for the failure modes the small model gets wrong.

### Optional cloud routing

Dia is **offline by default**. As an opt-in, Settings has a Backend section where you can configure any OpenAI-compatible endpoint (Ollama for self-hosted, OpenAI, OpenRouter, Gemini, LM Studio). When configured and enabled, `BackendRouter` switches **all** requests to the cloud — the API surface for every feature stays identical so the call sites don't change. Pilot uses this hook to push the hardest tasks to a stronger cloud Gemma while keeping everything else local.

---

## Feature deep-dives

### Chat — `app/src/main/java/com/dia/app/ui/chat/`

> **Who it's for:** the widow living alone who wants to talk at 2 a.m. without paying anyone. The journalist in a censored country who can't trust her drafts to a server. The lawyer on a flight. The student in a rural classroom. Anyone who wants a thinking partner that doesn't bill, surveil, or ghost when the network drops.

A streaming chat UI on top of Gemma 4 with:

- **Audio Scribe** — speak instead of type, Gemma 4 hears your audio directly (no STT layer).
- **Persistent chat history** — every conversation saved to disk and indexed for the drawer; switch between past chats instantly.
- **Model switching** — swap between any local model on your phone (or to cloud, if configured) without losing the conversation.
- **Thinking mode** — Gemma 4's reasoning trace, rendered collapsibly above the answer.
- **Markdown + code** — rich rendering with syntax highlighting via RichText.
- **Read aloud** — tap the speaker on any reply for TTS playback.
- **Image input** — attach a photo and ask about it inline.
- **Per-message actions** — copy, regenerate, read aloud, retry on error.
- **Font scaling + auto-speak** — both controllable from Settings or the in-chat menu.

### Lens & Lens Live — `app/src/main/java/com/dia/app/ui/lens/` + `lenslive/`

> **Who it's for:** the migrant worker reading a foreign-language medicine bottle. The new parent worried about a rash. The traveller standing in front of a menu in another script. The visually-impaired user who needs the room described to them. The kid who wants to know what plant that is. The grandparent who can't find the power button on a strange remote.

**Lens** is the simple flow: pick a photo from gallery, type or speak a question, get an answer.

**Lens Live** binds CameraX to a single `PreviewView` and keeps the camera bound across sub-mode switches (rebinding caused the original "video pauses" stutter). It hosts three sub-modes:

**Think (3 modes — Describe / Answer / Solve).**
- *Describe* narrates the scene in front of the camera.
- *Answer* reads any visible question (MCQ, fill-in, open) and answers it.
- *Solve* reads any visible problem (math, code, logic) and works it out.
- A **Thinking** button at the top is off by default — terse, direct answers — and on-tap returns Gemma's deeper reasoning and a longer explanation.

**Translate.**
- Real-time text translation overlaid on the live preview.
- **Auto-translate / auto-speaker toggle** — let it loop continuously and speak each translation aloud, hands-free.
- **Language picker** — pick the target language (defaults to English).

**Guide.**
- Type or speak a question about your surroundings: *"Where is the power button?"*, *"What is this plant?"*, *"Help me find the red switch."*
- Gemma replies with a sentence **and** an annotation: a bounding box drawn over the frame to show what it identified.
- Tap to dismiss the box and resume live preview.

**Accelerometer auto-trigger.** All Think/Translate/Guide sub-modes use `Sensor.TYPE_ACCELEROMETER` to detect when the phone is held still. We compute `|magnitude − GRAVITY_EARTH|`; if it stays below 0.4 for 2.2 s, we auto-fire the query. A circular progress ring fills around the trigger button while the user is holding still so the trigger feels deliberate. Tap-to-fire works at any time. While a query is inflight the trigger flips to a red Stop button.

### Guide (on-screen) — `app/src/main/java/com/dia/app/guide/` + `ui/guide/`

> **Who it's for:** the grandmother who has owned a smartphone for nine years and never sent a photo. The first-time smartphone user, anywhere on Earth. The cognitively overwhelmed adult who just wants to do *one thing* without 47 menus. The dyslexic user. The blind user (with TTS captions on). Anyone who's ever called their grandkid because "it's not letting me press the green button."

Guide is an iterative single-step planner. The user speaks or types a goal (*"how do I send a photo on WhatsApp?"*); Pilot's planner picks the **next** step only, a foreground `GuideOverlayService` paints a green target highlight + a finger pointer + a caption (*"Tap the camera icon"*), and we wait for a real `TYPE_VIEW_CLICKED` event before re-planning. We do **not** re-plan on `TYPE_WINDOW_CONTENT_CHANGED` — that was the source of the premature-finish bug.

A live **plan + step-by-step** panel shows what Dia thinks the path forward looks like and which step you're on, so the user always knows what's coming.

The overlay uses view-level `dispatchTouchEvent → false` plus auto-hide-after-1.5s so it never blocks the user's tap on Samsung One UI. Big text and high contrast captions are wired through `LocalAccessibility`.

### Pilot — `app/src/main/java/com/dia/app/pilot/`

> **Who it's for:** the person with severe arthritis or RSI who can speak but can't reliably tap small buttons. The blind user who can't navigate a visual UI at all. The driver who needs to message a contact without picking up the phone. The parent juggling a baby. The professional whose hands need a break. Anyone who'd rather *say* what they want than *do* it.

The autonomous mode. Type or speak a task; Pilot opens apps, taps things, types, scrolls, all on its own. It surfaces a live **plan + step-by-step** view too, with every tool call and result streamed to the UI.

The agent loop:

1. Read the screen → produce a 250-node compact tree with EDIT / TAP / MIC / CAM markers.
2. Build the prompt: system instruction + task + screen tree + history (trimmed to fit 4,096 tokens).
3. Stream Gemma 4 → brace-balanced JSON extractor → `{tool, params}`.
4. Stuck-detection: if the same `(tool, params)` repeats N times, emit a hint, then a forced strategy switch, then bail.
5. Execute through `ToolRegistry`, observe the result, push it onto history, refresh the screen, repeat.

For harder multi-app tasks, Settings → Backend can route Pilot to **Ollama** (or any OpenAI-compatible endpoint) for a stronger cloud Gemma — you keep the local Pilot for everyday tasks and a beefier cloud version for the long-horizon ones. The choice is yours and one toggle away.

The agent runs as a foreground service (`PilotForegroundService`) so it survives screen-off and notification-shade interactions.

### Slate — `app/src/main/java/com/dia/app/slate/` + `ui/slate/`

> **Who it's for:** the 9-year-old in a classroom with no tutor. The teenager studying for an exam alone at home. The dyslexic adult who finds typing exhausting but can write. The engineer sketching a circuit. The right-brained learner who thinks better with a pen. Children, students, parents helping with homework, and anyone whose first language is handwriting.

A pressure-sensitive infinite handwriting canvas with pinch-zoom, page navigation, and a Material toolbar (pen / highlighter / eraser, five colours, four widths, page background cycle).

**Notes mode.**
- A whole **notebook** with multiple pages — add new pages on demand, navigate prev/next.
- All notebooks **save to local storage** automatically (autosave on dispose, page change, AI reply).
- Draw or write anything; tap the spark and Gemma reads the page and writes a reply back **in handwriting on the same page**, just below your strokes.
- A hand-drawn glyph library + cursive connector strokes scaled to your handwriting size — it feels like a teacher writing back, not a chat reply.

**Quiz mode — built for education.**
- Type any topic. Gemma 4 generates 10 questions, one per page.
- The user **scribbles or draws their answer** — single number, written word, sketch, equation, anything.
- Both the page (with the question text) and the user's drawing are sent to Gemma 4 for evaluation.
- **Answers don't have to be hardcoded.** *"4"*, *"four"*, *"FOUR"*, *"IV"*, even a quick sketch of four objects — Gemma's image understanding evaluates the user's intent, not exact-string matching. This is the demo that makes the **Future of Education** track click: a tutor that grades like a human, not a Scantron.
- Right answers get a green ✓; wrong ones get the canonical answer written back in red ink at the bottom of the page.

### Home — `app/src/main/java/com/dia/app/home/` + `ui/home/`

> **Who it's for:** the elderly grandparent living alone who wants to dim the lights without standing up — and without buying an Echo that listens to her all day. The privacy-conscious family that already runs Home Assistant and refuses to give Amazon and Google a constant feed of their living room. The disabled user who can't physically reach a switch. The household that just wants whole-home voice control on its own terms.

Home turns the phone into a voice room powered by Gemma 4. A big animated voice orb is the only control most users need: tap it, speak, get an answer.

- **STT** in (`SpeechRecognizer`) → Gemma 4 → **TTS** out (`DiaTts`). The full voice loop, on device.
- **Soft wake-word** — when enabled, a continuous listening loop fires on *"hey dia / hi dia / ok dia / dia."* The wake phrase is stripped from the command, so *"Hey Dia, turn off the bedroom light"* works in one breath. (A true low-power always-on wake-word model is on the roadmap.)
- **Home Assistant integration.** Configure URL + Long-Lived Access Token in Settings and Dia connects to your HA instance. Gemma 4 calls four HA tools — `ha_call_service`, `ha_get_state`, `ha_list_entities`, `respond` — over HA's REST API, which means **Dia can control any smart device that Home Assistant supports.** That's lights, switches, fans, locks, climate, media players, scenes, scripts, automations, blinds, vacuums — anything in HA's 2,000+ integration ecosystem.

A live entity carousel under the orb shows the controllable devices with their current state, and a tap toggles them.

### Bubble — `app/src/main/java/com/dia/app/screen/QuickActionService.kt`

> **Who it's for:** the student reading a long Wikipedia article who needs the gist. The traveller using a foreign-language airline app. The researcher buried in a PDF reader. The gamer who wants to know what an in-game item does. The person in any app, anywhere, who needs an answer about whatever's on screen *right now* — without copy-pasting, app-switching, or losing context.

A draggable floating bubble drawn over every other app via `TYPE_APPLICATION_OVERLAY`. Dia, anywhere — your buddy in any app. Tap the bubble for grouped actions:

- **Translate** — translate text on the current screen.
- **Summarize** — quick gist of what's on screen.
- **Answer** — answer any visible question.
- **Solve** — work out any visible problem.
- **Ask about screen** — *region first, then voice or type.* The user drags a rectangle, Dia captures and crops the bitmap, then waits for a spoken or typed question and feeds both to Gemma 4. The most flexible Bubble mode: ask anything about any region of any app, anywhere.

The bubble uses `AccessibilityService.takeScreenshot` (Android 11+) for the actual pixel capture. The result floats back as a centred overlay card.

---

## Settings & accessibility

Dia is built accessibility-first, with every setting one screen away.

**Backend** — Local only (default), or Cloud only with any OpenAI-compatible endpoint (Ollama, OpenAI, OpenRouter, Gemini, LM Studio). Cloud is fully optional, off by default, and the API surface stays identical for every feature. Most users will never need it; it exists for the user who wants to push a long-horizon Pilot task to a 31B Gemma.

**Model** — pick any `.litertlm` / `.task` from device storage. **Load** / **Unload** to free RAM. Auto-load-on-launch toggle.

**Chat** — Read responses aloud, **Show thinking by default**, font scale (Small / Default / Large), clear chat memory.

**Display & accessibility** — Big text (1.4× scale), Reduce motion (fewer animations), Auto-listen on Pilot/Guide open, Pilot speaks status (TTS announcements for blind users).

**Floating bubble** — show / hide.

**Quick launch** — persistent notification with one-tap shortcuts to Chat / Guide / Pilot. Asks for `POST_NOTIFICATIONS` automatically on Android 13+.

**Permissions manager** — one-tap deep-links to Accessibility, Notification listener, Display-over-other-apps system pages.

**Home Assistant** — wake-word toggle, HA URL, Long-Lived Access Token (masked).

**Help** — replay the first-launch **tour** any time. A 10-card walkthrough of every feature with illustrated previews and *"try saying"* example chips. Useful when a new family member picks up the phone for the first time.

**About** — Dia version, "Built with Gemma 4 + LiteRT-LM."

### First-launch tour

A swipeable 10-card pager introduces every feature in sequence — welcome → Chat → Lens → Lens Live → Guide → Pilot → Slate → Home → Bubble → "you're ready" — each card with a hand-drawn animated illustration of the feature, a tagline, a description, and three real example prompts (e.g. *"Order biryani on Swiggy"*, *"Where's the cat?"*, *"Turn off the bedroom light"*). Skippable, replayable, and the only piece of "marketing" inside the app.

---

## Architecture

```
                            ┌─────────────────────────┐
                            │     LiteRT-LM Engine    │
                            │   (Gemma 4 .litertlm)   │
                            │  GPU first, CPU fallback│
                            │   MTP / speculative dec.│
                            └──────────┬──────────────┘
                                       │
                              ┌────────┴────────┐
                              │   DiaEngine     │  app-scope singleton,
                              │ (Conversation)  │  serialised init/unload
                              └────────┬────────┘
                                       │
                              ┌────────┴────────┐
                              │ BackendRouter   │  Local / Cloud (Ollama, etc.)
                              └────────┬────────┘
                                       │
        ┌─────────┬──────────┬─────────┼────────┬─────────┬─────────┬────────┐
        │         │          │         │        │         │         │        │
      Chat     Lens    Lens Live    Guide    Pilot     Slate     Home    Bubble
        │         │          │         │        │         │         │        │
   AudioScribe Vision  Acc-trigger   Acc.   ToolReg.  Handwrite  HA REST  AccSS
                       Bounding box  tree                       +TTS+STT  +OCR
```

**Single Activity, Compose-only, Navigation3.** Every screen is a `@Composable`; navigation is a typed `NavDisplay` over a `mutableStateListOf<Any>`. `DiaApp.kt` is the entire root.

**Foreground services** for things that must survive process pressure: `PilotForegroundService`, `GuideOverlayService`, `ScreenTranslateService`, `QuickActionService`, `DiaQuickLaunchService`. All declared with `foregroundServiceType=specialUse` and the Android 14+ subtype property.

**Accessibility service** (`DiaAccessibilityService`) is the workhorse for Pilot, Guide, Bubble, and screen translate. Compact 250-node trees with EDIT / TAP / MIC / CAM markers, gestures dispatched synchronously via `CountDownLatch`, screenshots via `takeScreenshot()`. Declared with `android:isAccessibilityTool="true"` so Android 12+ doesn't auto-disable it, plus `flagRetrieveInteractiveWindows | flagReportViewIds | flagIncludeNotImportantViews | flagRequestTouchExplorationMode` for full coverage.

---

## Who Dia is for

A more honest answer than "everyone."

- **The 700 million elderly smartphone users** who never learned the apps. The grandmother who has owned a smartphone for nine years and never sent a photo. Guide takes her by the hand. Big text, high contrast, voice instructions. She didn't have to learn — and that's the point.
- **The 2.5 billion people without reliable internet.** Migrant workers reading medicine bottles in foreign languages. Refugees in transit. Farmers with one bar of signal. Students in rural classrooms. Lens Live Translate, Chat, Bubble — all of it, offline.
- **Children learning without tutors.** Slate writes the answer back in handwriting on the same page, scaled to your child's hand. Quiz mode grades scribbles like a human, not a Scantron.
- **Disabled users who can't navigate visual interfaces.** Blind users get spoken Pilot announcements and Guide narration. Motor-impaired users get auto-listen and Pilot's voice-driven autonomy. Low-vision users get big text + high contrast everywhere.
- **The privacy-conscious.** Journalists, lawyers, activists, doctors. Dia talks to nothing it doesn't have to. No telemetry. No accounts. No bills.
- **You, when the network drops.** A flight. A trail. A power cut. An outage. The 2 a.m. moment when you just want to think with something.

Dia is the AI for whoever the cloud forgot.

---

## Hardware & system requirements

| | Minimum | Recommended | Validated on |
|---|---------|-------------|--------------|
| Android | 8.0 (API 26) | 12+ (API 31) | 13, 14 |
| RAM | 6 GB | 8 GB+ | 8 GB & 12 GB |
| Storage | 4 GB free | 8 GB+ | |
| GPU | Optional (CPU fallback) | Adreno 730+ / Mali-G715+ | Adreno 740, 750 |

Validated end-to-end on **Samsung Galaxy S23 (8 GB)** and **Samsung Galaxy S24 Ultra (12 GB)**. CPU-only works on lower-end devices; GPU is faster.

---

## Engineering challenges

A few of the toughest fixes shipped in the final build:

1. **The `FAILED_PRECONDITION: A session already exists` race** — solved with a single `Mutex` in `ModelManager` plus 7-attempt exponential-backoff retry on every conversation init.
2. **Samsung One UI overlay touch blocking** in Guide — solved with view-level `dispatchTouchEvent → false` plus auto-hide-after-1.5s.
3. **Compose perf regression in Slate** — `currentStroke = s` snapshot copy on every pointer sample was killing frame rate. Fixed with a `liveStrokeTick` Int counter that bumps once per frame.
4. **Token overflow in Pilot** — brace-balanced JSON extraction (so truncated output still parses) plus EDIT-aware screen-tree trimming to a 1,800-char budget.
5. **Premature finish in Guide** — re-planning on `TYPE_WINDOW_CONTENT_CHANGED` made Guide jump ahead before the user tapped. Fixed by re-planning only on real `TYPE_VIEW_CLICKED` events.
6. **Camera stutter in Lens Live** — re-binding the camera on every sub-mode switch caused video pauses. Fixed by binding once at startup and keeping the same `PreviewView` across modes.

---

## What's next

We have a clear roadmap and prototypes for several of these:

- **True low-power wake word** — a dedicated always-on detector to replace the current `SpeechRecognizer`-based soft wake-word loop in Home mode.
- **Tablet companion with Home mode** — a tablet UI optimised for a kitchen/living-room dock to compete head-to-head with smart-home displays.
- **Laptop / desktop port via LiteRT-LM** — Chat, Guide, and a video-call mode running on Windows/macOS/Linux through LiteRT-LM or `.task` runtime.
- **Browser build** — prototyped on the LiteRT-LM JS runtime, the goal is "open the page, get Dia."
- **NPU support** — attempted on S23 and S24 Ultra; model compilation on-device is not currently feasible with the current toolchain. Tracking it for when LiteRT-LM ships first-class NPU paths.

---

## Build & run

```bash
git clone <this-repo>
cd dia
./gradlew app:assembleDebug
adb install app/build/outputs/apk/debug/app-debug.apk
```

You'll need a Gemma 4 `.litertlm` (or `.task`) file on the device. The Model Setup screen guides you through selecting one from device storage. **Recommended:** **Gemma 4 E2B multimodal** (~4 GB on disk, ~3 GB RAM at inference) — the same 2B model we built the entire project around. Bigger Gemmas work too if your device has the RAM, but the 2B is the one we've validated end-to-end across every feature.

A signed release APK is attached to the GitHub Releases page for one-tap install.

---

## Project layout

```
app/src/main/java/com/dia/app/
├── llm/              # DiaEngine, ModelManager, BackendRouter, ModelRegistry, AudioClip
├── pilot/            # PilotAgent, ToolRegistry, 14 tools, foreground service, cloud router
├── guide/            # GuideEngine, GuideOverlayService, pointer + caption + highlight overlays
├── slate/            # InkRenderer, HandwritingSynth, SlateAi, SlateState, persistence
├── home/             # HaClient (HA REST), HaTools, HomeModeEngine (wake word + tool-calling)
├── screen/           # QuickActionService (bubble), ScreenAssistant (screen-text actions)
├── translate/        # ScreenTranslateService, region selector, two-step ASK flow
├── voice/            # AudioScribeRecorder, DiaTts
├── ui/               # All Compose screens
├── navigation/       # Single-activity Compose nav (Navigation3)
└── prefs/            # SharedPreferences-backed StateFlows (DiaPrefs, AccessibilityPrefs)
```

---

## Privacy

- No telemetry. No analytics SDK. No crash reporter.
- Zero outbound network traffic unless you explicitly enable cloud routing **or** Home Assistant.
- All chat history, slate notebooks, and preferences live in app-private storage.
- The accessibility service is opt-in per Android's standard flow and only used by features you trigger.

---

## Documentation

Internal hackathon docs (architecture deep-dive, writeup, pitch, video script) live alongside this repo but are not part of the public tree.

---

## License

Apache 2.0

---

## Demo & Links

- **Demo Video (YouTube):** [https://youtu.be/ZhBGNFW86kw](https://youtu.be/ZhBGNFW86kw)
- **Feature Demos (Google Drive):** [https://drive.google.com/drive/folders/1ZwZ4Mq5t5MjJJ_cMFkLLsEhiGbVpFbVn](https://drive.google.com/drive/folders/1ZwZ4Mq5t5MjJJ_cMFkLLsEhiGbVpFbVn)

---

<div align="center">

**Dia. Offline AI. For everyone.**

Built on **Google's Gemma 4** + **LiteRT-LM** · Gemma 4 Good Hackathon · May 2026

</div>
