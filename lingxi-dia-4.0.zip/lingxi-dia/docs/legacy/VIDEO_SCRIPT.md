# Dia — Demo Video Script
## Gemma 4 Good Hackathon | 2:30–3:00 min

---

## PRODUCTION NOTES

**Format**: Screen recording (phone mirrored to PC) + voiceover narration  
**Tools needed**: scrcpy or Vysor for phone mirroring, OBS for recording, any mic  
**No actors needed**: The phone IS the actor. You narrate as if you're the user.  
**Music**: Soft ambient/electronic background (royalty-free — try Uppbeat or Pixabay)  
**Pacing**: Quick cuts. Never stay on one screen more than 8 seconds.  
**Resolution**: 1080p, 16:9 (phone centered with dark blurred background)

---

## THE SCRIPT

---

### SCENE 1 — THE HOOK (0:00–0:15)

**[VISUAL]**: Black screen → text fades in:  
> *"1.7 billion people have never used a smartphone."*  
> *"For them, every app is a maze."*

Then quick cut to Dia's home screen loading.

**[VOICEOVER]**:  
*"What if your phone could teach itself to you? What if AI didn't need the internet, didn't need your data, and didn't need you to type?"*

**[VISUAL]**: Dia home screen with the logo mark, status dot green next to "Gemma 4 ready"

---

### SCENE 2 — THE PROBLEM (0:15–0:30)

**[VISUAL]**: Quick montage of real scenarios (use stock footage or just text cards):
- Text card: "👵 Grandma wants to video call but can't find the button"
- Text card: "🧑‍🦯 A blind user gets a notification but can't read it"
- Text card: "🌍 A farmer in rural India needs to order medicine — no 4G"

**[VOICEOVER]**:  
*"Billions of people are locked out of the digital world. Not because they're not smart — because apps weren't built for them. Dia changes that. Eight AI modes, one offline brain, zero cloud dependency."*

---

### SCENE 3 — GUIDE (0:30–0:55) ⭐ LEAD WITH THIS

**[VISUAL]**: Open Guide mode → speak "Help me send a photo on WhatsApp" → show Dia's overlay appearing with the green highlight on the correct button, finger pointer pulsing, caption saying "Tap the camera icon"

**[HOW TO SHOOT]**: Actually run the Guide on your phone with WhatsApp. Let it highlight each step. Record 3-4 steps, speed up the middle ones in editing.

**[VOICEOVER]**:  
*"Guide mode. Say what you want to do, and Dia literally points at the screen — step by step. No reading manuals. No calling your grandson for help. Just follow the finger."*

**[VISUAL]**: Quick cut showing the high-contrast yellow highlight + big text caption for accessibility.

*"Big text, high contrast, haptic feedback — designed for people who need it most."*

---

### SCENE 4 — PILOT (0:55–1:15) ⭐ MOST IMPRESSIVE DEMO

**[VISUAL]**: Open Pilot → speak "Message Lakshya that I'll be 10 minutes late" → show Dia opening WhatsApp, searching the contact, typing the message, hitting send — all autonomously.

**[HOW TO SHOOT]**: Run the actual Pilot task. Speed up the waiting parts (2x). Keep the final "✓ Message sent" confirmation at normal speed.

**[VOICEOVER]**:  
*"Pilot mode. Tell Dia what to do, and it drives your phone for you. Send messages, make calls, open apps — hands-free. Powered by Gemma 4's tool-calling, running entirely on-device."*

**[VISUAL]**: Quick second demo — "Call mom" → show it opening dialer and calling.

---

### SCENE 5 — CHAT (1:15–1:30)

**[VISUAL]**: Open Chat → type or speak "Explain photosynthesis in simple words" → show Gemma responding with a clear, friendly answer. Show the thinking toggle.

**[HOW TO SHOOT]**: Pre-load a short prompt so the response is already generating when you start recording. Cut to the finished response.

**[VOICEOVER]**:  
*"Need to think something through? Chat mode — a private AI assistant that never leaves your phone. No account. No data collection. Just you and Gemma 4."*

---

### SCENE 6 — LENS + LENS LIVE (1:30–1:50)

**[VISUAL]**: 
1. Lens: Pick a photo of a plant/food → ask "What is this?" → show the answer
2. Lens Live: Point camera at your desk → show bounding boxes appearing around objects with labels

**[HOW TO SHOOT]**: For Lens Live Guide mode, point at something distinctive (a book, a cup, a plant). Show the real-time boxes.

**[VOICEOVER]**:  
*"Lens mode — point at anything and ask. Lens Live — real-time vision with object highlighting. 'Where's the power button?' Dia shows you. All processed on-device with Gemma 4's multimodal understanding."*

---

### SCENE 7 — SLATE (1:50–2:05)

**[VISUAL]**: Open Slate → scribble a math equation (like "2x + 4 = 10") with your finger → tap the AI button → show Dia reading the handwriting and solving it

**[HOW TO SHOOT]**: Write something simple and clear. The AI response should be visible within a few seconds. Speed up the inference wait.

**[VOICEOVER]**:  
*"Slate — a handwriting notebook with a built-in tutor. Scribble a problem, and Dia reads your writing and explains the answer. No keyboard needed. Perfect for students, or anyone who thinks better with a pen."*

---

### SCENE 8 — HOME + BUBBLE (2:05–2:20)

**[VISUAL]**:
1. Home Mode: Big animated voice orb in the centre. Toggle "Wake word" on. Say *"Hey Dia, turn off the bedroom light"* → orb pulses green → the bedroom-light tile flips off in real time.
2. Bubble: Show the floating bubble over a news article → tap → "Translate" → drag a region over a paragraph → translation appears.

**[HOW TO SHOOT]**: For Home, if you don't have HA set up, leave the wake-word toggle on and demo the orb pulsing through Listening → Thinking → Speaking, and let Dia answer "I can't reach Home Assistant yet" — that still proves the voice loop works. For Bubble, run it over any app. Both work offline.

**[VOICEOVER]**:
*"Home mode turns your phone into a voice assistant — wake word, Alexa-style, but every word stays on the device. Tie in Home Assistant and it controls your lights, locks, thermostat. And the floating Bubble gives you AI anywhere — translate, summarise, or ask about whatever's on screen, in any app."*

---

### SCENE 9 — THE TECH (2:20–2:35)

**[VISUAL]**: Quick text cards or a simple diagram:
- "Gemma 4 E4B → LiteRT-LM → On-device"
- "Zero cloud. Zero latency. Zero data leaks."
- "Accessibility-first: voice input, TTS, big text, haptics, overlays"
- Show the Settings screen with the green status dot next to "Gemma 4 ready" and the backend picker showing "Local only"

**[VOICEOVER]**:  
*"Under the hood: Gemma 4 running via LiteRT on a standard Android phone. No internet required. No API keys. No subscriptions. Eight AI modes from a single 4-billion parameter model that fits in your pocket."*

---

### SCENE 10 — THE CLOSE (2:35–2:50)

**[VISUAL]**: Back to Dia home screen. Mascot animation. Then fade to:
> *"Dia — Offline AI for everyone."*  
> *"Built with Gemma 4 + LiteRT-LM"*  
> *"Gemma 4 Good Hackathon · May 2026"*

**[VOICEOVER]**:  
*"Dia isn't for power users. It's for the people technology forgot. The grandmother who just wants to video call. The student with no WiFi. The person who needs their phone to just... help. That's Dia. Offline AI for everyone."*

**[MUSIC]**: Swell and fade.

---

## SHOOTING TIPS (NO ACTORS NEEDED)

### How to show "accessibility" without an actual elderly/disabled person:

1. **First-person POV**: YOU are the user. Narrate as if you're experiencing it for the first time. "I don't know where the button is... let me ask Dia."

2. **Hands-only shots**: Film just your hand holding the phone. Use your non-dominant hand or hold it slightly shakily to suggest an older user. Nobody sees your face.

3. **Text cards for context**: Before each demo, flash a card like:
   - "Scenario: First-time smartphone user"
   - "Scenario: No internet connection"
   - "Scenario: Visually impaired user"
   
   This frames the demo without needing an actor.

4. **Split screen**: Show the phone on one side, and a text description of the user scenario on the other.

5. **Zoom into accessibility features**: When showing Guide, zoom into the big-text caption, the yellow highlight, the haptic pulse icon. Let the UI speak for itself.

---

## RECORDING CHECKLIST

- [ ] Phone charged, notifications silenced, airplane mode ON (proves offline)
- [ ] Gemma 4 model pre-loaded (show the "✓ loaded" badge)
- [ ] WhatsApp has a test contact ready (for Pilot/Guide demos)
- [ ] A clear photo saved in gallery (for Lens demo)
- [ ] Slate has a blank notebook ready
- [ ] Bubble service enabled
- [ ] scrcpy running with phone mirrored to PC
- [ ] OBS recording at 1080p 60fps
- [ ] Mic tested, room quiet
- [ ] Background music track downloaded and ready

---

## EDITING STRUCTURE

| Timestamp | Scene | Duration |
|-----------|-------|----------|
| 0:00 | Hook (text cards) | 15s |
| 0:15 | Problem statement | 15s |
| 0:30 | Guide demo | 25s |
| 0:55 | Pilot demo | 20s |
| 1:15 | Chat demo | 15s |
| 1:30 | Lens + Lens Live | 20s |
| 1:50 | Slate demo | 15s |
| 2:05 | Home + Bubble | 15s |
| 2:20 | Tech summary | 15s |
| 2:35 | Closing | 15s |
| **Total** | | **~2:50** |

---

## KEY PHRASES TO HIT (for judges scanning)

These phrases should appear either spoken or on-screen:

- "Offline-first" / "No internet required"
- "On-device Gemma 4"
- "LiteRT-LM"
- "Accessibility-first design"
- "Digital equity"
- "Zero cloud dependency"
- "Tool-calling / function-calling"
- "Multimodal (vision + text + voice)"
- "Privacy by design"
- "For the people technology forgot"

---

## TRACK-SPECIFIC ANGLES TO EMPHASIZE

### For Digital Equity & Inclusivity ($10K) — YOUR STRONGEST SHOT:
- Lead with Guide mode (shows someone who can't navigate getting help)
- Emphasize: voice-first, no typing needed, big text, haptics
- Show airplane mode icon (proves offline)
- Mention: "works without WiFi, without accounts, without literacy"

### For Main Track ($50K):
- Show breadth: all 8 modes in action
- Emphasize technical depth: tool-calling, multimodal, on-device inference
- Show the Settings backend picker (local vs cloud architecture)

### For LiteRT Special Technology ($10K):
- Zoom into the model status badge
- Mention LiteRT-LM by name multiple times
- Show real inference happening (the "thinking..." state → response)
- Emphasize: "single 4B model powers all 8 modes"

---

## FINAL TIP

> **The video is NOT a feature tour. It's a STORY.**
> 
> The story is: "There are people who can't use their phones. Dia fixes that."
> 
> Every feature demo should connect back to that story.
> Don't say "here's our chat feature." Say "when you can't type, you speak."
> Don't say "here's Pilot." Say "when you can't navigate apps, Dia does it for you."
> 
> Problem → Solution → Proof. For every single scene.
