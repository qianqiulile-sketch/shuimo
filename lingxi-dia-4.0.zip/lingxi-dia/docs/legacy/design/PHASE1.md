# PHASE1.md

What we're building first. Nothing else.

Phase 1 is not about features. It's about making the foundation unbreakable before anything gets built on top of it.

---

## Goal

A working app that:
1. Takes all necessary permissions
2. Loads or downloads the model
3. Has a settings screen
4. Lands on a home screen with feature selection

No AI features yet. Just the skeleton. Solid.

---

## Screens

### 1. Onboarding — Permissions

Single screen. Request everything upfront. Explain why each one exists.

| Permission | Why | Request type |
|---|---|---|
| Microphone | Voice feature | `requestPermissions()` |
| Camera | Lens + Drive | `requestPermissions()` |
| Contacts | Pilot messaging | `requestPermissions()` |
| Storage / Media | Slate saves, Drive clips | `requestPermissions()` |
| SMS | Pilot can send texts | `requestPermissions()` |
| Accessibility Service | Guide + Pilot read and control screen | Deep link to Settings |
| Display Over Other Apps | Guide cursor overlay | Deep link to Settings |
| Notification Access | Read + manage notifications | Deep link to Settings |

Special permissions (Accessibility, Overlay, Notifications) can't be `requestPermissions()`'d — they need the user to go to Settings manually. Handle these with:
- "Tap to open Settings" button
- App polls `onResume()` to detect if permission was granted
- Visual tick when granted, still-pending state if not
- User can skip non-critical ones and grant later from Settings screen

Don't block app launch if non-critical permissions are skipped. Do block if Accessibility is skipped and user tries to open Guide or Pilot.

---

### 2. Model Setup

Shown after permissions. Two paths:

```
"Do you already have the model file on your device?"

  [ Yes, I have it ]          [ Download it ]
        ↓                           ↓
  File picker                 Show: 2.6GB, wifi warning
  (.litertlm only)            Progress bar + estimated time
  Validate file               Download from HuggingFace
  checksum check              ─────────────────────────
        ↓                     litert-community/
  Load model                  gemma-4-E2B-it-litert-lm
        ↓                           ↓
  Warmup inference            Save to app-specific storage
  (hidden, ~1 dummy call)     Validate checksum
        ↓                           ↓
  Home screen                 Load + warmup → Home screen
```

**On every subsequent launch:**
```
App opens
 ↓
Check stored model path exists and is valid
 ├── valid → load model → home screen
 └── missing/corrupt → back to model setup screen
```

No re-onboarding. Just model check.

**Model storage path:** app-specific external storage  
`/storage/emulated/0/Android/data/com.dia.app/files/models/`

No scoped storage issues. No extra permissions needed.

---

### 3. Settings Screen

Accessible from home screen top-right. Always available after onboarding.

```
Model
├── Current: Gemma 4 E2B  (2.6GB)
├── Path: /Android/data/.../gemma4-e2b.litertlm  [change]
├── Backend: [ Auto | GPU | CPU ]
└── Re-download model

Cloud Inference (optional)
├── [ ] Enable cloud fallback
├── Provider: [ Local only ▾ ]
│              OpenAI
│              Gemini
│              Groq
│              Ollama — Local Network
│              Ollama — Cloud
│              Custom
├── Base URL: ____________________
├── API Key:  [••••••••••••••]  (hidden, EncryptedSharedPreferences)
├── Model ID: ____________________
└── [Test Connection]

Permissions
├── Microphone          ● granted  (or  ✗ tap to fix)
├── Camera              ● granted
├── Accessibility       ● granted
├── Overlay             ● granted
├── Notifications       ● granted
├── Contacts            ● granted
└── Storage             ● granted

Debug
├── [ ] Show inference stats (tok/s, time to first token)
├── [ ] Show active skill in header
└── Clear conversation history

About
├── Version: 0.1.0
├── Model: Gemma 4 E2B (Apache 2.0)
└── GitHub / Licenses
```

---

### 4. Home Screen

Feature picker. Clean. Nothing else.

```
┌─────────────────────────────┐
│  Dia            [settings ⚙]│
│                              │
│   ┌──────┐  ┌──────┐        │
│   │ Chat │  │Voice │        │
│   └──────┘  └──────┘        │
│   ┌──────┐  ┌──────┐        │
│   │ Lens │  │Guide │        │
│   └──────┘  └──────┘        │
│   ┌──────┐  ┌──────┐        │
│   │Pilot │  │Slate │        │
│   └──────┘  └──────┘        │
│        ┌───────┐             │
│        │ Drive │             │
│        └───────┘             │
│                              │
│  ● Local  Gemma 4 E2B       │
│  ◌ Cloud  off               │
└─────────────────────────────┘
```

Bottom status bar shows: active inference mode + model loaded state.

Tapping a feature:
- Checks required permissions for that feature
- If missing → friendly prompt to grant, deep link to settings
- If granted → opens feature screen

---

## What Phase 1 Does NOT Include

- No actual AI inference in features (model just loads and warms up)
- No conversation history UI
- No memory system
- No tool execution
- No skill loading
- No voice pipeline
- No camera pipeline
- No accessibility automation

Phase 1 ends when: app installs, permissions are set, model loads, settings work, home screen shows all features. That's it.

---

## Success Criteria

- [ ] App installs clean on Android 10+
- [ ] All permissions requestable from onboarding screen
- [ ] Special permissions (Accessibility, Overlay, Notifications) deep-link correctly
- [ ] Model downloads from HuggingFace with progress shown
- [ ] Existing `.litertlm` file loadable via file picker
- [ ] Model loads and warms up silently on launch
- [ ] Settings screen saves/loads correctly including encrypted API key
- [ ] Cloud test connection returns success/fail correctly
- [ ] Home screen shows all 7 features
- [ ] Tapping locked feature (missing permission) shows correct prompt
- [ ] App survives: rotation, background kill, low memory, permission revocation

---

## Phase 2 Preview

After Phase 1 is solid:
- Chat feature (Gemma inference + conversation UI)
- Memory system (Room DB + session profile injection)
- Then: Voice, Lens, Guide, Pilot, Slate, Drive — one at a time
