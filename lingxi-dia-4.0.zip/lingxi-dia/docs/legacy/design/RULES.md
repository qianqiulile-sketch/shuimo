# RULES.md

Ground rules for building Dia. These don't change without a deliberate decision.

---

## Core Rules

### 1. One feature active at a time. Always.
No two features run simultaneously. Switching means full teardown of the current feature before loading the next. No shared resources, no background feature activity, no exceptions in Phase 1 and Phase 2.

### 2. Gemma must be doing real work.
If a feature works the same without Gemma being involved, it doesn't ship. Android APIs are the body. Gemma is the brain. The brain must be thinking, not just watching.

Examples of real Gemma work:
- Gemma reads UI tree and decides which node to target → Guide
- Gemma processes a voice clip and understands intent → Voice
- Gemma looks at an image and answers a question → Lens
- Gemma plans a sequence of tool calls to complete a task → Pilot

Examples of fake Gemma work (don't ship):
- A camera filter that applies effects (Gemma does nothing)
- A step counter (just sensors)
- A stopwatch (just system clock)

### 3. Tools are generic. Skills are the playbook.
Tools never have app-specific logic baked in. `tap(x, y)` doesn't know what app it's in. `send_message` doesn't know the messenger app's UI. That's what skills are for — they tell Gemma how to use generic tools for specific workflows.

If you're tempted to hardcode an app name or UI element into a tool, write a skill instead.

### 4. Only load skills for the active feature.
The context window is limited. A 2B model with 18 tool definitions gets confused. Only the skills needed by the currently active feature go into context. Nothing else.

### 5. Fail safe, always.
Especially in Pilot. If Gemma hallucinates a tool name, passes wrong params, or gets stuck — the app does nothing and tells the user, not crashes or executes something unintended.

```
invalid tool call → log it → tell user → stop
stuck loop (same screen twice) → go_back → retry once → stop
banking / payment UI detected → stop immediately
```

### 6. Thinking tokens never re-enter history.
When using Gemma's thinking mode in multi-turn sessions (Pilot especially), only the final answer goes back into conversation history. Never the thinking block. This is a silent failure mode that breaks multi-turn loops.

### 7. Cloud is opt-in. Local is default.
The app works fully offline after model download. Cloud settings exist for power users who want them. Cloud is never silently used as a fallback. If local fails, tell the user — don't quietly phone home.

### 8. No permissions are requested without explaining why.
Every permission request has a one-line plain-language explanation visible to the user before the system dialog appears. No dark patterns.

### 9. Memory stays on device.
User memories, conversation history, API keys — none of it leaves the device unless the user explicitly configures a cloud provider. API keys go in `EncryptedSharedPreferences`. Conversation history stays in Room DB. No analytics, no telemetry.

### 10. Phase discipline.
Don't build Phase 2 features during Phase 1. Finish what's scoped before expanding. A broken foundation with exciting features on top is just a broken app.

---

## Code Rules

### Kotlin only.
No Java interop unless a library forces it. Coroutines for async, not threads.

### One LiteRT session per model size, kept warm.
Don't recreate sessions on every inference call. Initialize once, reuse. Teardown only when the app is backgrounded for extended time or memory pressure is high.

### FeatureManager is the single source of truth for active feature.
Nothing else tracks which feature is active. Nothing else acquires hardware resources directly. Everything goes through FeatureManager.

### Validate before executing in Pilot.
Every tool call from Gemma passes through a validator before AccessibilityService touches the screen. Check: tool exists, params are the right type, target is not a sensitive UI zone.

### EncryptedSharedPreferences for anything sensitive.
API keys, user name, any personal config. Never plain SharedPreferences for these.

---

## Design Rules

### No feature gets a UI until its backend works.
Don't build the Guide cursor animation before the accessibility tree reading is solid. Don't build the Lens camera UI before the vision inference pipeline is tested. Backend first.

### Loading states are intentional, not spinners.
Cold start takes time on CPU. That's fine. Show something that feels intentional — a loading bar with a label, not just a spinner that looks like it's frozen.

### Permissions prompts are honest.
If a permission is required for a feature to work at all, say so. If it's optional, say so. Don't pretend optional is required.

### Feature tiles on home screen show lock state.
If a feature is missing a required permission, the tile shows a lock icon. Tap it → explains what's missing and deep-links to fix it. No silent broken features.

---

## What's Out of Scope (for now)

These are explicitly not being built yet. Don't start them early.

- Multi-feature concurrent execution
- Cross-device sync
- Cloud backup / restore
- Custom wake word ("Hey Dia")
- Wearable companion
- Dia on iOS
- Fine-tuning / custom model
- Community skill sharing / marketplace

When the core is solid and these make sense to add, they get a Phase doc and proper scoping. Not before.
