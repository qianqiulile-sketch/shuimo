# 水墨素材生成器

`app/src/main/res/drawable-nodpi/` 里的背景、头像、插画、笔触、宣纸纹理和启动图标，都是这两个脚本程序绘制的（无版权问题）。

想换个样子（比如换月亮位置、多画几只鸟）可以改脚本后重新生成：

```bash
pip install numpy scipy pillow
# 需要把马善政 / 钟齐志莽行字体放到当前目录（Google Fonts，SIL OFL）：
#   mashanzheng_MaShanZheng-Regular.ttf、zhimangxing_ZhiMangXing-Regular.ttf
python3 make_assets.py out                 # 全部生成到 out/
python3 make_assets.py out night wuji      # 只生成部分
SCALE=0.5 python3 make_assets.py prev      # 半尺寸快速预览
```

生成后把 `out/` 里的文件复制到 `app/src/main/res/drawable-nodpi/`（`ic_dia_logo.png` 放到 `drawable/`）。
