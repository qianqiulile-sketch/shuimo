"""
水墨江湖素材生成器（纯程序绘制，无版权问题）。
输出：背景（宣纸山水 / 江湖夜色 / 无极墨金）、侠客头像、空状态插画、笔触、宣纸纹理、启动图标。
"""
import math, os, sys
import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont, ImageChops
from scipy import ndimage

OUT = sys.argv[1] if len(sys.argv) > 1 else 'out'
os.makedirs(OUT, exist_ok=True)
RNG = np.random.default_rng(7)
FONT_BRUSH = 'mashanzheng_MaShanZheng-Regular.ttf'
FONT_CURSIVE = 'zhimangxing_ZhiMangXing-Regular.ttf'
FONT_SERIF = '/usr/share/fonts/opentype/noto/NotoSerifCJK-Bold.ttc'


# ───────────────────────── 基础噪声 ─────────────────────────

def value_noise(h, w, scale, rng):
    gh, gw = max(2, int(h / scale) + 2), max(2, int(w / scale) + 2)
    g = rng.random((gh, gw))
    z = ndimage.zoom(g, (h / (gh - 1) * 1.0001, w / (gw - 1) * 1.0001), order=3)
    return z[:h, :w]


def fbm(h, w, base, octaves, rng, gain=0.5):
    acc = np.zeros((h, w)); amp = 1.0; tot = 0.0; s = base
    for _ in range(octaves):
        acc += amp * value_noise(h, w, s, rng); tot += amp
        amp *= gain; s = max(2, s / 2)
    return acc / tot


def noise1d(n, base, octaves, rng):
    acc = np.zeros(n); amp = 1.0; tot = 0; s = base
    for _ in range(octaves):
        k = max(2, int(n / s) + 2)
        g = rng.random(k)
        x = np.linspace(0, k - 1, n)
        acc += amp * np.interp(x, np.arange(k), g); tot += amp
        amp *= 0.5; s = max(2, s / 2)
    return acc / tot


def smooth1d(a, sigma):
    return ndimage.gaussian_filter1d(a, sigma)


# ───────────────────────── 宣纸 ─────────────────────────

def paper(h, w, base=(244, 238, 223), rng=RNG, fiber=True, strength=1.0):
    img = np.ones((h, w, 3)) * np.array(base, float)
    lum = (fbm(h, w, 300, 4, rng) - 0.5) * 14 * strength
    img += lum[..., None]
    grain = (rng.random((h, w)) - 0.5) * 6 * strength
    img += grain[..., None]
    if fiber:
        f = np.zeros((h, w))
        n = int(h * w / 2500)
        ys = rng.integers(0, h, n); xs = rng.integers(0, w, n)
        L = rng.integers(8, 40, n); ang = rng.random(n) * math.pi
        for y, x, l, a in zip(ys, xs, L, ang):
            for t in range(l):
                yy = int(y + t * math.sin(a)); xx = int(x + t * math.cos(a))
                if 0 <= yy < h and 0 <= xx < w: f[yy, xx] += 1
        f = ndimage.gaussian_filter(f, 0.7)
        img -= (f * 10 * strength)[..., None]
    # 四周略暗（陈年宣纸）
    yy, xx = np.mgrid[0:h, 0:w]
    d = np.sqrt(((xx - w / 2) / (w / 2)) ** 2 + ((yy - h / 2) / (h / 2)) ** 2)
    img -= (np.clip(d - 0.7, 0, 1) * 22 * strength)[..., None] * np.array([1, 1.05, 1.3])
    return np.clip(img, 0, 255)


def composite(img, color, alpha):
    """把颜色 color 按 alpha(0..1, HxW) 叠到 img 上。"""
    a = np.clip(alpha, 0, 1)[..., None]
    return img * (1 - a) + np.array(color, float) * a


# ───────────────────────── 山 ─────────────────────────

def mountain_layer(h, w, base_y, amp, scale, rng, peaks=None, rough=1.0):
    """返回该层山的 alpha（山体浓淡已含墨色由脊线往下变淡的效果）。"""
    prof = noise1d(w, scale, 5, rng)
    prof = (prof - prof.min()) / (prof.max() - prof.min() + 1e-9)
    ridge = base_y - prof * amp
    if peaks:
        xs = np.arange(w)
        for (px, ph, pw) in peaks:
            ridge -= ph * np.exp(-((xs - px * w) / (pw * w)) ** 2)
    ridge = smooth1d(ridge, 2)
    yy = np.arange(h)[:, None]
    depth = (yy - ridge[None, :])  # >0 在山体内
    inside = depth > 0
    # 墨色：脊线处最浓，往下迅速变淡（留白成雾）
    fall = np.exp(-np.clip(depth, 0, None) / (amp * 0.55 + 30))
    tex = fbm(h, w, 60, 5, rng)  # 皴法纹理
    streak = value_noise(h, w, 18, rng)
    a = inside * (0.35 + 0.65 * fall) * (0.75 + 0.5 * (tex - 0.5) * rough) * (0.85 + 0.3 * streak)
    # 脊线浓墨边
    edge = np.exp(-(np.clip(depth, 0, None) / 5.0) ** 2) * inside
    a = np.maximum(a, edge * 0.9)
    # 底部被云雾吃掉
    mist = np.clip((yy - (ridge.max() + amp * 0.15)) / (amp * 1.2 + 60), 0, 1)
    a *= (1 - mist * 0.95)
    a = ndimage.gaussian_filter(a, 1.2)
    return np.clip(a, 0, 1), ridge


def mist_band(h, w, y, thick, rng, strength=0.85):
    yy = np.arange(h)[:, None]
    n = fbm(h, w, 220, 3, rng)
    band = np.exp(-((yy - y - (n - 0.5) * thick * 0.8) / thick) ** 2)
    return np.clip(band * strength * (0.7 + 0.6 * n), 0, 1)


# ───────────────────────── 人物 / 松 / 鸟 / 月 ─────────────────────────

def swordsman_mask(size=1200, facing=1):
    """斗笠侠客背影（站立，披风随风扬起，背负长剑）。返回 L 模式 alpha。"""
    S = size
    im = Image.new('L', (S, S), 0)
    d = ImageDraw.Draw(im)
    cx = S * 0.5
    f = facing
    # 剑（斜背，剑柄露在左肩上方）
    d.line([(cx - f * S * 0.16, S * 0.20), (cx + f * S * 0.12, S * 0.62)], fill=255, width=int(S * 0.012))
    d.line([(cx - f * S * 0.185, S * 0.215), (cx - f * S * 0.135, S * 0.185)], fill=255, width=int(S * 0.02))  # 护手
    d.ellipse([cx - f * S * 0.205 - S * 0.012, S * 0.155, cx - f * S * 0.205 + S * 0.012, S * 0.18], fill=255)  # 剑穗头
    # 剑穗
    for k in range(3):
        d.line([(cx - f * S * 0.205, S * 0.17), (cx - f * S * (0.28 + k * 0.015), S * (0.26 + k * 0.02))], fill=255, width=int(S * 0.004))
    # 斗笠
    hat_y = S * 0.255
    d.polygon([(cx - S * 0.20, hat_y + S * 0.035), (cx + S * 0.20, hat_y + S * 0.035), (cx + S * 0.012, hat_y - S * 0.075), (cx - S * 0.012, hat_y - S * 0.075)], fill=255)
    d.ellipse([cx - S * 0.205, hat_y + S * 0.02, cx + S * 0.205, hat_y + S * 0.05], fill=255)
    # 头 / 颈
    d.ellipse([cx - S * 0.045, hat_y + S * 0.02, cx + S * 0.045, hat_y + S * 0.11], fill=255)
    # 身体（长袍）
    body = [
        (cx - S * 0.10, S * 0.36), (cx + S * 0.10, S * 0.36),
        (cx + S * 0.13, S * 0.55), (cx + S * 0.16, S * 0.80), (cx + S * 0.09, S * 0.83),
        (cx - S * 0.09, S * 0.83), (cx - S * 0.15, S * 0.80), (cx - S * 0.13, S * 0.55),
    ]
    d.polygon(body, fill=255)
    # 披风（向一侧扬起的飘带形）
    cape = []
    for t in np.linspace(0, 1, 40):
        x = cx + f * (S * 0.08 + t * S * 0.42)
        y = S * 0.36 + t * S * 0.18 + math.sin(t * 7) * S * 0.025
        cape.append((x, y))
    for t in np.linspace(1, 0, 40):
        x = cx + f * (S * 0.10 + t * S * 0.36)
        y = S * 0.48 + t * S * 0.30 + math.sin(t * 6 + 1) * S * 0.03
        cape.append((x, y))
    d.polygon(cape, fill=255)
    # 腿 / 靴
    d.polygon([(cx - S * 0.07, S * 0.82), (cx - S * 0.02, S * 0.82), (cx - S * 0.03, S * 0.93), (cx - S * 0.09, S * 0.93)], fill=255)
    d.polygon([(cx + S * 0.02, S * 0.82), (cx + S * 0.07, S * 0.82), (cx + S * 0.10, S * 0.93), (cx + S * 0.04, S * 0.93)], fill=255)
    # 腰带飘带
    for k in range(2):
        pts = [(cx + f * S * 0.06, S * (0.50 + k * 0.01))]
        for t in np.linspace(0, 1, 20):
            pts.append((cx + f * (S * 0.06 + t * S * 0.26), S * (0.50 + k * 0.02) + t * S * 0.05 + math.sin(t * 9 + k) * S * 0.012))
        d.line(pts, fill=255, width=int(S * 0.008))
    a = np.asarray(im, float) / 255
    # 墨韵：边缘晕开 + 干笔飞白
    rng = np.random.default_rng(3)
    rough = fbm(S, S, 25, 4, rng)
    a = ndimage.gaussian_filter(a, S * 0.0025)
    a = np.clip((a - 0.35 + (rough - 0.5) * 0.35) * 3.2, 0, 1)
    dry = value_noise(S, S, 40, rng)
    a *= np.clip(0.97 + (dry - 0.5) * 0.08, 0, 1)
    return a


def pine_mask(w, h, rng, origin=(0.0, 0.15), direction=1):
    """从画面边缘伸出的一枝古松：虬曲枝干 + 层层扁平的松针团。"""
    S = 2
    im = Image.new('L', (w * S, h * S), 0)
    d = ImageDraw.Draw(im)
    ox, oy = origin[0] * w * S, origin[1] * h * S
    pads = []

    def limb(x, y, ang, length, width, depth):
        steps = 14
        px, py = x, y
        for i in range(steps):
            ang += (rng.random() - 0.5) * 0.30 + 0.025
            nx = px + math.cos(ang) * length / steps * direction
            ny = py + math.sin(ang) * length / steps
            wdt = max(2, int(width * (1 - i / steps * 0.55)))
            d.line([(px, py), (nx, ny)], fill=255, width=wdt)
            d.ellipse([nx - wdt / 2, ny - wdt / 2, nx + wdt / 2, ny + wdt / 2], fill=255)
            if depth > 0 and i in (5, 10) and rng.random() < 0.9:
                limb(nx, ny, ang + (0.45 + rng.random() * 0.4) * (1 if i == 10 else -1), length * 0.42, width * 0.45, depth - 1)
            if i in (7, 13):
                pads.append((nx, ny, length * 0.32 + 30 * S))
            px, py = nx, ny
        pads.append((px, py, length * 0.38 + 34 * S))

    limb(ox, oy, -0.22, w * S * 0.80, w * S * 0.045, 2)
    # 松针团：扁平、上密下疏的扇形短笔
    for (x, y, r) in pads:
        for c in range(2):
            cx = x + (rng.random() - 0.5) * r * 0.5
            cy = y - r * 0.12 + (rng.random() - 0.5) * r * 0.15
            n = 110
            for k in range(n):
                a = math.pi - 0.25 + (k / (n - 1)) * (math.pi + 0.5) + (rng.random() - 0.5) * 0.08
                rr = r * (0.45 + 0.55 * rng.random())
                x2 = cx + math.cos(a) * rr
                y2 = cy + math.sin(a) * rr * 0.42
                d.line([(cx + math.cos(a) * rr * 0.15, cy + math.sin(a) * rr * 0.06), (x2, y2)], fill=255, width=2 * S)
    im = im.resize((w, h), Image.LANCZOS)
    a = np.asarray(im, float) / 255
    tex = value_noise(h, w, 4, rng)
    a = np.clip(a * (0.85 + 0.3 * tex) * 1.15, 0, 1)
    return ndimage.gaussian_filter(a, 0.6)


def bamboo_mask(w, h, rng, stalks=3):
    """几竿墨竹：竹节 + 成簇的竹叶。"""
    S = 2
    im = Image.new('L', (w * S, h * S), 0)
    d = ImageDraw.Draw(im)
    for k in range(stalks):
        x0 = w * S * (0.06 + k * 0.10 + rng.random() * 0.04)
        lean = (rng.random() * 0.12 + 0.03) * w * S
        top = h * S * (0.05 + rng.random() * 0.25)
        width = w * S * (0.018 - k * 0.003)
        segs = 7 + k
        prev = (x0, h * S)
        for i in range(1, segs + 1):
            t = i / segs
            y = h * S - (h * S - top) * t
            x = x0 + lean * t ** 1.5
            gap = width * 0.35
            d.line([prev, (x, y + gap)], fill=255, width=int(width * (1 - t * 0.45)))
            # 竹节：两小笔
            d.line([(x - width * 0.6, y + gap * 0.3), (x + width * 0.6, y - gap * 0.2)], fill=255, width=max(2, int(width * 0.18)))
            prev = (x, y - gap * 0.2)
            # 竹叶：在上半段的节上长出一簇
            if t > 0.35 and rng.random() < 0.75:
                side = -1 if rng.random() < 0.5 else 1
                for j in range(3 + int(rng.random() * 3)):
                    L = w * S * (0.10 + rng.random() * 0.08)
                    ang = (0.35 + rng.random() * 0.9) * (1 if side > 0 else -1) + (0 if side > 0 else math.pi)
                    ang += (j - 1) * 0.28 * side
                    bx, by = x, y
                    ex, ey = bx + math.cos(ang) * L, by + abs(math.sin(ang)) * L * 0.75 + L * 0.15
                    mx, my = (bx + ex) / 2, (by + ey) / 2
                    nx, ny = -(ey - by), (ex - bx)
                    nn = math.hypot(nx, ny) + 1e-6
                    wid = L * 0.11
                    p1 = (mx + nx / nn * wid, my + ny / nn * wid)
                    p2 = (mx - nx / nn * wid, my - ny / nn * wid)
                    q1 = (bx + (mx - bx) * 0.35 + nx / nn * wid * 0.7, by + (my - by) * 0.35 + ny / nn * wid * 0.7)
                    q2 = (bx + (mx - bx) * 0.35 - nx / nn * wid * 0.7, by + (my - by) * 0.35 - ny / nn * wid * 0.7)
                    d.polygon([(bx, by), q1, p1, (ex, ey), p2, q2], fill=255)
    im = im.resize((w, h), Image.LANCZOS)
    a = np.asarray(im, float) / 255
    a *= 0.8 + 0.4 * value_noise(h, w, 6, rng)
    return np.clip(ndimage.gaussian_filter(a, 0.7), 0, 1)


def birds_mask(w, h, rng, n=5, region=(0.55, 0.12, 0.35, 0.12), size=22):
    im = Image.new('L', (w, h), 0)
    d = ImageDraw.Draw(im)
    rx, ry, rw, rh = region
    for i in range(n):
        x = (rx + rng.random() * rw) * w
        y = (ry + rng.random() * rh) * h
        s = size * (0.6 + rng.random() * 0.7)
        d.line([(x - s, y - s * 0.25), (x - s * 0.4, y - s * 0.45), (x, y)], fill=255, width=3)
        d.line([(x, y), (x + s * 0.45, y - s * 0.5), (x + s * 1.05, y - s * 0.2)], fill=255, width=3)
    a = ndimage.gaussian_filter(np.asarray(im, float) / 255, 0.9)
    return np.clip(a * 1.4, 0, 1)


def disc(h, w, cx, cy, r, soft=2.0):
    yy, xx = np.mgrid[0:h, 0:w]
    dd = np.sqrt((xx - cx) ** 2 + (yy - cy) ** 2)
    return np.clip((r - dd) / soft, 0, 1)


def halo(h, w, cx, cy, r):
    yy, xx = np.mgrid[0:h, 0:w]
    dd = np.sqrt((xx - cx) ** 2 + (yy - cy) ** 2)
    return np.exp(-(np.clip(dd - r, 0, None) / (r * 1.4)) ** 2)


def place(canvas_alpha, mask, x, y, scale=1.0):
    """把 mask（0..1）缩放后放到 canvas_alpha 的 (x,y)（左上角）。"""
    m = Image.fromarray((mask * 255).astype(np.uint8))
    if scale != 1.0:
        m = m.resize((max(1, int(m.width * scale)), max(1, int(m.height * scale))), Image.LANCZOS)
    a = np.asarray(m, float) / 255
    H, W = canvas_alpha.shape
    x0, y0 = int(x), int(y)
    x1, y1 = min(W, x0 + a.shape[1]), min(H, y0 + a.shape[0])
    sx, sy = max(0, -x0), max(0, -y0)
    if x1 <= max(0, x0) or y1 <= max(0, y0):
        return canvas_alpha
    canvas_alpha[max(0, y0):y1, max(0, x0):x1] = np.maximum(
        canvas_alpha[max(0, y0):y1, max(0, x0):x1], a[sy:sy + (y1 - max(0, y0)), sx:sx + (x1 - max(0, x0))])
    return canvas_alpha


def seal_image(text, size=120, color=(181, 55, 43), font=FONT_SERIF, rng=RNG):
    """朱砂印：方形红底、阴刻白字、边缘斑驳。"""
    S = size * 3
    im = Image.new('RGBA', (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    d.rounded_rectangle([S * 0.04, S * 0.04, S * 0.96, S * 0.96], radius=S * 0.08, fill=color + (255,))
    n = len(text)
    if n <= 1:
        ft = ImageFont.truetype(font, int(S * 0.62))
        bb = d.textbbox((0, 0), text, font=ft)
        d.text(((S - (bb[2] - bb[0])) / 2 - bb[0], (S - (bb[3] - bb[1])) / 2 - bb[1]), text, font=ft, fill=(255, 246, 234, 255))
    else:
        # 两字竖排 / 四字两列（印章从右往左读）
        cols = [text[i:i + 2] for i in range(0, n, 2)][::-1] if n > 2 else [text]
        ft = ImageFont.truetype(font, int(S * (0.38 if n > 2 else 0.36)))
        cw = S * 0.84 / len(cols)
        for ci, col in enumerate(cols):
            for ri, ch in enumerate(col):
                bb = d.textbbox((0, 0), ch, font=ft)
                x = S * 0.08 + ci * cw + (cw - (bb[2] - bb[0])) / 2 - bb[0]
                y = S * 0.08 + ri * S * 0.42 + (S * 0.42 - (bb[3] - bb[1])) / 2 - bb[1]
                d.text((x, y), ch, font=ft, fill=(255, 246, 234, 255))
    a = np.asarray(im).astype(float)
    # 斑驳：随机侵蚀
    er = fbm(S, S, 14, 3, rng)
    keep = np.clip((er - 0.22) * 6, 0, 1)
    a[..., 3] *= keep
    out = Image.fromarray(np.clip(a, 0, 255).astype(np.uint8), 'RGBA').resize((size, size), Image.LANCZOS)
    return out


def brush_stroke(w=1400, h=120, rng=RNG):
    """横向干笔一笔：起笔重、收笔飞白。返回 alpha。"""
    yy, xx = np.mgrid[0:h, 0:w].astype(float)
    t = xx / w
    center = h * 0.5 + np.sin(t * 3.0) * h * 0.06
    thick = h * 0.36 * (0.55 + 0.45 * np.sin(np.clip(t, 0, 1) * math.pi) ** 0.6) * (1.15 - 0.3 * t)
    body = np.clip((thick - np.abs(yy - center)) / 3.0, 0, 1)
    bristle = value_noise(h, w, 3, rng)
    streaks = ndimage.gaussian_filter1d(rng.random((h, 1)).repeat(w, 1), 0.6, axis=0)
    dry = np.clip((streaks - (0.15 + 0.75 * t ** 2)) * 4, 0, 1)
    a = body * (0.55 + 0.45 * dry) * (0.85 + 0.3 * bristle)
    # 起笔圆头
    head = disc(h, w, w * 0.035, h * 0.5, h * 0.22, 6)
    a = np.maximum(a, head * 0.85)
    return np.clip(a, 0, 1)


def save_rgb(arr, name, q=82):
    Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8)).save(os.path.join(OUT, name), quality=q, method=6)


def save_alpha(a, name, color=(0, 0, 0)):
    h, w = a.shape
    rgba = np.zeros((h, w, 4), np.uint8)
    rgba[..., :3] = color
    rgba[..., 3] = np.clip(a * 255, 0, 255).astype(np.uint8)
    Image.fromarray(rgba, 'RGBA').save(os.path.join(OUT, name), optimize=True)
