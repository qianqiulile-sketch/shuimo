"""
「水墨太极」主题包生成器（纯程序绘制，无版权问题）。

生成一个完整的灵犀主题包（.lxtheme）：
  theme.json        配色 + 图片 + 全部图标位
  images/           对话背景（宣纸 · 水墨太极 · 八卦 · 远山）、功能页背景（墨夜太极）、头像、插画、笔触、纸纹
  icons/            约 110 个图标：毛笔字 + 干笔圆相 / 朱砂印 / 太极

用法：
  pip install numpy scipy pillow
  python3 make_taiji_theme.py out_dir            # 生成到 out_dir/taiji/ 并打包 out_dir/水墨太极.lxtheme
  SCALE=0.5 python3 make_taiji_theme.py prev     # 半尺寸快速预览
"""
import json, math, os, sys, zipfile
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter
from scipy import ndimage

HERE = os.path.dirname(os.path.abspath(__file__))
sys.argv = [sys.argv[0], os.path.join(sys.argv[1] if len(sys.argv) > 1 else 'out', '_tmp')] + sys.argv[2:]
import inkart as K  # noqa: E402

OUT_ROOT = os.path.dirname(K.OUT)
DST = os.path.join(OUT_ROOT, 'taiji')
os.makedirs(os.path.join(DST, 'images'), exist_ok=True)
os.makedirs(os.path.join(DST, 'icons'), exist_ok=True)

SCALE = float(os.environ.get('SCALE', '1'))
W, H = int(1080 * SCALE), int(2340 * SCALE)
BRUSH = os.path.join(HERE, '..', '..', 'app', 'src', 'main', 'res', 'font', 'mashanzheng.ttf')
SERIF = '/usr/share/fonts/opentype/noto/NotoSerifCJK-Bold.ttc'
INK = (27, 23, 20)
RED = (163, 52, 43)
PAPER = (242, 237, 226)


# ───────────────────────── 太极 ─────────────────────────

def taiji_alpha(h, w, cx, cy, R, rng, wash=True):
    """返回 (阴（黑）区域 alpha, 外圈干笔 alpha)。阴区带水墨晕染。"""
    yy, xx = np.mgrid[0:h, 0:w].astype(float)
    dx, dy = xx - cx, yy - cy
    r = np.sqrt(dx ** 2 + dy ** 2)
    upper = np.sqrt(dx ** 2 + (dy + R / 2) ** 2) < R / 2
    lower = np.sqrt(dx ** 2 + (dy - R / 2) ** 2) < R / 2
    # 左黑右白：左半圆 + 下小圆 - 上小圆
    yin = (((dx < 0) | lower) & ~upper & (r < R)).astype(float)
    # 鱼眼
    eye_r = R * 0.13
    yin = np.maximum(yin * (1 - K.disc(h, w, cx, cy + R / 2, eye_r, 2)), K.disc(h, w, cx, cy - R / 2, eye_r, 2))
    if wash:
        # 水墨晕染：边缘渗化 + 浓淡
        soft = ndimage.gaussian_filter(yin, R * 0.012 + 1)
        tex = K.fbm(h, w, max(4, R * 0.25), 5, rng)
        bleed = ndimage.gaussian_filter(yin, R * 0.05 + 1) * (0.35 + 0.5 * tex)
        yin = np.clip(np.maximum(soft * (0.72 + 0.4 * (tex - 0.5)), bleed * 0.55), 0, 1)
    # 外圈：一笔圆相（起笔重、收笔飞白、留一个缺口）。笔毛的丝缕沿着圆周走。
    ang = (np.arctan2(dy, dx) + math.pi * 0.62) % (2 * math.pi) / (2 * math.pi)
    base_w = R * 0.05
    width = base_w * (0.45 + 0.85 * np.sin(np.clip(ang, 0, 1) * math.pi) ** 0.6) * (1.12 - 0.25 * ang)
    rad = r - R * 1.04
    ring = np.clip((width - np.abs(rad)) / 1.6, 0, 1) * (ang < 0.93)
    # 丝缕：只随半径变化的一维噪声（同心细纹），再随角度缓慢起伏
    n = max(8, int(base_w * 8))
    prof = K.noise1d(n, max(2, n / 14), 3, rng)
    idx = np.clip(((rad / (base_w * 2.2)) + 0.5) * (n - 1), 0, n - 1).astype(int)
    streak = prof[idx]
    wobble = K.noise1d(720, 40, 3, rng)[np.clip((ang * 719).astype(int), 0, 719)]
    dry = np.clip((streak + 0.25 * (wobble - 0.5) - (0.18 + 0.62 * ang ** 2.2)) * 5, 0, 1)
    ring = ring * (0.25 + 0.75 * dry)
    # 起笔处墨重、略洇
    head = np.clip(1 - ang / 0.08, 0, 1) * np.clip((width * 1.3 - np.abs(rad)) / 2, 0, 1)
    ring = np.maximum(ring, ndimage.gaussian_filter(head, 1.2) * 0.9)
    return np.clip(yin, 0, 1), np.clip(ring, 0, 1)


def bagua_alpha(h, w, cx, cy, R, line_w):
    im = Image.new('L', (w, h), 0)
    d = ImageDraw.Draw(im)
    # 先天八卦：乾兑离震巽坎艮坤
    trigrams = [7, 3, 5, 1, 6, 2, 4, 0]
    for k in range(8):
        a = -math.pi / 2 + k * math.pi / 4
        for j in range(3):
            rr = R * (1.22 + j * 0.075)
            solid = (trigrams[k] >> (2 - j)) & 1
            span = 0.20
            segs = [(-span, span)] if solid else [(-span, -0.035), (0.035, span)]
            for s0, s1 in segs:
                pts = [(cx + math.cos(a + t) * rr, cy + math.sin(a + t) * rr) for t in np.linspace(s0, s1, 12)]
                d.line(pts, fill=255, width=max(1, int(line_w)))
    a = np.asarray(im, float) / 255
    return ndimage.gaussian_filter(a, 0.9)


def vertical_text(text, size, font=BRUSH):
    ft = ImageFont.truetype(font, size)
    im = Image.new('L', (int(size * 1.3), int(size * 1.15 * len(text) + size * 0.3)), 0)
    d = ImageDraw.Draw(im)
    for i, ch in enumerate(text):
        bb = d.textbbox((0, 0), ch, font=ft)
        d.text(((im.width - (bb[2] - bb[0])) / 2 - bb[0], i * size * 1.15 - bb[1] + size * 0.1), ch, font=ft, fill=255)
    return np.asarray(im, float) / 255


# ───────────────────────── 背景 ─────────────────────────

def scene_taiji_paper():
    rng = np.random.default_rng(1314)
    img = K.paper(H, W, PAPER, rng)
    cx, cy, R = W * 0.5, H * 0.30, W * 0.33
    # 八卦（极淡）
    img = K.composite(img, (90, 80, 70), bagua_alpha(H, W, cx, cy, R, 8 * SCALE) * 0.22)
    # 太极：阴区淡墨晕染、阳区留白，外圈浓墨一笔
    yin, ring = taiji_alpha(H, W, cx, cy, R, rng)
    img = K.composite(img, (52, 46, 41), yin * 0.30)
    img = K.composite(img, INK, ring * 0.78)
    # 远山 + 云雾
    layers = [
        (H * 0.70, H * 0.12, 260, 0.18, [(0.22, H * 0.06, 0.10), (0.78, H * 0.05, 0.09)], (120, 124, 126)),
        (H * 0.82, H * 0.14, 200, 0.36, [(0.65, H * 0.08, 0.10)], (80, 82, 84)),
        (H * 0.95, H * 0.15, 160, 0.66, [(0.15, H * 0.09, 0.10)], INK),
    ]
    for i, (by, amp, sc, st, peaks, col) in enumerate(layers):
        a, _ = K.mountain_layer(H, W, by, amp, sc * SCALE, rng, peaks)
        img = K.composite(img, col, a * st)
        if i < 2:
            img = K.composite(img, (245, 241, 231), K.mist_band(H, W, by + amp * 0.15, H * 0.03, rng, 0.9))
    # 飞鸟（似鹤）
    img = K.composite(img, INK, K.birds_mask(W, H, rng, 3, (0.14, 0.60, 0.26, 0.05), 15 * SCALE) * 0.45)
    # 右侧竖写「道法自然」（淡墨）
    t = vertical_text('道法自然', int(78 * SCALE))
    canvas = np.zeros((H, W))
    K.place(canvas, t, W * 0.86, H * 0.52)
    img = K.composite(img, (60, 52, 46), canvas * 0.26)
    # 左下角朱砂印「太极」
    seal = K.seal_image('太极', int(96 * SCALE), RED, SERIF, rng)
    pil = Image.fromarray(np.clip(img, 0, 255).astype(np.uint8)).convert('RGBA')
    sealw = Image.new('RGBA', pil.size, (0, 0, 0, 0))
    sealw.paste(seal, (int(W * 0.07), int(H * 0.60)), seal)
    pil = Image.alpha_composite(pil, Image.blend(Image.new('RGBA', pil.size, (0, 0, 0, 0)), sealw, 0.8))
    return np.asarray(pil.convert('RGB'), float)


def scene_taiji_night():
    rng = np.random.default_rng(2718)
    img = np.ones((H, W, 3)) * np.array((19, 17, 16), float)
    img += ((K.fbm(H, W, 300, 4, rng) - 0.5) * 14)[..., None]
    swirl = K.fbm(H, W, 170, 5, rng)
    img = K.composite(img, (36, 33, 30), np.clip((swirl - 0.45) * 2.2, 0, 1) * 0.7)
    cx, cy, R = W * 0.5, H * 0.26, W * 0.30
    img = K.composite(img, (200, 190, 170), bagua_alpha(H, W, cx, cy, R, 7 * SCALE) * 0.16)
    yin, ring = taiji_alpha(H, W, cx, cy, R, rng)
    yang_disc = K.disc(H, W, cx, cy, R, 2) * (1 - yin)
    img = K.composite(img, (222, 214, 196), yang_disc * 0.13)
    img = K.composite(img, (232, 224, 205), ring * 0.45)
    img = K.composite(img, (232, 224, 205), K.halo(H, W, cx, cy, R) * 0.05)
    for by, amp, col, st in [(H * 0.80, H * 0.15, (40, 37, 33), 0.9), (H * 0.94, H * 0.16, (14, 13, 12), 1.0)]:
        a, _ = K.mountain_layer(H, W, by, amp, 200 * SCALE, rng, [(0.42, H * 0.06, 0.14)], rough=0.6)
        img = K.composite(img, col, a * st)
    return img


# ───────────────────────── 头像 / 插画 / 笔触 / 纸纹 ─────────────────────────

def make_avatar():
    S = 512
    rng = np.random.default_rng(9)
    img = K.paper(S, S, (240, 233, 218), rng, fiber=False, strength=0.6)
    yin, ring = taiji_alpha(S, S, S / 2, S / 2, S * 0.36, rng, wash=False)
    tex = K.fbm(S, S, 40, 4, rng)
    img = K.composite(img, INK, ndimage.gaussian_filter(yin, 1.0) * (0.78 + 0.25 * (tex - 0.5)))
    img = K.composite(img, INK, ring * 0.95)
    alpha = K.disc(S, S, S / 2, S / 2, S * 0.49, 2)
    rgba = np.dstack([np.clip(img, 0, 255), alpha * 255]).astype(np.uint8)
    Image.fromarray(rgba, 'RGBA').save(os.path.join(DST, 'images', 'avatar.png'), optimize=True)


def make_hero():
    """单色墨稿（App 里按配色着色）：太极 + 远山 + 打拳的人。"""
    w, h = int(900 * SCALE) or 900, int(560 * SCALE) or 560
    rng = np.random.default_rng(77)
    yin, ring = taiji_alpha(h, w, w * 0.5, h * 0.40, h * 0.30, rng)
    a = np.maximum(yin * 0.8, ring)
    m, ridge = K.mountain_layer(h, w, h * 0.95, h * 0.16, 120 * SCALE, rng, [(0.22, h * 0.07, 0.10), (0.85, h * 0.05, 0.08)], rough=0.6)
    yy = np.arange(h)[:, None]
    fade = np.clip(1 - (yy - ridge[None, :]) / (h * 0.12), 0, 1)
    a = np.maximum(a, m * fade * 0.55)
    man = K.swordsman_mask(600)
    canvas = np.zeros((h, w))
    K.place(canvas, man, w * 0.70, h * 0.48, h * 0.30 / 600)
    a = np.maximum(a, canvas)
    K.OUT = os.path.join(DST, 'images')
    K.save_alpha(np.clip(a, 0, 1), 'hero.png')


def make_divider():
    rng = np.random.default_rng(31)
    a = K.brush_stroke(1400, 120, rng)
    # 中间一个小太极点
    yin, ring = taiji_alpha(120, 1400, 700, 60, 30, rng, wash=False)
    a = np.maximum(a * (1 - K.disc(120, 1400, 700, 60, 40, 3)), np.maximum(yin, ring))
    K.OUT = os.path.join(DST, 'images')
    K.save_alpha(np.clip(a, 0, 1), 'divider.png')


def make_grain():
    rng = np.random.default_rng(3)
    S = 256
    img = K.paper(S, S, (128, 128, 128), rng, strength=1.4)
    g = np.clip(img.mean(axis=2), 0, 255)
    a = np.clip((128 - g) / 40, 0, 1)
    K.OUT = os.path.join(DST, 'images')
    K.save_alpha(a, 'grain.png', (60, 50, 40))


# ───────────────────────── 图标 ─────────────────────────

def _char_alpha(ch, S, size_ratio=0.6, font=BRUSH):
    ft = ImageFont.truetype(font, int(S * size_ratio))
    im = Image.new('L', (S, S), 0)
    d = ImageDraw.Draw(im)
    bb = d.textbbox((0, 0), ch, font=ft)
    d.text(((S - (bb[2] - bb[0])) / 2 - bb[0], (S - (bb[3] - bb[1])) / 2 - bb[1] - S * 0.01), ch, font=ft, fill=255)
    return np.asarray(im, float) / 255


def icon_ink(ch, rng, color=INK, ring=True, dot=True):
    """毛笔字 + 干笔圆相（适合浅色底）。"""
    S = 192
    a = _char_alpha(ch, S, 0.56 if ring else 0.74)
    a = np.clip(ndimage.gaussian_filter(a, 0.7) * 1.15, 0, 1)
    # 墨的浓淡
    tex = K.fbm(S, S, 20, 3, rng)
    a = a * (0.82 + 0.3 * (tex - 0.5))
    if ring:
        _, rr = taiji_alpha(S, S, S / 2, S / 2, S * 0.40, rng, wash=False)
        a = np.maximum(a, rr * 0.9)
    rgba = np.zeros((S, S, 4), float)
    rgba[..., :3] = color
    rgba[..., 3] = np.clip(a, 0, 1) * 255
    if dot:
        # 右上角一点朱砂
        d = K.disc(S, S, S * 0.80, S * 0.18, S * 0.05, 1.5)
        rgba[..., :3] = rgba[..., :3] * (1 - d[..., None]) + np.array(RED, float) * d[..., None]
        rgba[..., 3] = np.maximum(rgba[..., 3], d * 235)
    return Image.fromarray(rgba.astype(np.uint8), 'RGBA').resize((128, 128), Image.LANCZOS)


def icon_seal(ch, rng):
    """朱砂印（重要按钮）。"""
    return K.seal_image(ch, 128, RED, BRUSH, rng)


def icon_light(ch, rng):
    """浅色毛笔字（放在朱砂 / 深色圆按钮上）。"""
    return icon_ink(ch, rng, color=(255, 247, 236), ring=False, dot=False)


def icon_taiji(rng, dark=False):
    S = 192
    yin, ring = taiji_alpha(S, S, S / 2, S / 2, S * 0.38, rng, wash=False)
    disc = K.disc(S, S, S / 2, S / 2, S * 0.38, 1.5)
    rgba = np.zeros((S, S, 4), float)
    paper = np.array((246, 240, 228), float)
    ink = np.array(INK, float)
    col = paper * (1 - yin[..., None]) + ink * yin[..., None]
    col = col * (1 - ring[..., None]) + ink * ring[..., None]
    rgba[..., :3] = col
    rgba[..., 3] = np.clip(np.maximum(disc, ring), 0, 1) * 255
    return Image.fromarray(rgba.astype(np.uint8), 'RGBA').resize((128, 128), Image.LANCZOS)


# 图标位 → (样式, 字)
ICONS = {
    # 顶栏
    'header.history': ('ink', '史'), 'header.new': ('ink', '新'), 'header.more': ('ink', '余'),
    'header.wuji': ('taiji', ''), 'header.deep': ('seal', '思'),
    # 输入栏
    'input.toolbox': ('seal', '囊'), 'input.tools': ('ink', '器'), 'input.web': ('ink', '网'),
    'input.send': ('light', '发'), 'input.mic': ('ink', '声'), 'input.stop': ('light', '止'),
    'input.cancel': ('ink', '罢'), 'input.done': ('light', '毕'),
    # 消息
    'msg.copy': ('ink', '抄'), 'msg.speak': ('ink', '读'), 'msg.mute': ('ink', '默'), 'msg.retry': ('ink', '复'),
    'msg.delete': ('ink', '删'), 'msg.save': ('ink', '藏'), 'msg.thinking': ('ink', '悟'),
    # 卡片
    'card.done': ('ink', '成'), 'card.error': ('ink', '误'), 'card.expand': ('ink', '展'), 'card.plan': ('taiji', ''),
    'card.confirm': ('seal', '令'), 'card.user': ('light', '亲'),
    # 长思
    'deep.start': ('ink', '行'), 'deep.pause': ('ink', '歇'), 'deep.folder': ('ink', '匣'), 'deep.new': ('light', '新'),
    'deep.send': ('light', '传'),
    # 文件夹
    'folder.dir': ('ink', '卷'), 'folder.file': ('ink', '笺'),
    # 工具
    'tool.web_search': ('ink', '寻'), 'tool.read_webpage': ('ink', '阅'), 'tool.step_think': ('ink', '析'), 'tool.calc': ('ink', '算'),
    'tool.read_file': ('ink', '读'), 'tool.create_file': ('ink', '撰'), 'tool.edit_file': ('ink', '改'), 'tool.rewrite_file': ('ink', '润'),
    'tool.translate': ('ink', '译'), 'tool.generate_image': ('ink', '画'), 'tool.remember': ('ink', '记'), 'tool.recall': ('ink', '忆'),
    'tool.ai_files': ('ink', '匣'), 'tool.transcribe_audio': ('ink', '录'), 'tool.listen_audio': ('ink', '听'), 'tool.deep_think': ('seal', '思'),
    'tool.doc_outline': ('ink', '纲'), 'tool.list_files': ('ink', '目'), 'tool.pdf_tool': ('ink', '帖'), 'tool.convert_file': ('ink', '换'),
    'tool.restore_file': ('ink', '还'), 'tool.download': ('ink', '取'), 'tool.open_app': ('ink', '启'), 'tool.phone_task': ('ink', '役'),
    'tool.phone_action': ('ink', '按'), 'tool.read_screen': ('ink', '观'), 'tool.look_screen': ('ink', '视'), 'tool.notifications': ('ink', '讯'),
    'tool.clipboard': ('ink', '贴'), 'tool.device_info': ('ink', '机'), 'tool.list_apps': ('ink', '列'), 'tool.contacts': ('ink', '友'),
    'tool.call_phone': ('ink', '呼'), 'tool.send_message': ('ink', '信'), 'tool.open_url': ('ink', '径'), 'tool.guide': ('ink', '引'),
    'tool.translate_screen': ('ink', '屏'), 'tool.smart_home': ('ink', '宅'), 'tool.open_page': ('ink', '页'), 'tool.set_theme': ('ink', '色'),
    'tool.set_background': ('ink', '景'), 'tool.forget': ('ink', '忘'), 'tool.theme': ('ink', '妆'), 'tool.plan': ('ink', '谋'),
    'tool.ask_user': ('ink', '问'),
    # 百宝囊
    'box.deep': ('seal', '思'), 'box.wuji': ('taiji', ''), 'box.step': ('ink', '分'), 'box.loop': ('ink', '环'),
    'box.tools': ('ink', '器'), 'box.ai_folder': ('ink', '匣'), 'box.voice_chat': ('ink', '谈'), 'box.transcribe': ('ink', '录'),
    'box.image': ('ink', '图'), 'box.camera': ('ink', '摄'), 'box.file': ('ink', '卷'), 'box.draw': ('ink', '画'),
    'box.create_doc': ('ink', '文'), 'box.create_ppt': ('ink', '演'), 'box.rewrite': ('ink', '润'), 'box.pdf': ('ink', '帖'),
    'box.search': ('ink', '寻'), 'box.translate': ('ink', '译'), 'box.screen_translate': ('ink', '屏'), 'box.read_screen': ('ink', '观'),
    'box.phone': ('ink', '役'), 'box.guide': ('ink', '引'), 'box.memory': ('ink', '记'), 'box.backup': ('ink', '存'),
    'box.theme': ('ink', '妆'), 'box.background': ('ink', '景'), 'box.lens': ('ink', '镜'), 'box.slate': ('ink', '书'),
    'box.home': ('ink', '宅'), 'box.bubble': ('ink', '泡'), 'box.pilot': ('ink', '驭'), 'box.guide_page': ('ink', '导'),
    'box.help': ('ink', '问'), 'box.settings': ('ink', '规'),
}


def make_icons():
    rng = np.random.default_rng(88)
    out = {}
    for slot, (style, ch) in ICONS.items():
        if style == 'seal':
            im = icon_seal(ch, rng)
        elif style == 'light':
            im = icon_light(ch, rng)
        elif style == 'taiji':
            im = icon_taiji(rng)
        else:
            im = icon_ink(ch, rng)
        name = 'icons/' + slot.replace('.', '_') + '.png'
        im.save(os.path.join(DST, name), optimize=True)
        out[slot] = name
    return out


PALETTE = {
    "background": "#F2EDE2", "backgroundAlt": "#E6DECD", "surface": "#FAF6EC", "surfaceAlt": "#EEE6D4",
    "cinnabar": "#A3342B", "onCinnabar": "#FFF7EC", "gold": "#8C7445", "indigo": "#2F5A55", "bamboo": "#4F7A44",
    "text": "#1B1714", "textSecondary": "#4D433A", "textTertiary": "#877A69", "border": "#4D4A3B2C", "error": "#A8261C",
    "userBubble": "#1F1B18", "onUserBubble": "#F3ECDD", "mountain": "#24201C", "ink": "#1F1B18",
}


def main():
    print('背景…')
    K.OUT = os.path.join(DST, 'images')
    K.save_rgb(scene_taiji_paper(), 'background.webp', q=80)
    K.save_rgb(scene_taiji_night(), 'page.webp', q=80)
    print('头像 / 插画 / 笔触 / 纸纹…')
    make_avatar(); make_hero(); make_divider(); make_grain()
    print('图标…')
    icons = make_icons()
    icons['avatar.ai'] = 'images/avatar.png'
    theme = {
        "format": "lingxi-theme", "version": 1, "id": "taiji", "name": "水墨太极",
        "author": "灵犀（程序绘制）",
        "description": "宣纸 · 水墨太极 · 八卦 · 远山；图标全部是毛笔字、干笔圆相与朱砂印",
        "dark": False, "bubbleAlpha": 0.88, "heroTint": True, "dividerTint": True,
        "colors": PALETTE,
        "images": {"background": "images/background.webp", "page": "images/page.webp", "avatar": "images/avatar.png",
                   "hero": "images/hero.png", "divider": "images/divider.png", "grain": "images/grain.png"},
        "icons": icons,
    }
    with open(os.path.join(DST, 'theme.json'), 'w', encoding='utf-8') as f:
        json.dump(theme, f, ensure_ascii=False, indent=2)
    pack = os.path.join(OUT_ROOT, '水墨太极.lxtheme')
    with zipfile.ZipFile(pack, 'w', zipfile.ZIP_DEFLATED) as z:
        for base, _, files in os.walk(DST):
            for fn in files:
                p = os.path.join(base, fn)
                z.write(p, os.path.relpath(p, DST))
    print('完成：', pack, os.path.getsize(pack) // 1024, 'KB')


if __name__ == '__main__':
    main()
