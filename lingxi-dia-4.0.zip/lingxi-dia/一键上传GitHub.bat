@echo off
chcp 65001 >nul
rem 灵犀 Dia 3.0 —— 一键把代码推到 GitHub（推上去后 GitHub 会自动打包 APK）
cd /d "%~dp0"
set /p USER=你的 GitHub 用户名: 
set /p REPO=仓库名（直接回车默认 lingxi-dia）: 
if "%REPO%"=="" set REPO=lingxi-dia
if not exist .git git init
git add -A
git commit -m "灵犀 3.0 水墨江湖 · 无极版"
git branch -M main
git remote remove origin 2>nul
git remote add origin https://github.com/%USER%/%REPO%.git
git push -u origin main
echo.
echo 已推送。打开 https://github.com/%USER%/%REPO%/actions 等待「Android 打包」变绿，然后在页面底部 Artifacts 下载 APK。
pause
